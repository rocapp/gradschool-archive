#!/bin/bash
fext=nmuc
[[ "$@" == *"--muc"* ]] && fext=muc
[[ "$@" == *"vta"* ]] && fext+="_vtadeg"
export -p fext
g++ run.cc && ./a.out "$@" && python3 sim.py
