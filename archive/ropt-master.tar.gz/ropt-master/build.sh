#!/usr/bin/env bash
cd $ROPTPATH
echo $(pwd)
src=$ROPTPATH/src/
src=$(realpath -ms $src)
includes=$ROPTPATH/src/includes/
includes=$(realpath -ms $includes)
test=${test:-sl_test}
tests=${ROPTPATH}/tests/
tests=$(realpath -ms $tests)
echo "ROPTPATH=$ROPTPATH"
echo "SRC=$src"
echo "INCLUDES=$includes"
echo "TEST=$test"
SOURCES=""
for eachfile in $(ls $src/*.cc)
do
    SOURCES="$SOURCES $eachfile"
done
SOURCES="$SOURCES $tests/$test.cc"
arch=linux
if [ "$arch" = "linux" ]
then
    CFLAGS=" "
    LIBS=" "
    echo "CFLAGS=$CFLAGS"
    echo "LIBS=$LIBS"
    echo "SOURCES=$SOURCES"
    g++ -Wall -std=c++17 -g $CFLAGS -I$includes $SOURCES -o $ROPTPATH/$test.bin $LIBS
elif [ "$arch" = "win" ]
then
    echo "not done yet."
fi
