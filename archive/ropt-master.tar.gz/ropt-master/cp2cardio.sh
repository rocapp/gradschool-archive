#!/bin/bash
cp -f ./lib/libropt.so ../cardio-cpp/lib/
cp -f ./src/includes/opt.hpp ../cardio-cpp/include/
