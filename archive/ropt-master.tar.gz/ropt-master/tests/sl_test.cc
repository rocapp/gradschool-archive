#include "opt.hpp"
#include <iostream>
#include <algorithm>
#include <vector>
#include <cstdlib>
#include <ctime>

int main(int argc, char*argv[])
{
  std::srand ( unsigned ( std::time(0) ) );

  std::cout << "P0 = [ ";
  std::vector<float> p0 = {18.2, 3.0, 5.0};
  for(float& pf: p0)
    std::cout << pf << " ";
  std::cout << " ] " << std::endl;

  Optimizer opt(p0);
  opt.sigma = 1e-3;

  // training vectors
  std::vector<float> xi = {1., 2., 3.};
  std::vector<float> yi = {1*xi[0],
			   2*xi[1],
			   3*xi[2]};
  std::cout << "y = [ ";
  for(float& yj: yi)
    std::cout << yj << " ";
  std::cout << " ] " << std::endl;
  
  // std::generate(xi.begin(), xi.end(), RandomNumber);
  std::cout << "x = [ ";
  for(float& xj: xi)
    std::cout << xj << " ";
  std::cout << " ] " << std::endl;

  std::cout << "training using supervised learning...\n";
  for(int i=0; i < 10000; i++)
    {
      opt.train_once_supervised(xi, yi);
      // std::cout << "iter " << i << std::endl;
      // for(float& pp: opt.p())
      // 	std::cout << pp << ", ";
      // std::cout << std::endl;
    }
  std::cout << "training error = " << std::endl;
  std::vector<float> trerr = opt.training_error();
  for(int j=0; j < (int)opt.M(); j++)
    std::cout << trerr.at(j) << ", ";
  std::cout << std::endl;
  std::cout << "P* = [ ";
  for(int j=0; j < (int)opt.M(); j++)
    std::cout << opt.p().at(j) << " ";
  std::cout << " ] " << std::endl;
  std::cout << "training finished." << std::endl;
  return 0;
}
