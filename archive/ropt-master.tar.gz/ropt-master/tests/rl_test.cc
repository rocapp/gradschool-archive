#include "opt.hpp"
#include <iostream>
#include <algorithm>
#include <vector>

std::vector<float> reward3(std::vector<float> x);
std::vector<float> reward3(std::vector<float> x)
{
  std::vector<float> reward((int)x.size(),0);
  for(int j=0; j < (int)x.size(); j++)
    reward.at(j) -= std::abs(x.at(j) - 3.0);
  return reward;
}

int main(int argc, char*argv[])
{
  std::srand ( unsigned ( std::time(0) ) );

  int M = 100;
  std::vector<float> p0(M,0);
  Optimizer opt(p0);
  opt.sigma = 1e-2;

  // set reward function
  opt.reward_func = reward3;

  // training vectors
  std::vector<float> xi(M);
  std::generate(xi.begin(), xi.end(), RandomNumber);
  for(float& xj: xi)
    xj *= 100.0;
  // std::cout << "x = [ ";
  // for(float& xj: xi)
  //   std::cout << xj << " ";
  // std::cout << " ] " << std::endl;

  std::cout << "training using reinforcement learning...\n";
  for(int i=0; i < 10000; i++)
    {
      opt.train_once_modelfree(xi);
      // std::cout << "iter " << i << std::endl;
      // for(float& pp: opt.p())
      // 	std::cout << pp << ", ";
      // std::cout << std::endl;
    }
  std::cout << "training finished." << std::endl;
  int max_ri = opt.max_reward_index();
  std::cout << "Max rewarded x = " << xi.at(max_ri) << "(rmax=" << opt.p().at(max_ri) << ")"
	    << std::endl;
  int min_ri = opt.min_reward_index();
  std::cout << "Min rewarded x = " << xi.at(min_ri) << "(rmin=" << opt.p().at(min_ri) << ")"
	    << std::endl;
  return 0;
}
