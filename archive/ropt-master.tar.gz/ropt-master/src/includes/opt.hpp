#ifndef OPT_HPP
#define OPT_HPP

#include <iostream>
#include <vector>
#include <functional>
#include <cmath>
#include <iterator>
#include <algorithm>
#include <cstdlib>
#include <ctime>

float RandomNumber();

class Optimizer {

  unsigned int M_, N_;
  std::vector<float> p_;
  
public:  
  Optimizer(std::vector<float> p0) : p_(p0)
  {
    M_ = (unsigned int)(p0.size());
  }

  unsigned int M() const { return M_; }
  unsigned int N() const { return N_; }
  std::vector<float> p() const { return p_; }
  
  float sigma = 1e-3;
  float gamma = 1e-5;
  
  std::vector<std::vector<float>> X_train, Y_train, R_train;
  std::vector<std::vector<float>> X_test, Y_test, R_test;

  std::vector<float> training_error()
  {
    std::vector<float> trerr((int)(M_),0.0);
    for(int ti=0; ti < (int)R_train.size(); ti++)
      {
	for(int tj=0; tj < (int)(M_); tj++)
	  {
	    trerr.at(tj) += std::abs(R_train.at(ti).at(tj));
	  }
      }
    for(float& tre: trerr)
      tre /= (float)(R_train.size());
    return trerr;
  }
  
  std::function<std::vector<float>(std::vector<float>,std::vector<float>)> cost_func =
    [this](std::vector<float> x, std::vector<float> y)
  {
    std::vector<float> cost((int)M_,0);
    for(int j=0; j < (int)x.size(); j++)
      cost.at(j) += (y.at(j) - p_.at(j)*x.at(j)) / std::abs(y.at(j));
    return cost;
  };

  int max_reward_index()
  {
    return (int)std::distance(p_.begin(),std::max_element(p_.begin(), p_.end()));
  }

  int min_reward_index()
  {
    return (int)std::distance(p_.begin(),std::min_element(p_.begin(), p_.end()));
  }

  std::function<std::vector<float>(std::vector<float>)> reward_func =
    [this](std::vector<float> x)
  {
    std::vector<float> reward((int)M_,0);
    for(int j=0; j < (int)x.size(); j++)
      reward.at(j) += 1.0 / (float)((int)x.at(j) % 3) - (float)((int)x.at(j) % 9);
    return reward;
  };
  
  std::vector<float> train_once_supervised(std::vector<float> x, std::vector<float> y);
  std::vector<float> train_once_modelfree(std::vector<float> rwd);
};

#endif
