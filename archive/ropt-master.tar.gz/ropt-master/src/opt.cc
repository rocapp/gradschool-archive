#include "opt.hpp"
#include <vector>

float RandomNumber () { return (float)(rand()) / (RAND_MAX); }

std::vector<float> Optimizer::train_once_supervised(std::vector<float> x, std::vector<float> y)
{
  X_train.push_back(x);
  Y_train.push_back(y);
  R_train.push_back(cost_func(x, y));
  if((int)R_train.size() > 1)
    {
      for(int pi=0; pi < (int)M_; pi++)
	p_.at(pi) += (R_train.back().at(pi) + pow(R_train.at(R_train.size()-2).at(pi) - R_train.back().at(pi),2))*sigma;
    }
  return p();
}

std::vector<float> Optimizer::train_once_modelfree(std::vector<float> rwd)
{
  R_train.push_back(rwd);
  if((int)R_train.size() > 1)
    {
      for(int pi=0; pi < (int)M_; pi++)
	p_.at(pi) += (2.0*R_train.back().at(pi)-R_train.at(R_train.size()-2).at(pi))*sigma;
    }
  return p();
}
