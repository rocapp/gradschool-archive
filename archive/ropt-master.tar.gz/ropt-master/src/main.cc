#include "opt.hpp"
#include <iostream>
#include <string>

int main(int argc, char*argv[])
{
  std::cout << "=== ropt ===" << std::endl;
  if(argc < 2) {
    std::cout << "Usage: ./ropt.bin <sl_test|rl_test>" << std::endl;
    std::exit(0);
  }
  std::string cmd = (std::string)(argv[1]);
  std::cout << "cmd = " << cmd << std::endl;
  if(cmd=="sl_test"||cmd=="rl_test") {
    std::system(("./bin/" + cmd + ".bin").c_str());
  } else {
    std::cout << "no such command... exiting..." << std::endl;
  }
}
