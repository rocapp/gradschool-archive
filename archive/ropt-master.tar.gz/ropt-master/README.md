*ropt*

An extensible optimization toolkit written in C/C++