#!/usr/bin/env python3

# author: Robert A. Capps
# Fall 2018
# Model of TAN dynamics

import matplotlib as mpl
mpl.use("Agg")

mpl.rcParams["figure.titlesize"] = 36 #"xx-large"
mpl.rcParams["figure.titleweight"] = "bold"
mpl.rcParams["figure.dpi"] = 150
mpl.rcParams["figure.figsize"] = (14, 15)
mpl.rcParams["axes.labelsize"] = 25 #"x-large"
mpl.rcParams["axes.titlesize"] = 30 #"xx-large"
mpl.rcParams["xtick.labelsize"] = 36 #"x-large"
mpl.rcParams["ytick.labelsize"] = 36 #"x-large"
mpl.rcParams["lines.linewidth"] = 5.0
mpl.rcParams["legend.fontsize"] = 30 #"xx-large"

import matplotlib.pyplot as plt
from matplotlib.figure import Figure
import numpy as np
from scipy.integrate import odeint
from scipy.optimize import minimize, differential_evolution
import os,sys
import cgi

# Path to save TAN figures
tan_path = os.path.expanduser("~/Documents/TANfigs")
www_path = os.path.expanduser("~/Documents/TANwww")
for path in [tan_path, www_path]:
    if not os.path.isdir(path):
        os.mkdir(path) # make the path if it doesn't exist

def normalize(x): # normalize from 0 to 1
    return (x - x.min()) / (x.max() - x.min())

def heavi(x): # heaviside function
    if x > 0:
        return x
    return 0

def sigmoid(x):
    H = np.tanh(x) if x > 0 else 0
    return H

def dTAN(y, t, p): # derivative function
    dydt = [0,0,0,0]
    V_thal = 1.0 if (t > p["t_stim"][0] and t < p["t_stim"][1]) else 0.0
    I_tan = p["w_thal"]*V_thal + p["drv_tan"] + y[1] + y[2]
    dydt[0] = (sigmoid(I_tan)-y[0])/p["tau_tan"]                                                                 # dV_tan
    dydt[1] = (-y[1]-p["g_sahp"]*(y[0]-p["theta_sahp"])*heavi((y[0]-p["theta_sahp"])))/p["tau_sahp"]             # dI_sAHP
    dydt[2] = (-y[2]+p["g_h"]*np.exp(-p["w_da"]*y[3])*(p["theta_h"]-y[0])*heavi(p["theta_h"]-y[0]))/p["tau_h"]   # dI_h
    dydt[3] =  (1.0-p["DA_def"]) * ( p["LDOPA"] + p['da_0'] - y[3] + p['g_da'] * ( p["rpe"] * (p["da_0"] - y[0]/p["theta_da"]) ) * heavi(p["theta_da"]-y[0]) ) / p["tau_da"] #dDA
    return dydt

def tan_model(time,p,y0): # integrate tan model
    sol = odeint(dTAN, y0, time, args=(p,))
    return sol

def tan_dur(time,tan_plot,tstim): # calculate duration of TAN pause
    len_dur = np.argwhere((tan_plot<0.01) & (time > tstim))
    dur = time[len_dur][-1] - time[len_dur][0]
    # print("tan pause length (ms):",dur)
    return dur[0]

def da_amp(da):
    dmax = da.max() if da.min() >= -0.001 else da.min()
    # print("da amplitude:",dmax)
    return dmax

def tan_plot(time,sol,p,show=False,ftype='png',web=False):
    tan_plot = sol[:, 0].copy()
    tdur = tan_dur(time,tan_plot,p["t_stim"][0])
    DA = sol[:,3].copy()
    da_plot = DA
    damp = da_amp(da_plot)
    sahp_plot = sol[:, 1].copy()
    h_plot = sol[:,2].copy()
    # Plot
    rpe = p['rpe']
    DA_def = p['DA_def']
    stitle = "RPE={:.1f}".format(rpe,)
    fn = "tans_rpe={:.1f}".format(rpe,)
    if DA_def > 0: # Some DA deficiency
        fn = "DAdef" + fn + "_ldopa={:.1f}_dadef={:.1f}".format(LDOPA,DA_def)
        if LDOPA == 0 and rpe == 1:
            fn = "A1_" + fn
        elif LDOPA == 0 and rpe == -1:
            fn = "A2_" + fn
        elif LDOPA > 0 and rpe == 1:
            fn = "B1_" + fn
        elif LDOPA > 0 and rpe == -1:
            fn = "B2_" + fn
        fig = Figure(figsize=(10,7),frameon=False)
        stitle = stitle + "\n{:d}% Dopamine deficiency".format(int(DA_def*100),)
        if LDOPA > 0:
            stitle = stitle + "\nLevodopa={:.2f}".format(LDOPA,)
        fig.suptitle(stitle, ha="right", x=0.95, fontsize="xx-large")
        ax = fig.add_subplot()
        ax.plot(time, da_plot, '#ffa500')
        tan_fill = time[(tan_plot<0.025) & (time>p["t_stim"][0])]
        fillshift=30
        ax.fill_betweenx([-0.1, 2.1],
                          x1=tan_fill[0]+fillshift,
                          x2=tan_fill[-1]+fillshift,
                          facecolor='#000077', alpha=0.2, edgecolor='b',
                          hatch="\\")
        ax.fill_between(time, -0.1, da_plot, facecolor='#ff9700',
                         alpha=0.5, hatch="/", edgecolor='#ffa500')
        ax.set_xlim([2000, 4000])
        ax.set_xticks([2000, 3000, 4000])
        ax.set_ylim([-0.1, 2.1])
        ax.set_yticks([0, 1.0, 2.0])
        ax.set_xlabel("time (ms)")
        ax.set_ylabel("Dopamine release")
        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        fig.tight_layout()
    # print("  ",stitle.replace("    ","\n  "))
    if DA_def==0: # No DA deficiency
        if rpe == 1:
            fn = "A_" + fn
        elif rpe == 0:
            fn = "B_" + fn
        elif rpe == -1:
            fn = "C_" + fn
        fig = Figure(frameon=False)
        fig.suptitle(stitle, x=0.85)
        pad_title_top = -25
        plotix = 411
        ax = fig.add_subplot(plotix)
        ax.set_title("TAN activity", loc="left", pad=pad_title_top)
        ax.plot(time, tan_plot, 'b')
        ax.vlines(x=p["t_stim"][0],
                   ymin=-0.1, ymax=1.0, # mark stimulation time
                   color="r", linestyle="--")
        tan_fill = time[(tan_plot<0.025) & (time>p["t_stim"][0])]
        ax.fill_betweenx([-0.1, 1], x1=tan_fill[0], x2=tan_fill[-1],
                          facecolor='#000077', alpha=0.2, edgecolor='b',
                          hatch="\\")
        # ax.setp(ax.get_xticklabels(), visible=False)
        ax.set_xticklabels([],[])
        ax.set_yticks([0, 0.5, 1])
        ax.set_ylim([-0.1, 1.1])
        ax.spines['right'].set_visible(False)
        ax.spines['top'].set_visible(False)
        ax.set_ylabel("Activity")
        ax1 = fig.add_subplot(plotix+1,sharex=ax)
        ax1.set_title("Dopamine release", loc="left", pad=pad_title_top)
        ax1.plot(time, da_plot, '#ffa500')
        tan_fill = time[(tan_plot<0.025) & (time>p["t_stim"][0])]
        ax1.fill_betweenx([-0.1, 2.1], x1=tan_fill[0], x2=tan_fill[-1],
                          facecolor='#000077', alpha=0.2, edgecolor='b',
                          hatch="\\")
        ax1.fill_between(time, -0.1, da_plot, facecolor='#ff9700',
                         alpha=0.5, hatch="/", edgecolor='#ffa500')
        ax1.set_ylim([-0.1, 2.1])
        # ax1.setp(ax1.get_xticklabels(), visible=False)
        ax1.set_xticklabels([],[])
        ax1.set_yticks([0, 1.0, 2.0])
        ax1.spines['right'].set_visible(False)
        ax1.spines['top'].set_visible(False)
        ax1.set_ylabel("Concentration")
        pad_title_bot = -25
        ax2 = fig.add_subplot(plotix+2,sharex=ax)
        ax2.set_title(r'Slow current ($I_{sAHP}$)', loc="left", pad=pad_title_bot)
        ax2.plot(time, 1.0-normalize(sahp_plot), 'r')
        # ax2.setp(ax2.get_xticklabels(), visible=False)
        ax2.set_xticklabels([],[])
        ax2.set_yticks([0, 0.5, 1.0])
        ax2.spines['right'].set_visible(False)
        ax2.spines['top'].set_visible(False)
        ax2.set_ylabel("Activation")
        ax3 = fig.add_subplot(plotix+3,sharex=ax)
        ax3.set_title("H-current ($I_{h}$)", loc="left", pad=pad_title_bot)
        ax3.plot(time, normalize(h_plot), 'k')
        ax3.set_yticks([0, 0.5, 1.0])
        ax3.set_xticks([p["t_stim"][0]-800, p["t_stim"][0], time.max()])
        ax3.set_xlim([p["t_stim"][0]-800, time.max()])
        ax3.set_xlabel("time (ms)")
        ax3.spines['right'].set_visible(False)
        ax3.spines['top'].set_visible(False)
        ax3.set_ylabel("Activation")
        fig.subplots_adjust(hspace=0.3)
        fig.tight_layout()
    if show:
        fig.show()
    if not web:
        fig.savefig(os.path.join(tan_path, fn+"."+ftype))
        return
    return fig

def dur_run(time, y0, p, show=False, ftype='png'):
    # thalamic stimulation time (ms)
    stimtime = np.array([300.0, 400.0, 500.0])
    sts = {}
    p["t_stim"][0] = 2000.0
    stimtime = stimtime + p["t_stim"][0]
    # print("thal stim")
    for rpe in [-1, 1]:
        p['rpe'] = rpe
        sts[rpe] = []
        for st in stimtime:
            p['t_stim'][1] = st
            soln = tan_model(time,p,y0)
            tdur=tan_dur(time,soln[:,0],p["t_stim"][0])
            sts[rpe].append(tdur)
            # print(" stimtime=", st, "rpe=", p["rpe"], " : tdur=",tdur)
    dur_plot(sts, stimtime, 0.1*np.mean(stimtime-2000.0), stimtime.astype(np.int)-2000, "Thalamic stimulation time (ms)", "thal", show=show, ftype=ftype)
    
    p['t_stim'][1] = 2500.0
    
    # DA deficiency (%)
    # print("\ndadef")
    dadefs = np.array([0.2, 0.5, 0.8])
    das = {}
    for rpe in [-1, 1]:
        p["rpe"] = rpe
        das[rpe] = []
        for da in dadefs:
            # p["rpe"]=rpe-da
            # if rpe-da < -1: p["rpe"]=-1
            p["da_0"]=1.0-da
            p["DA_def"] = da
            soln = tan_model(time,p,y0)
            tdur = tan_dur(time,soln[:,0],p["t_stim"][0])
            # print(" def=", da, " rpe=",p["rpe"]," : tdur=",tdur)
            das[rpe].append(tdur)
    dur_plot(das, dadefs, 0.25*np.mean(dadefs*100.0), (dadefs*100.0).astype(np.int), "Dopamine deficiency (%)", "dadef", show=show, ftype=ftype)
    p["da_0"] = 1.0
    
    # LDOPA
    ldops = np.array([0.2, 0.5, 0.8]) #np.linspace(0, 1.0, 3)
    lds = {}
    # print('\nldopa')
    ldadef=0.5
    for rpe in [-1, 1]:
        p["rpe"] = rpe
        # if p["rpe"] < -1: p["rpe"]=-1
        lds[rpe] = []
        for ld in ldops:
            p["da_0"] = 1-ldadef
            p["DA_def"] = ldadef
            p["LDOPA"] = ld
            soln = tan_model(time,p,y0)
            tdur = tan_dur(time,soln[:,0],p["t_stim"][0])
            lds[rpe].append(tdur)
            # print(" ldopa=", ld, " rpe=",p["rpe"]," : tdur=",tdur)
    dur_plot(lds, ldops, 0.2*np.mean(ldops), ldops, "Levodopa concentration", "ldopa",
             show=show, ftype=ftype)

def dur_plot(hdict, x, width, xticks, dtitle, stitle, show=False, ftype="png"):
    plt.figure()
    colors = ["k", "w"]
    ix = 0
    bars = []
    labels = []
    hatch = ""
    if "dadef"==stitle: x = x*100.0
    for hk, hv in sorted(hdict.items()):
        labels.append(hk)
        if colors[ix]=="w": hatch="/"
        bars.append(plt.bar(x+ix*width, hv, width,
                            facecolor=colors[ix],
                            edgecolor='k',
                            hatch=hatch))
        ix += 1
    plt.ylim([100, 450])
    xtlabels = {"ldopa": "{:.2f}", "dadef": "{:d}", "thal": "{:d}"}
    plt.xticks(x+width/1.5,[xtlabels[stitle].format(xt) for xt in xticks],fontsize="x-large")
    plt.yticks([100, 200, 300, 400,],fontsize="x-large")
    plt.ylabel('TAN pause duration (ms)',fontsize="xx-large")
    plt.legend(bars, ["RPE={}".format(label) for label in labels], loc='upper left')
    plt.xlabel(dtitle,fontsize="xx-large")
    plt.tight_layout()
    if show: plt.show()
    else:
        fn = "tan_durs_{}.{}".format(stitle,ftype)
        if stitle=="thal": fn = "A_" + fn
        elif stitle=="dadef": fn = "B_" + fn
        elif stitle=="ldopa": fn = "C_" + fn
        plt.savefig(os.path.join(tan_path, fn))
    plt.close()


import io
import urllib, base64

def web_format(fig, ftype='svg', params=None):
    buf = io.BytesIO()
    fig.savefig(buf,bbox_inches="tight",format=ftype)
    buf.seek(0)
    string = base64.b64encode(buf.read())
    ft = ftype
    if ftype == 'svg':
        ft = 'svg+xml'
    uri = 'data:image/{};base64,'.format(ft) + urllib.parse.quote(string)
    htmlbody =\
        ('<!DOCTYPE html>'
         '<html>'
         '<head>'
         '<style>'
         'svg,figure,embed,'
         'img {{ display: block; max-width: auto; max-height: auto; padding: 0 0 0 0; margin: 0 0 0 0; height: 550px; width: auto; }}'
         '.myfig {{ outline: 1px solid blue; height: 550px; width: auto; }}'
         '</style>'
         '<script>'
         'function getval() {{ '
         '    var x = document.getElementById("rpe").value;'
         '    console.log("rpe=", x); '
         '    document.getElementById("rpe").labels[0].innerText = "RPE = " + x;'
         '    }}'
         '</script>'
         '</head>'
         '<body>'
         '<figure id="myfig" class="myfig">'
         '<embed class="myfig" type="image/{}" src="{}" />'
         '</figure>'
         '<form action="http://localhost:9999/backend.py" method="get">'
         '<label for="rpe">RPE = {:.1f}</label>'
         '<input type="range" id="rpe" name="rpe" onchange="getval()" value="{:.1f}" step="0.1" min="-1" max="1"><br>'
         '<input type="submit" value="Submit">'
         '</form>'
         '<script>'
         '</script>'
         '</body>'
         '</html>'.format(ft, uri, params['rpe'], params['rpe']))
    return htmlbody

def format_figures(figtype,ftype='svg',web=False,params=None):
    fn = os.path.join(tan_path, figtype+"."+ftype)
    if os.path.exists(fn):
        os.remove(fn)
        # print("* deleted old file: ", fn)
    # figdict : figure params per type of figure,
    # param list is organized like this:
    #         [ (plot rows, plot cols), figure labels (e.g. A, B, C...), ]

    figdict = {
        "DAdeftans": [(2,2), ("A1", "A2", "B1", "B2"), ],
        "tans_rpe": [(1,3), ("A", "B", "C",)],
        "tan_durs": [(1,3), ("A", "B", "C",)],
    }
    if web: figdict['tans_rpe'] = [(1,1), ("",)]
    fl = figdict[figtype]
    dirlist = [fn for fn in os.listdir(tan_path) if figtype in fn[:12]]
    imgs = [plt.imread(os.path.join(tan_path, fn)) for fn in sorted(dirlist)]
    ishape = (imgs[0].shape[0] / 100, imgs[0].shape[1] / 100)
    figsize = (ishape[0]*fl[0][1],ishape[1]*fl[0][0])
    # print(figsize)
    fig = Figure(figsize=figsize,frameon=False)
    axa = fig.subplots(nrows=fl[0][0], ncols=fl[0][1],gridspec_kw=dict(hspace=0,wspace=0),squeeze=True)
    if not any([fff>1 for fff in fl[0]]):
        title = ""
        ax = axa
        im = ax.imshow(imgs[0])
        ax.axis('off')
        ax.set_title(title, ha='left')
    elif fl[0][0]==1:
        for i in range(fl[0][1]):
            title = fl[1][i]
            ax = axa[i]
            im = ax.imshow(imgs[i])
            ax.axis('off')
            ax.set_title(title, ha='left') 
    else:
        k = 0
        for i in range(fl[0][0]):
            for j in range(fl[0][1]):
                title = fl[1][k]
                # print(title, i, j)
                ax = axa[i][j]
                im = ax.imshow(imgs[k])
                ax.axis('off')
                ax.set_title(title, ha='left')
                k += 1
    # plt.margins(0.0)
    fig.tight_layout(pad=0.)
    if not web:
        fig.savefig(fn,bbox_inches="tight",format=ftype)
        # print('saved to :', fn)
        return
    wwwtxt = web_format(fig, ftype=ftype, params=params)
    wwwfn = os.path.join(www_path, figtype+".html")
    with open(wwwfn, 'w') as wwwf:
        wwwf.write(wwwtxt)
    # print('saved to :', wwwfn)
    DEBUG = False
    if DEBUG:
        import webbrowser
        webbrowser.open('file:///'+wwwfn)
    return

def doFun(puse, time, y0):
    soln = tan_model(time,puse,y0)
    try:
        return tan_dur(time,soln[:,0],puse["t_stim"][0]), soln
    except IndexError:
        return np.inf, soln

def optFun(x, time, y0):
    # Minimize this function for rpe=1,-1,0
    # 0: 301ms; 1: 453ms; -1: 210ms
    # x=[p["w_thal"],p["drv_tan"],p["g_sahp"],p["g_da"],p["g_h"]]
    p.update({'w_thal': x[0],
              'drv_tan': x[1],
              'g_sahp': x[2],
              'g_da': x[3],
              'g_h': x[4]})
    p0 = {}
    p0.update(p)
    p0.update({'rpe': 0.0})
    tdur0, soln0 = doFun(p0, time, y0)

    p1 = {}
    p1.update(p)
    p1.update({'rpe': 1.0})
    tdur1, soln1 = doFun(p1, time, y0)
    
    pn1 = {}
    pn1.update(p)
    pn1.update({'rpe': -1.0})
    tdurn1, solnn1 = doFun(pn1, time, y0)

    tdurs = np.array([tdur0, tdur1, tdurn1])
    texpect = np.array([301, 453, 210])
    resid = np.sqrt(np.power(texpect - tdurs, 2)) +\
        np.sqrt((2.0 - soln1[:,3].max())**2.0) +\
        np.sqrt((-2.0 - solnn1[:,3].min())**2.0)
    return resid.sum()


if __name__=="__main__":

    # Run the script like this:
    # python tans.py 1.0 0 0
    
    # Command line arguments in order:
    #     RPE, DAdef, LDOPA
    
    # Optional arguments:
    #     show
    
    Nms = 5000 # number of milliseconds for the simulation to be run
    time = np.linspace(0.0, Nms, Nms)

    rpe = 0.0
    DA_def = 0.0
    LDOPA = 0.0
    show = False
    dodur = False
    doform = False
    doopt = False
    doweb = False
    ftype = 'png'

    if 'show' in sys.argv:
        show = True
    if 'dur' in sys.argv:
        dodur = True
    if 'form' in sys.argv:
        doform = True
        figtype = sys.argv[sys.argv.index('form')+1]
    if 'opt' in sys.argv:
        doopt = True
    if 'web' in sys.argv:
        doweb = True
    if 'ftype' in sys.argv:
        ftype = sys.argv[sys.argv.index('ftype')+1]
    if len(sys.argv) > 3 and all(['dur' not in sys.argv[1:],'form' not in sys.argv[1:]]):
        nonums = ['show',
                  'dur',
                  'form',
                  'opt',
                  'ftype','png','svg',
                  'web']
        rpe, DA_def, LDOPA = [float(ar) for ar in sys.argv[1:] if ar not in nonums]
    try:
        rpe = float(cgi.escape(os.environ['rpe']))
    except:
        pass
        
    da0 = 1.0 - DA_def
    p = {
        "t_stim": [2000, 2500],
        "rpe": rpe,
        "tau_tan": 20.0, # 20.0
        "w_thal": 5.5, # 4.0
        "drv_tan": 0.7, # 0.3
        "tau_sahp": 700, # 100.0,
        "g_sahp": 5.0, # 3.1
        "theta_sahp": 0.1, # 0.3
        "w_da": 1.0, # 1.0 # set to 0.0 for sulpiride
        "g_da": 89.5, # 100.0
        "tau_da": 20.0, # 20.0
        "tau_h": 700, # 700
        "theta_h": 0.1, # 0.1
        "g_h": 426.0, # 20
        "theta_da": 0.01, # 0.01
        "da_0": da0,
        "LDOPA": LDOPA,
        "DA_def": DA_def
    }

    y0 = np.array([0., 0., 0, p["da_0"]])

    if dodur:
        dur_run(time, y0, p, show=False, ftype=ftype)
    elif doform:
        format_figures(figtype,ftype=ftype,web=doweb,params=p)
    elif doopt:
        #   w_thal drv_tan g_sahp g_da g_h
        # x0 = [4.96, 0.06, 3.66, 59.0, 596.0]
        x0=[p["w_thal"],p["drv_tan"],p["g_sahp"],p["g_da"],p["g_h"]]
        res = differential_evolution(optFun,
                                     args=(time,y0),
                                     maxiter=1000, popsize=10,
                                     bounds=[(3.0, 5.5),
                                             (0.05, 0.7),
                                             (1.5, 5.0),
                                             (50.0, 300.0),
                                             (400.0, 700.0)],
                                     disp=True,
                                     tol=1.0)
        # print(res.success, res.message)
        # print('"w_thal": {:.3f}'.format(res.x[0]))
        # print('"drv_tan": {:.3f}'.format(res.x[1]))
        # print('"g_sahp": {:.3f}'.format(res.x[2]))
        # print('"g_da": {:.3f}'.format(res.x[3]))
        # print('"g_h": {:.3f}'.format(res.x[4]))
        p.update({'w_thal': res.x[0],
                  'drv_tan': res.x[1],
                  'g_sahp': res.x[2],
                  'g_da': res.x[3],
                  'g_h': res.x[4]})
        p.update({'rpe': 0.0})
        tdur0, soln0 = doFun(p, time, y0)
        p.update({'rpe': 1.0})
        tdur1, soln1 = doFun(p, time, y0)
        p.update({'rpe': -1.0})
        tdurn1, solnn1 = doFun(p, time, y0)
        tdurs = np.array([tdur0, tdur1, tdurn1])
        # print('tdurs = ', tdurs)
    else:
        soln = tan_model(time,p,y0)
        tan_plot(time,soln,p,show=show,ftype=ftype)
