# tan-model

Python implementation of TAN model

## Web
`$ python2 server.py`

## Model Output to Image
`$ python3 tans.py 1 0 0`