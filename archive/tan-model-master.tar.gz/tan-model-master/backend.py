#!/usr/bin/env python3
import cgi, os, subprocess, sys, shlex
import numpy as np
from tans import www_path, tan_path, web_format, tan_model, tan_plot
def echo(str=""):
    sys.stdout.write(str)
if __name__=="__main__":
    form = cgi.FieldStorage()
    figtype = "tans_rpe"
    echo("Content-Type: text/html")
    echo("\n\n")
    echo()
    try:
        rpe = float(cgi.escape(os.environ['rpe']))
    except KeyError as exc0:
        try:
            rpe = float(cgi.escape(form['rpe'].value))
        except KeyError as exc1:
            rpe = 0.0
    compute_cmd = "python3 tans.py {:.1f} 0 0 ftype png".format(rpe) # > /dev/null 2>&1
    html_cmd = "python3 tans.py web form {} ftype svg".format(figtype)
    for ff in os.listdir(tan_path):
        os.remove(os.path.join(tan_path, ff))
        echo("removed old file ... {}".format(ff))
    # pout = subprocess.check_output(shlex.split(compute_cmd), env={'rpe':str(rpe)})
    p = {
        "t_stim": [2000, 3000],
        "rpe": rpe,
        "tau_tan": 20.0, # 20.0
        "w_thal": 5.5, # 4.0
        "drv_tan": 0.7, # 0.3
        "tau_sahp": 700, # 100.0,
        "g_sahp": 5.0, # 3.1
        "theta_sahp": 0.1, # 0.3
        "w_da": 1.0, # 1.0 # set to 0.0 for sulpiride
        "g_da": 89.5, # 100.0
        "tau_da": 20.0, # 20.0
        "tau_h": 700, # 700
        "theta_h": 0.1, # 0.1
        "g_h": 426.0, # 20
        "theta_da": 0.01, # 0.01
        "da_0": 1,
        "LDOPA": 0,
        "DA_def": 0
    }
    time = np.linspace(0.0, 5e3, int(5e2))
    soln = tan_model(time,p,np.array([0,0,0,1]))
    fig = tan_plot(time,soln,p,show=False,ftype='svg',web=True)
    html_str = web_format(fig, ftype='svg', params=p)
    echo(html_str)
    # with open("./index.html","w") as indexf:
    #     indexf.write(html_str)
    # p1 = subprocess.check_output(shlex.split(html_cmd), env={'rpe':str(rpe)})
    # hl = []
    # with open(os.path.join(www_path, figtype+".html"),"r") as htmlf:
    #     hl = htmlf.readlines()
    # # with open("./index.html","w") as indexf:
    # #     indexf.writelines(hl)
    # for ll in hl:
    #     echo(ll)
