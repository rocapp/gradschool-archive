#!/bin/bash

python3 tans.py 1 0 0 ftype $1 &\
    python3 tans.py -1 0 0 ftype $1 &\
    python3 tans.py 0 0 0 ftype $1 &\
    python3 tans.py 1 0.5 0 ftype $1 &\
    python3 tans.py -1 0.5 0 ftype $1 &\
    python3 tans.py 1 0.5 0.5 ftype $1 &\
    python3 tans.py -1 0.5 0.5 ftype $1 &
