#!/bin/bash

# Compute and plot traces, save to HTML
: ${rpe=1.0}
python3 tans.py $rpe 0 0 ftype png  > /dev/null 2>&1
python3 tans.py web form tans_rpe ftype svg > /dev/null 2>&1

