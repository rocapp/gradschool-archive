#!/usr/bin/python
import numpy as np
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import os, sys

if __name__=="__main__":
    weights = np.loadtxt(sys.argv[1])
    fig= plt.figure()
    im=plt.imshow(np.atleast_2d(weights),extent=(0, weights.size, 0, weights.size))
    plt.colorbar(im)
    plt.xlabel("Action")
    plt.yticks([],[])
    fname = os.path.join(os.environ["CARDIO_FIG"],
                         "fig_{}.png".format(sys.argv[1].split("/")[-1].split(".")[0]))
    plt.savefig(fname)
    print(fname)
    plt.close()
