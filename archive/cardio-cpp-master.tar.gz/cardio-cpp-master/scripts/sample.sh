#!/bin/bash
# args: $1=SID , $2=NRP
export -p SID=$1 TESTS=test_sampler_mp H5=1 MPI=1 CONFIG=./config/$1.ini NRP=$2
cd /home/rocapp/Git/cardio-cpp && make runtestmp
