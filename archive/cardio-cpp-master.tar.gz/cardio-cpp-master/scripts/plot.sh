#!/bin/sh

cmds="simplot='$CARDIO_WEB/$1.svg';ltvplot='$CARDIO_OUT/ltv_$1.cardio'"
cmds="$cmds;bpplot='$CARDIO_OUT/bp_$1.cardio'"
cmds="$cmds;svplot='$CARDIO_OUT/stroke_vol_$1.cardio'"
cmds="$cmds;rsaplot='$CARDIO_OUT/hrri_$1.cardio'"
cmds="$cmds;mtitle='$1'"
cmds="$cmds;outname='${1//-/0}'"
gnuplot -e $cmds $CARDIO_SRC/scripts/plot.gnu
