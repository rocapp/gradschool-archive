import subprocess
import json
import os
import numpy as np
import sys
import time

make_path = "/home/rocapp/Git/cardio-cpp"
jpath = "/home/rocapp/Public/sepsis_records/records_check.json2018-08-08"
jpath_orig = os.path.join(make_path, "records_original.json")
os.chdir(make_path)

def updateRecords(newdict):
    with open(jpath, "w") as f:
        json.dump(newdict, f)
    print("Records json updated.\n")


if __name__ == "__main__":

    oflag = False
    if len(sys.argv[1:]) > 0:
        if len(sys.argv[1:]) == 1:
            if sys.argv[1] == 'o':
                oflag = True
                print("\n===OFLAG ENABLED===\n")
                time.sleep(5)

    with open(jpath, "r") as f:
        rdict = json.load(f)

    lookin = [None,True,False,'Fig']
    if oflag: lookin = [True,'Fig']

    lookin = [None,False]

    for jk, jv in rdict.items():

        if jv[1] in lookin:
        
            print("\nmaking figures for records : ", jk)

            ti = 0
            for ir, rec in enumerate(jv[0]):
                if (ti != 0 or ir != len(jv[0])):
                    print("--> ", rec)
                    try:
                        if not oflag:
                            cmd = "TESTS=test_hdf5 H5=1 SID={} CONFIG=./config/config_000.ini make runtest".format(rec)
                            pcomp = subprocess.run(cmd, shell=True, check=True, stderr=subprocess.PIPE)
                        elif oflag:
                            sid = rec.replace("_", "-")
                            cmd = "python3.6 scripts/plot.py {}".format(sid)
                            pcomp = subprocess.run(cmd, shell=True, check=True, stderr=subprocess.PIPE)
                        rdict[jk][1] = "Fig"
                        updateRecords(rdict)
                        ti += 1
                    except subprocess.CalledProcessError as Ex:
                        print("\n",rec," failed...\n")
                        if oflag:
                            print(Ex)

            if ti == 0:
                rdict[jk][1] = None
            elif ti > 0 and ti < 2:
                rdict[jk][1] = False
            
            updateRecords(rdict)

                
    
