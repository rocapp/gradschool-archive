#!/usr/local/bin/python3.6
import numpy as np

import matplotlib as mpl
mpl.use("Agg")

mpl.rcParams['figure.titlesize'] = 24
mpl.rcParams['figure.figsize'] = (12,12)
mpl.rcParams['figure.dpi'] = 100 #300

mpl.rcParams['figure.subplot.hspace'] = 0.05

mpl.rcParams['savefig.bbox'] = 'tight'

axfontsize = 18
mpl.rcParams['axes.labelsize'] = axfontsize
mpl.rcParams['axes.titlesize'] = axfontsize+4

tickfontsize = 14
mpl.rcParams['xtick.labelsize'] = tickfontsize
mpl.rcParams['ytick.labelsize'] = tickfontsize

import matplotlib.pyplot as plt
from matplotlib.patches import ConnectionPatch

import sys, os, subprocess
import plot as psrc
from stats import cauchy_quantile, cauchy_cdf, compute_mad, ks2sample, ks2_compute_pvalues, fit_rsa
import utils

def get_signal_per_subject(plt_dict, signame):
    dat = []
    for ei, ekey in enumerate(["pre","dur","post"]):
        dat.append([])
        for dep in plt_dict[ekey][signame]:
            dat[ei].append(np.array(dep[2],dtype='float'))
    return dat

def binned_aves(signame, timevec, signal, plt_dict, tbins, sigstds=None):
    # Form a dictionary of averages, errors, signals
    if signame=="rsa":
        rphase, timevec = timevec
        qcomps, signal = signal
    preix = np.where((timevec >= tbins[0][0]) & (timevec < tbins[0][1]))[0]
    presig = signal[preix]
    durix = np.where((timevec >= tbins[1][0]) & (timevec < tbins[1][1]))[0]
    dursig = signal[durix]
    postix = np.where((timevec >= tbins[2][0]) & (timevec < tbins[2][1]))[0]
    ixs = np.array([preix, durix, postix])
    postsig = signal[postix]
    sigs = np.array([presig, dursig, postsig])
    preave = np.mean(presig)
    durave = np.mean(dursig)
    postave = np.mean(postsig)
    ave = np.array([preave, durave, postave])
    prestd = compute_mad(presig)
    durstd = compute_mad(dursig)
    poststd = compute_mad(postsig)
    stds = np.array([prestd, durstd, poststd])
    if signame=="rsa":
        for ri, av in enumerate(ave):
            rix = np.argsort(rphase[ixs[ri]])
            p0 = [qcomps[0], qcomps[1], qcomps[2]]
            opt, rerr = fit_rsa(rphase[ixs[ri]][rix], signal[ixs[ri]][rix], p0)
            ave[ri] = np.linalg.norm(opt)
            stds[ri] = np.mean([rerr[rei]/p0[rei] for rei in np.arange(rerr.size)])
    plt_dict["pre"][signame].append( ( ave[0], stds[0], presig ) )
    plt_dict["dur"][signame].append( ( ave[1], stds[1], dursig ) )
    plt_dict["post"][signame].append( ( ave[2], stds[2], postsig ) )
    return plt_dict

def convert_to_stderr(tlabel, slabel, data_plt):
    # given the standard deviation for each subject, convert to a scalar population standard error
    signal_all_subjects = np.array([sigave[0] for sigave in data_plt[tlabel][slabel]])
    N = signal_all_subjects.size
    popave = np.median(signal_all_subjects)
    stderr = compute_mad(signal_all_subjects) / np.sqrt(N)
    return popave, stderr

subject_names = [
    "S1-WQ-10-25-10-Erica",
    "S2-ML-10-28-10-Erica",
    "S3-TW-10-28-10-Erica",
    "S4-AK-01-18-11-Erica",
    "S5-BT-01-20-11-Erica",
    "S6-CC-3-15-11-Erica",
    "S7-JT-5-20-11-Erica",
    "S8-CR-06-20-11-Erica",
    "S9-ZM-8-4-11-Erica",
    "S10-SV-8-19-11-Erica"
]
time_bins = dict((sname, []) for sname in subject_names)
nwins = {}
nrwins = 30
data_plt = dict(pre={}, dur={}, post={})
cdf_dict = dict(pre={}, dur={}, post={})
signal_names = []

from scipy.stats import linregress

def load_erica_subjects(do_processing=False, only_proc=False):

    for sk in list(time_bins.keys()): # load condwins from .ini config file
        cwins = psrc.parse_cond_wins(sk)
        time_bins[sk] = [cwins["prewin"], cwins["durwin"], cwins["postwin"]]
        nwins[sk] = nrwins

    ### Data to Use ###
    for k in data_plt.keys(): # stored as data_plt["pre"]["signal"]
        data_plt[k] = dict(rsa=[],rri=[],bp=[],bpmod=[])
    bpmaves = []
    bpmsaves = []
    rsaaves = []
    snrs = []
    # Load each subject
    for sid in subject_names:
        tbins = time_bins[sid]
        psrc.NR_WINS = nwins[sid]
        print(sid, "nwins=", psrc.NR_WINS)
        if do_processing:
            print("\n## processing subject... ##\n")
            # data routine for each subject
            completed = utils.process_subject(sid)
            print("plotting subject-specific stuff...")
            utils.plot_subject(sid) #plots=["hcvcphase","bp","rsaseg"])
            print("\n## done processing subject. ##\n")
            if only_proc:
                bpmaves.append(np.loadtxt(psrc.save_path("{}/_{}_BPMresp.txt".format(sid,sid))))
                bpmsaves.append(np.loadtxt(psrc.save_path("{}/_{}_BPMsynthresp.txt".format(sid,sid))))
                rsaaves.append(np.loadtxt(psrc.save_path("{}/_{}_RSAconds.txt".format(sid,sid))))
                continue
        else:
            # utils.plot_subject(sid,plots=["rsaseg"])
            bpmaves.append(np.loadtxt(psrc.save_path("{}/_{}_BPMresp.txt".format(sid,sid))))
            bpmsaves.append(np.loadtxt(psrc.save_path("{}/_{}_BPMsynthresp.txt".format(sid,sid))))
            rsaaves.append(np.loadtxt(psrc.save_path("{}/_{}_RSAconds.txt".format(sid,sid))))
            snrs.append(int(sid.split("-")[0][1:]))
            # print("  --> SID =", snrs[-1], "BPM =", bpmaves[-1], "RSA = ", rsaaves[-1])
        
        if not only_proc:
            # BP
            if "bp" in data_plt["pre"].keys():
                time = psrc.loadf(sid, "time")
                bpsig = psrc.loadf(sid, "bp")
                bpwin=np.int(bpsig.size/psrc.NR_WINS)
                bpskip=int(bpwin*0.1)
                bptime, bpmeds, bperrs = psrc.median_filt(time, bpsig, bpwin, skipix=bpskip)
                if np.sum(np.isnan(bpmeds))==0 and np.sum(np.isnan(bperrs))==0 and bpmeds.size > 2 and bpmeds.mean() > 0:
                    binned_aves("bp", bptime, bpmeds, data_plt, tbins)
            # BP Modulation
            if "bpmod" in data_plt["pre"].keys() and "S5" not in sid:
                svdiff = psrc.loadf(sid,"bpsysdiff")
                svtime = psrc.loadf(sid,"bpsystime")
                svspace, svmeds, sverr = psrc.make_signal_length_equal(svtime, svdiff, bpmeds.size, psrc.NR_WINS)
                if not np.isnan(svmeds).any() and not np.isnan(sverr).any() and svmeds.size > 2 and svmeds.mean() > 0:
                    print(svmeds.mean())
                    binned_aves("bpmod", svspace, svmeds, data_plt, tbins)
                    print(sid, data_plt["pre"]["bpmod"][-1][0], data_plt["dur"]["bpmod"][-1][0], data_plt["post"]["bpmod"][-1][0])
            if "bplen" in data_plt["pre"].keys():
                pass
            # RESP
            if "rdur" in data_plt["pre"].keys():
                rdtime = psrc.loadf(sid,"timeresp")
                rdur = psrc.loadf(sid, "respdur")
                binned_aves("rdur", rdtime, rdur, data_plt, tbins)
            # IDUR
            if "idur" in data_plt["pre"].keys():
                idur = psrc.loadf(sid,"linspdur")
                binned_aves("idur",rdtime,idur,data_plt,tbins)
            if "edur" in data_plt["pre"].keys():
                # EDUR
                edur = psrc.loadf(sid,"lexpdur")
                binned_aves("edur",rdtime,edur,data_plt,tbins)
            # CVC
            if "cvc" in data_plt["pre"].keys():
                # DIRECT CALCULATION Beats->Insp
                cvctimes = psrc.loadf(sid, "timecvc")
                cvcdiffs = psrc.loadf(sid, "hcvcphase")
                binned_aves("cvc", cvctimes, cvcdiffs, data_plt, tbins)
            # RSA
            if "rsa" in data_plt["pre"].keys() and "S6" not in sid:
                tbeat = psrc.loadf(sid, "timebeat")
                rphase = psrc.loadf(sid, "hrsaphaseR")
                rdiff = psrc.loadf(sid, "hrridiffR")
                qcomps = psrc.loadf(sid, "qcomps")
                binned_aves("rsa", [rphase,tbeat], [qcomps,rdiff], data_plt, tbins)
                # qtime = np.loadtxt(os.path.join(psrc.cardio_dir, "qtime_{}.cardio").format(sid),dtype='float64')
                # Qarr = np.loadtxt(os.path.join(psrc.cardio_dir, "Q_{}.cardio").format(sid),dtype='float64',delimiter=",", ndmin=2)
                # binned_aves("rsa", [qtime,tbeat], [Qarr[:,0],rdiff], data_plt, tbins)
            # Stroke Volume
            if "svl" in data_plt["pre"].keys():
                svol = psrc.loadf(sid, "stroke_vol")
                svtime = psrc.loadf(sid, "svtime")
                binned_aves("svl", svtime, svol, data_plt, tbins)
            # RRI
            if "rri" in data_plt["pre"].keys():
                rri = psrc.loadf(sid,"hrri")
                tbeat = psrc.loadf(sid,"timebeat")
                tbix = np.argsort(tbeat)
                tbeat = tbeat[tbix]
                rri = rri[tbix]
                binned_aves("rri",tbeat,rri,data_plt,tbins)
    if only_proc:
        print("### done with processing for all loaded subjects. ###")
        print("plotting BPM, BPMs vs RSA...")
        print([bb.shape for bb in bpmaves])
        fig, axs = plt.subplots(ncols=2, figsize=(36,12))
        plt.suptitle("BPM, BPMsynth, RSA (SDB, Baseline)", fontsize=14,ha="center",x=0.05)
        # Order of indices: sii, eix, [phase, mag]
        Xrsa, Ybpm, Ybps = [], [], []
        Prsa, Pbpm, Pbps = [], [], []
        for sii in range(len(bpmaves)):
            print("comparing bpm, rsa (sdb vs base) for subject", sii)
            rsax = rsaaves[sii][1][1] - rsaaves[sii][0][1]
            if rsax > 0:
                Xrsa.append(rsax)
                rsap = rsaaves[sii][1][0] - rsaaves[sii][0][0]
                Prsa.append(rsap)
                bpmp = np.abs(bpmaves[sii][1][0] - bpmaves[sii][0][0])
                if bpmp > 0.8: bpmp = 1.0 - bpmp
                Pbpm.append(bpmp)
                bpmy = bpmaves[sii][1][1] - bpmaves[sii][0][1]
                Ybpm.append(bpmy)
                bpsp = np.abs(bpmsaves[sii][1][0] - bpmsaves[sii][0][0])
                if bpsp > 0.8: bpsp = 1.0 - bpsp
                Pbps.append(bpsp)
                bpsy = bpmsaves[sii][1][1] - bpmsaves[sii][0][1]
                Ybps.append(bpsy)
                print(rsaaves[sii][[0,1]])
                axs[0].errorbar(rsax, bpmy,
                             xerr=np.mean(rsaaves[sii][[0,1]][:,2]),
                             yerr=np.mean(bpmaves[sii][[0,1]][:,2]),
                             color='k', ecolor='r',
                             linestyle='', marker='o',
                             ms=20, label="BPM(nat)")
                axs[0].errorbar(rsax, bpsy,
                                xerr=np.mean(rsaaves[sii][:2][:,2]),
                                yerr=np.mean(bpmsaves[sii][:2][:,2]),
                                color='b', ecolor='c', alpha=0.7,
                                linestyle='', marker='o',
                                ms=20, label="BPM(synth)")
                xys, ys = 0.984, 0.984
                axs[0].annotate("{:02d}".format(snrs[sii]),
                                xy=(rsax*xys, bpmy*ys),
                                color=(0, 1, 0.2, 1))
                axs[0].annotate("{:02d}".format(snrs[sii]),
                                xy=(rsax*xys, bpsy*ys),
                                color=(1, 1, 0.2, 1))
                # Phase plot
                axs[1].plot(np.cos(rsap), np.sin(bpmp), color='k', marker='o', ms=20)
                axs[1].plot(np.cos(rsap), np.sin(bpsp), color='b', marker='o', ms=20, alpha=0.7)
                print(np.cos(rsap), np.sin(bpmp), np.sin(bpsp))
                axs[1].annotate("{:02d}".format(snrs[sii]),
                                xy=(np.cos(rsap), np.sin(bpmp)),
                                color=(0, 1, 0.2, 1))
                axs[1].annotate("{:02d}".format(snrs[sii]),
                                xy=(np.cos(rsap), np.sin(bpsp)),
                                color=(1, 1, 0.2, 1))
        Xrsa, Ybpm, Ybps = np.array(Xrsa), np.array(Ybpm), np.array(Ybps)
        Prsa, Pbpm, Pbps = np.array(Prsa), np.array(Pbpm), np.array(Pbps)
        # Nat BP vs rsa
        Mxy, Bxy, rxy, pxy, errxy = linregress(Xrsa, Ybpm)
        yfit = Mxy*Xrsa + Bxy
        axs[0].plot(Xrsa, yfit, color='k', linestyle='--', label='linreg(nat)')
        # Synth BP vs rsa
        Mxy1, Bxy, rxy, pxy1, errxy = linregress(Xrsa, Ybps)
        yfit = Mxy1*Xrsa + Bxy
        axs[0].plot(Xrsa, yfit, color='b', linestyle='--', label='linreg(Synth)')
        from scipy.stats import spearmanr
        Sxm, pxm = spearmanr(Xrsa, Ybpm)
        Sxs, pxs = spearmanr(Xrsa, Ybps)
        axs[0].annotate("{:.2f} (p={:.2f})".format(Mxy,pxy),
                        color='k',
                        xy=(0.02, 1.5))
        axs[0].annotate("{:.2f} (p={:.2f})".format(Mxy1,pxy1),
                        color='b',
                        xy=(0.06, 0.5))
        axs[0].set_xlabel("RSA Amp (SDB - Baseline)")
        axs[0].set_ylabel("BPM Amp (SDB - Baseline)")
        axs[0].legend()
        axs[1].set_xlabel("RSA Phase (SDB - Baseline)")
        axs[1].set_ylabel("BPM Phase (SDB - Baseline)")
        axs[1].set_ylim([0, 1])
        # axs[eix].set_xlim([0.0, 0.12])
        # axs[eix].set_ylim([0.1, 3.9])
        figsavepath=psrc.save_path("{}/_{}.svg".format("EricaAnalysis","BPMvsRSA"))
        plt.savefig(figsavepath)
        plt.savefig(figsavepath.replace(".svg",".png"))
        plt.close()
        print("saved BPM vs RSA figure to {}".format(figsavepath))
        sys.exit(0)

def compute_cdfs():
    for sigk in signal_names:
        data = get_signal_per_subject(data_plt, sigk)
        pre_data, dur_data, post_data = data
        cdf_dict["pre"][sigk] = []
        cdf_dict["dur"][sigk] = []
        cdf_dict["post"][sigk] = []
        for subjx in np.arange(len(pre_data)):
            cdf_dict["pre"][sigk].append(cauchy_cdf(np.median(pre_data[subjx]),
                                                    compute_mad(pre_data[subjx]),
                                                    pre_data[subjx]))
            cdf_dict["dur"][sigk].append(cauchy_cdf(np.median(dur_data[subjx]),
                                                    compute_mad(dur_data[subjx]),
                                                    dur_data[subjx]))
            cdf_dict["post"][sigk].append(cauchy_cdf(np.median(post_data[subjx]),
                                                     compute_mad(post_data[subjx]),
                                                     post_data[subjx]))

            
if __name__=="__main__":
    
    ### Save Directory ###
    savedir = psrc.save_path("EricaAnalysis")
    if not os.path.exists(savedir):
        os.mkdir(savedir)
    psrc.sample_rate = 100 # sampling frequency for Erica Dataset
    
    do_processing = False
    only_proc = False # only process each subject, then end the program
    doneflag = True # if true, skips calculation of bounds (i promise you *do* want to skip! lol)
    dlimit = 5
    if len(sys.argv) > 1: # check for cmdline arguments: true/false (perform data routine)
        do_processing = (sys.argv[1].lower() in ["1", "true"])
        print("do_processing",do_processing)
        if "only_proc" or "onlyproc" in sys.argv:
            only_proc = True # check for "only_proc" in args
        # if len(sys.argv) > 2:
        #     doneflag = not (sys.argv[2].lower() in ["1", "true"])
        #     print("doneflag",doneflag)
        # if len(sys.argv) > 3:
        #     dlimit = float(sys.argv[3])
        #     print("dlimit",dlimit)

    dii = 0
    while not doneflag:
        print("### loading subjects...")
        if dii==0: # Load Erica Subjects
            load_erica_subjects(do_processing=do_processing, only_proc=only_proc)
        else:
            load_erica_subjects(do_processing=True, only_proc=only_proc)
        signal_names = list(list(data_plt.values())[0].keys())
        N = len(list(time_bins.keys())) # population N (nr subjects)
        compute_cdfs() # Calculate CDFs (1 per epoch / subject)
        doneflags = []
        for sigk in signal_names:
            for epoch in list(cdf_dict.keys()):
                for subjx, sid in enumerate(subject_names):
                    cdf1 = cdf_dict[epoch][sigk][subjx][1]
                    cdf2 = np.linspace(0, 1, len(cdf1))
                    newbounds = utils.ks2_determine_bounds(sid, time_bins[sid], cdf1, len(cdf1), cdf2, len(cdf2),
                                                           alpha=0.05, increment=0.05)
                    doneflags.append(newbounds==time_bins[sid])
                    if newbounds != time_bins[sid]:
                        print("-->", subjx, "newbounds=", newbounds)
                        time_bins[sid] = newbounds
                        utils.update_bounds(sid, time_bins[sid], boundnames=["prewin","durwin","postwin"])
        doneflag = all(doneflags) or (dii >= dlimit)
        dii+=1
        print("iteration {}".format(dii))

    # print("done determining bounds!")

    # Load with correct bounds
    load_erica_subjects(do_processing=do_processing, only_proc=only_proc) # Load Erica Subjects
    signal_names = list(list(data_plt.values())[0].keys())
    N = len(list(time_bins.keys())) # population N (nr subjects)

    # Plot Population Averages as bar plots
    fig, axs = plt.subplots(nrows=len(signal_names),figsize=(2.5,15)) # one row per signal
    index = np.arange(3) # one index for each time
    bar_width = 0.4
    barlabels = {"rdur": "Resp. period (sec)",
                 "rsa": "RSA (sec)",
                 "bp": "mmHg",
                 "bpmod": "mmHg",
                 "rri": "RRI (sec)"}
    for aix, sigk in enumerate(signal_names): # iterate through signals
        axs[aix].set_ylabel(barlabels[sigk], fontsize=16)
        # Get data, calculate averages, stderrs
        preave, preerr = convert_to_stderr("pre", sigk, data_plt)
        durave, durerr = convert_to_stderr("dur", sigk, data_plt)
        postave, posterr = convert_to_stderr("post", sigk, data_plt)
        np.savetxt(os.path.join(os.environ.get("CARDIO_OUT"), "{}_EricaAnalysisGroupAve.txt".format(sigk)),
                   np.array([[preave, durave, postave], [preerr, durerr, posterr]]))
        print("population", sigk, "error=", preerr, durerr, posterr)
        # Plot Averages
        rects = axs[aix].bar(index, [preave, durave, postave], bar_width,
                             facecolor="grey", edgecolor='k', color=(1,1,1,0),
                             yerr=[preerr, durerr, posterr],
                             error_kw=dict(ecolor='k',elinewidth=2.0), capsize=1.0)
        minscale = 1.25
        miny = preave-preerr*minscale
        if miny > durave-durerr:
            miny = durave-durerr*minscale
        if miny > postave-posterr:
            miny = postave-posterr*minscale
        if miny < 0: miny = 0
        if np.isnan(miny): miny = 0
        axs[aix].set_xticks(index)
        axs[aix].set_ylim(bottom=miny, top=(np.array([preave, durave, postave])+np.array([preerr, durerr, posterr])).max())
        axs[aix].tick_params(axis='y', labelsize=9)
        axs[aix].set_xticklabels(('Baseline', 'SDB', 'Post-SDB'), fontsize=9)
        axextent = axs[aix].get_window_extent().transformed(fig.dpi_scale_trans.inverted())
        fig.savefig(os.path.join(savedir, "_{}_EricaAnalysis.svg".format(sigk)),
                    bbox_inches=axextent.expanded(2.0, 1.25))
        fig.savefig(os.path.join(savedir, "_{}_EricaAnalysis.png".format(sigk)),
                    bbox_inches=axextent.expanded(2.0, 1.25))
    fig.tight_layout(h_pad=0.2)
    savepath = os.path.join(savedir, "_EricaAnalysis_{}.svg".format("BarCharts"))
    plt.savefig(savepath)
    print("bar chart saved to: ", savepath)
    savepath = os.path.join(savedir, "_EricaAnalysis_{}.png".format("BarCharts"))
    plt.savefig(savepath)
    plt.close()
    print("bar chart saved to: ", savepath)
    
    compute_cdfs() # Calculate CDFs (1 per epoch / subject)
        
    # Compute P-values using CDFs
    pvalues = ks2_compute_pvalues(cdf_dict, list(cdf_dict.keys()),
                                  np.linspace(0.01, 0.999, int(1e3)), signal_names)

    for subjx in np.arange(len(cdf_dict["pre"]["rsa"])):
        # Plot CDFs per subject
        fig, axs = plt.subplots(nrows=len(signal_names),ncols=3) # one row per signal, one col per "epoch"
        plt.suptitle("{}".format(subject_names[subjx]), x=0.05, y=0.98, fontsize=15)
        epochs = ["pre","dur","post"]
        for aix, sigk in enumerate(signal_names): # iterate through signals
            for eix, ename in enumerate(epochs):
                # print(subjx, sigk, ename, cdf_dict[ename][sigk][subjx][0].size, cdf_dict[ename][sigk][subjx][1].size)
                try:
                    axs[aix][eix].set_title("{} {} N={:d} p={:.2f}".format(sigk.upper(), ename,
                                                                           len(cdf_dict[ename][sigk][subjx][1]),
                                                                           pvalues[sigk][(ename, "unif", subjx)]),fontsize=12)
                    axs[aix][eix].plot(cdf_dict[ename][sigk][subjx][0], cdf_dict[ename][sigk][subjx][1], 'b.', rasterized=True)
                except (KeyError,IndexError) as kexcep:
                    print(kexcep)
                    if "KeyError" in str(kexcep):
                        axs[aix][eix].set_title("{} {} N={:d} p=Unif".format(sigk.upper(), ename,len(cdf_dict[ename][sigk][subjx][1]),),fontsize=12)
                    elif "IndexError" in str(kexcep):
                        axs[aix][eix].set_title("signal not available")
        fig.tight_layout()
        plt.savefig(os.path.join(savedir, "_EricaAnalysisCDF_{:d}.svg".format(subjx+1)))
        plt.savefig(os.path.join(savedir, "_EricaAnalysisCDF_{:d}.png".format(subjx+1)))
        plt.close()

        # Plot Box-Whisker Plots per epoch, per subject
        print("plotting boxplots...",subjx)
        fig, axs = plt.subplots(nrows=len(signal_names))
        plt.suptitle("{}".format(subject_names[subjx]), x=0.1, y=0.98, fontsize=18)
        for aix, sigk in enumerate(signal_names):
            axs[aix].set_title("{}".format(sigk.upper(),),fontsize=16)
            try:
                axs[aix].boxplot([cdf_dict[ename][sigk][subjx][0] for eix, ename in enumerate(epochs)],
                                 labels=["Pre", "SDB", "Post"])
                for eix, ename in enumerate(epochs):
                    for eix2, ename2 in enumerate(epochs+["unif"]):
                        if eix!=eix2:
                            try:
                                axs[aix].text(x=float(eix+0.05)/len(epochs), y=float((1+eix2)*0.5)/(len(epochs)),
                                              s="p_{}={:.2f}".format(ename2,pvalues[sigk][(ename, ename2, subjx)]),
                                              transform=axs[aix].transAxes)
                            except KeyError as kexcep:
                                print(kexcep)
            except IndexError as iexc:
                print(iexc)
        fig.tight_layout(h_pad=2.0,w_pad=1.5)
        plt.savefig(os.path.join(savedir, "_EricaAnalysisBoxPlot_{}.svg".format(subject_names[subjx].split("-")[0])))
        plt.savefig(os.path.join(savedir, "_EricaAnalysisBoxPlot_{}.png".format(subject_names[subjx].split("-")[0])))
        plt.close()

    # Combine Erica Plots
    pdf_cmd = 'convert "{}/*.{{png}}" -quality 100 {}/00_EricaAnalysis.pdf'.format(savedir,savedir)
    pdf_complete = utils.run_command(pdf_cmd)
    print(pdf_complete.stdout)
