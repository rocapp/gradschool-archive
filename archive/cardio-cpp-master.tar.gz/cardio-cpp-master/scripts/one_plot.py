#!/usr/local/bin/python3.6
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import wfdb
import os
import numpy as np

# Load a single wfdb file

db_path = os.path.expanduser("~/Public/SepsisData") # path to wfdb files
# db_path = os.path.expanduser("~/Public/mghdb")
# db_path = os.path.expanduser("~/Public/prcp")

# recs = os.listdir(db_path)
# recs = [os.path.splitext(r)[0] for r in recs]
# recs = list(set(recs))
# recs = [r for r in recs if r.count("_") == 1]
# recs = sorted(recs)

# recs = ["12726",]
# recs = ["mgh152",] # record to load
# recs = ["A012-0447461450_0007","A012-0447461450_0008"] #"A084-0380661247_0014" A012-0447461450_0007 mgh005
# "A065-0408757787_0027", "A065-0408757787_0028"
recs = ["A006-0360249162_0004"]

out_path = os.path.expanduser("~/public_html/sepsis_data/figs/{}_rawplot")
out_fn = "_{}_rawplot_{}.svg"
for rec in recs:
    try:
        # channel_names = ["ECG","ABP","Angle",]
        # channel_names = ["ECG lead II","Resp. Imp.",] # mgh
        channel_names = ["II","V","CO2","SPO2",
                         "CVP3","PA2","AR1",
                         "CVP2"] # sepsis_nemati

        sigs, fields = wfdb.io.rdsamp(os.path.join(db_path, rec), channel_names=channel_names)
        print(fields)

        out_path = out_path.format(rec)
        if not os.path.exists(out_path):
            os.mkdir(out_path)

        sigl = []
        for j in range(sigs.shape[1]):
            sigc = sigs[:,j]
            print(channel_names[j], "pre_nan_size=", sigc.size)
            sigl.append(sigc[~np.isnan(sigc)])
            print(channel_names[j], "post_nan_size=", sigl[j].size)
            
        for ci, cn in enumerate(channel_names):
            print("  >", cn)
            out_fn1 = out_fn.format(rec,cn)
            out_path1 = os.path.join(out_path, out_fn1)
            sig = sigl[ci]
            # if cn == "V": sig = np.abs(sig)*np.abs(sigl[1])
            # smn = sig.mean() if cn != "SPO2" else 100 - sig[26000*fields['fs']:].mean()
            # print(rec, cn, sig.size, 'ave', smn,"+-",sig.std())
            time = np.linspace(0, sig.size / fields['fs'], sig.size)
            plt.figure()
            plt.suptitle("{} {}".format(rec,cn))
            plt.subplot(211)
            plt.plot(time, sig, color="b", label=cn)
            plt.subplot(212)
            ix_zoom = 0*fields['fs'] # to
            offset = 100*fields['fs'] # from
            plt.plot(time[offset:offset+ix_zoom], sig[offset:offset+ix_zoom])
            plt.xlabel("time (sec)")
            plt.savefig(out_path1)
            plt.close()
    except IndexError as E:
        print(E)
        pass
