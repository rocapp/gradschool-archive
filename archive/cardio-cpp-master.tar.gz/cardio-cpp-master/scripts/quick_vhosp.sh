#!/bin/bash
echo "Experimental"
VHOSP=TEST TESTW0=1573583500 ./test_vhosp_nocuda -f config/test-model-vhosp-septest.ini
sleep 2;

echo "Control"
VHOSP=TEST TESTW0=000000 ./test_vhosp_nocuda -f config/test-model-vhosp-septest.ini
sleep 1;

echo "done."
