#!/usr/bin/python
import os, sys
import numpy as np
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt

def sig2arr(rlines, sign):
    arr = np.array([float(l.split("{}".format(sign))[1].split(" ")[0])\
                    for l in rlines if sign in l])
    print(sign, np.mean(arr), np.std(arr))
    return arr

if __name__=='__main__':
    with open(sys.argv[1],"r") as ff:
        rlines = ff.readlines()[1:]
    
    nsurv = sum([float(l.split("survival: ")[-1]) for l in rlines if "survival" in l])
    print(nsurv)

    sdict = {}
    sdict["surv"] = sig2arr(rlines, "survival: ")
    print(sdict["surv"])
    sdict["rri"] = sig2arr(rlines, "RRI=")
    sdict["resp"] = sig2arr(rlines, "RESP=")
    sdict["insp"] = sig2arr(rlines, "INSP=")
    sdict["expir"] = sig2arr(rlines, "EXP=")
    sdict["bp"] = sig2arr(rlines, "BP=")
    sdict["aerr"] = sig2arr(rlines, "AERR=")
    sdict["act"] = sig2arr(rlines, "action: ")
    sdict["iter"] = sig2arr(rlines, "iter ")

    print("Mean error:",np.mean(sdict['aerr']), "+-", np.std(sdict['aerr']))

    fig, axs = plt.subplots(nrows=7) #len(list(sdict.keys())))
    plt.suptitle(sys.argv[1].split("/")[-1].split(".")[0])
    axs[0].plot(sdict["iter"], sdict["aerr"], color='k', ls="-", marker=".",label="Err")
    axs[0].set_ylabel("err")
    axs[1].plot(sdict["iter"], sdict["resp"], color='b', ls="-", marker=".",label="Resp")
    axs[1].set_ylabel("resp")
    axs[2].plot(sdict["iter"], sdict["insp"], color='b', ls="-", marker=".",label="Insp")
    axs[2].set_ylabel("insp")
    axs[3].plot(sdict["iter"], sdict["expir"], color='b', ls="-", marker=".",label="Expir")
    axs[3].set_ylabel("expir")
    axs[4].plot(sdict["iter"], sdict["act"], color='g', ls="-", marker=".",label="Action")
    axs[4].set_xlabel("iter")
    axs[4].set_ylabel("act")
    axs[5].plot(sdict["iter"], sdict["bp"], color='r', ls='-', marker='o', label="bp")
    axs[5].set_ylabel('bp')
    plt.xticks(sdict['iter'])
    plt.xlabel("iter")
    # axs[-1].imshow(np.atleast_2d(1.0-sdict["surv"]), cmap="binary", extent=(sdict["iter"][0], sdict["iter"][-1], 0.0, 1.0))
    axs[-1].bar(sdict["iter"], sdict["surv"])
    fname = os.path.join(os.environ["CARDIO_FIG"],
                         "fig_{}.png".format(sys.argv[1].split("/")[-1].split(".")[0]))
    plt.savefig(fname)
    print(fname)
    plt.close()
