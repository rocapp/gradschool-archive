#!/bin/bash

# Virtual hospital simulation script

# ** Before Running: **
# Compile test_model and test_vhosp:
#  `cd $CARDIO_SRC && TESTS=test_model make`
#  `cd $CARDIO_SRC && TESTS=test_hosp make`

# *** Remember! *** : move any old logs/weights into another directory to avoid issues with this script!


#
# ...Virtual Hospital Simulation...

## Initial Training Phase
#  *Note* : the "goal breathing pattern" is the only difference between "experimental" and "control"

# Train the "experimental" subject at baseline health (Physiotherapy training)
echo "\n\n Experimental Training Simulation begin. \n"
sleep 2;
VHOSP=TRAIN $CARDIO_SRC/test_vhosp_nocuda -f $CARDIO_SRC/config/test-model-vhosp.ini

sleep 2;

## Testing Phase (Shock Trials)
export TESTW0=$(ls -ct $CARDIO_SRC/virtual_hosp_logs/Wvhosp*.cardio | head -1 | grep -oP "[0-9]*") # experimental 
export TESTW1=000000 # control

# Pseudo-train the "control" subject at baseline health (No Physiotherapy training)
python -c $'import random\nfor i in range(50): print(random.uniform(0.0,1.0))' > $CARDIO_SRC/virtual_hosp_logs/Wvhosp_vhosp_000000.cardio
sleep 2

echo "\n\n Experimental Test Simulation Weights : ${TESTW0} \n"
echo "\n\n Control Test Simulation Weights : ${TESTW1} \n"
sleep 2

# Test the "experimental" subject during septic shock
VHOSP=TEST TESTW0=$TESTW0 \
     $CARDIO_SRC/test_vhosp_nocuda -f $CARDIO_SRC/config/test-model-vhosp-septest.ini

sleep 1

# Test the "control" subject during septic shock
VHOSP=TEST TESTW0=$TESTW1 \
     $CARDIO_SRC/test_vhosp_nocuda -f $CARDIO_SRC/config/test-model-vhosp-septest.ini

#  wait for shock trials to complete...
# wait
sleep 2

# Print Summary 
## Compare survival rates

print_summary() {
    
    echo " \n \n \n "
    echo "Experimental (Physiotherapy) :"
    export exper_fn=$(ls -ct $CARDIO_SRC/virtual_hosp_logs/logvh_TEST_vhosp-septest_[0-9]*.cardio | tail -1)
    echo $exper_fn
    python -c $'import os\nwith open(os.environ["exper_fn"],"r") as ff: rlines = ff.readlines()[1:]\nprint(sum([float(l.split("survival: ")[-1]) for l in rlines if "survival" in l]))'
    sleep 2;
    cp $exper_fn "$CARDIO_SRC/virtual_hosp_logs/logvh_TEST_exper.cardio"
    
    echo " \n \n "
    echo "Control (Sans) :"
    export control_fn=$(ls -ct $CARDIO_SRC/virtual_hosp_logs/logvh_TEST_vhosp-septest_[0-9]*.cardio | head -1)
    python -c $'import os\nwith open(os.environ["control_fn"],"r") as ff: rlines = ff.readlines()[1:]\nprint(sum([float(l.split("survival: ")[-1]) for l in rlines if "survival" in l]))'
    sleep 2;
    cp $control_fn "$CARDIO_SRC/virtual_hosp_logs/logvh_TEST_control.cardio"
}

print_summary;

## ## ##

echo "Done with simulation session!"
