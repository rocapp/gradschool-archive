#!/usr/local/bin/python3.6

import sys, os, subprocess, fileinput
import plot as psrc
import stats

config_dir = os.path.join(os.environ["CARDIO_SRC"], "config")

def run_command(cmd):
    try:
        completed = subprocess.run(cmd,
                                   shell=True,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE,
                                   text=True, env=os.environ)
    except TypeError:
        completed = subprocess.run(cmd,
                                   shell=True,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE,
                                   encoding='utf8', env=os.environ)
    return completed

def process_subject(sid):
    os.environ["SID"] = sid
    print("CARDIO_DATA = ", os.environ["CARDIO_DATA"])
    cmd = os.environ["CARDIO_SRC"]+"/test_hdf5_nocuda -f {}/config/".format(os.environ["CARDIO_SRC"]) + sid + ".ini"
    print(cmd)
    completed = run_command(cmd)
    with open(os.environ["CARDIO_SRC"]+"/logs/eplot_{}.log".format(sid), "w") as lfile:
        lfile.write(completed.stdout)
    print("** returncode = ", completed.returncode)
    if completed.returncode != 0:
        print("Exited! failed to process subject!")
        print(completed.stdout)
        print(completed.stderr)
        sys.exit(1)
    return completed.returncode

def plot_subject(sid, plots=[]):
    os.environ["SID"] = sid
    cmd = os.environ["CARDIO_SRC"]+"/scripts/plot.py"
    if plots:
        cmd += " {}".format(sid)
        for pltn in plots:
            cmdi = cmd+" {}".format(pltn)
            completed = run_command(cmdi)
            print(completed.stderr)
            logname = os.environ["CARDIO_SRC"]+"/logs/eplot_{}_{}.log".format(sid,pltn)
            with open(logname, "w") as lfile:
                lfile.write(completed.stdout)
        return 0
    completed = run_command(cmd)
    logname = os.environ["CARDIO_SRC"]+"/logs/eplot_{}.log".format(sid)
    with open(logname, "w") as lfile:
        lfile.write(completed.stdout)
    return 0

def update_bounds(sid, newbounds, boundnames=["prewin","durwin","postwin"]):
    filename = os.path.join(config_dir, "{}.ini".format(sid))
    for line in fileinput.input(filename, inplace=True):
        if any(wl in line for wl in boundnames):
            bname = line.split(" ")[0].strip()
            oldb = line.split(" ")[1].strip()
            line = line.replace(oldb, ",".join(["{:.2f}".format(nb) for nb in newbounds[boundnames.index(bname)]]))
        sys.stdout.write(line)

def ks2_determine_bounds(sid, tbins, cdf1, N, cdf2, M, alpha=0.05, increment=0.05):
    reqN, isvalid = stats.ks2sample(cdf1, N, cdf2, M, alpha, retN=True)
    newbounds = tbins
    print("isvalid",isvalid,"reqN=",reqN,"N=",N)
    if True:
        for nti, tb in enumerate(newbounds):
            nbs = [ tb[0]/(1.0+increment), tb[1]*(1.0+increment) ]
            for ntj, tb2 in enumerate(newbounds):
                if ntj!=nti:
                    if tb[1] >= tb2[0] and tb[1] <= tb2[1]:
                        nbs[1] = tb2[0] - tb2[0]*increment
                        if nbs[1] < 0: nbs[1] = tb[1]
                    if tb[0] >= tb2[0] and tb[0] <= tb2[1]:
                        nbs[0] = nbs[1] - N*100.0
                        if nbs[0] < 0: nbs[0] = 0
            newbounds[nti] = nbs
    return newbounds
