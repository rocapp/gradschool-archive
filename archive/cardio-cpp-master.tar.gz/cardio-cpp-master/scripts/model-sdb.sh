#!/bin/sh

TESTS=test_model $CARDIO_SRC/scripts/build.sh testmodel-base
TESTS=test_model $CARDIO_SRC/scripts/build.sh testmodel-sdb
SZOOM=40 $CARDIO_SRC/scripts/plot.py test-model-testmodel-base ltv
SZOOM=40 $CARDIO_SRC/scripts/plot.py test-model-testmodel-sdb ltv
SZOOM=40 $CARDIO_SRC/scripts/plot.py test-model-testmodel-base bp
SZOOM=40 $CARDIO_SRC/scripts/plot.py test-model-testmodel-sdb bp


