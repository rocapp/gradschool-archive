#!/usr/local/bin/python3.6
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import wfdb
import os
import numpy as np

# Load a single wfdb file, save to text

db_path = os.path.expanduser("~/Public/SepsisData") # path to wfdb files
# db_path = os.path.expanduser("~/Public/mghdb")

# recs = os.listdir(db_path)
# recs = [os.path.splitext(r)[0] for r in recs]
# recs = list(set(recs))
# recs = [r for r in recs if r.count("_") == 1]
# recs = sorted(recs)

recs = [,] # record to load
# rec = "A084-0380661247_0014"
# "A006-0360249162_0004"  A012-0447461450_0007"

out_path = os.path.expanduser("~/Documents/DataToSlava") + "/{}.txt"

for rec in recs:
    channel_names = ["CO2","II","SPO2"]
    sigs, fields = wfdb.io.rdsamp(os.path.join(db_path, rec), channel_names=channel_names)
    fn = out_path.format(rec)
    np.savetxt(fn, sigs)
