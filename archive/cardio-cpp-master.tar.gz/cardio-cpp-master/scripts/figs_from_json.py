#!/usr/local/bin/python3.6

import subprocess
import json
import os
import numpy as np
import sys
import time
 
make_path = "/home/rocapp/Git/cardio-cpp"
jpath = "/home/rocapp/Public/sepsis_records/RECORDS.json"
os.chdir(make_path)

if __name__ == "__main__":
    with open(jpath, "r") as f:
        rdict = json.load(f)

    lookin = ["Fig",True]

    for jk, jv in rdict.items():

        # jk = subject id
        # jv = {rec : rec_info, 'use': True/'Fig'/False/None}

        if jv['use'] in lookin:
        
            print("\nmaking figures for records : ", jk)

            for ir, rec in enumerate([ky for ky in jv.keys() if ky!='use']):
                
                print("  --> ", rec)
                
                try:
                    cmd = "TESTS=test_hdf5 H5=1 SID={} CONFIG=./config/config_000.ini make runtest".format(rec)
                    pcomp = subprocess.run(cmd, shell=True, check=True, stderr=subprocess.PIPE)
                except subprocess.CalledProcessError as Ex:
                    print("\n",rec," failed...\n")
