#!/usr/bin/env python3
import numpy as np
import traceback
import matplotlib as mpl
mpl.use("Agg")


mpl.rcParams['figure.titlesize'] = 36
mpl.rcParams['figure.figsize'] = (12,12)
mpl.rcParams['figure.dpi'] = 100 #300

mpl.rcParams['figure.subplot.hspace'] = 0.05

mpl.rcParams['savefig.bbox'] = 'tight'

axfontsize = 24
mpl.rcParams['axes.labelsize'] = axfontsize
mpl.rcParams['axes.titlesize'] = axfontsize+4

tickfontsize = 14
mpl.rcParams['xtick.labelsize'] = tickfontsize
mpl.rcParams['ytick.labelsize'] = tickfontsize

# from matplotlib.backends.backend_pdf import PdfPages

import matplotlib.pyplot as plt

import sys, os

import subprocess

bpload = False # is blood pressure loaded?

sample_rate = 240 # sampling rate of data

NR_WINS = 20 # Number of windows for median filtering

cardio_dir = os.environ["CARDIO_OUT"] # where to look for .cardio files
os.chdir(cardio_dir)

fig_dir = os.environ["CARDIO_FIG"] # where figures are sent
def save_path(fn): return os.path.join(fig_dir, fn)

def loadf(sid, signame, dtype='float64'):
    return np.fromfile(os.path.join(cardio_dir, "{}_{}.cardio".format(signame,sid)),dtype=dtype)

def normalize(sig):
    return (sig - sig.min())/(sig.max()-sig.min())

def median_filt(time, sig, ws, skipix=1):
    tmed = np.array([np.median(time[i-ws:i+ws]) for i in range(ws, time.size-ws, skipix)], dtype=sig.dtype).flatten()
    windows = [sig[i-ws:i+ws] for i in range(ws, sig.size-ws, skipix)]
    meds = np.array([np.median(win) for win in windows], dtype=sig.dtype).flatten()
    stds = np.array([np.std(win) for win in windows], dtype=sig.dtype).flatten()
    return tmed, meds, stds

def compute_mad(x):
    return np.median(np.abs(x-np.median(x)))

def make_signal_length_equal(stime, signal, desired_length, nr_wins, debug_=False):
    if not debug_:
        nullf = open(os.devnull, 'w')
        oldstdout = sys.stdout
        sys.stdout = nullf
    signal_length = stime.size
    swin = int(signal_length/desired_length)*nr_wins
    sskip = int(signal_length/desired_length)
    while True:
        mtime, msig, merr = median_filt(stime, signal, swin, skipix=sskip)
        print("goal_len=",desired_length,"msig.size=",msig.size,
              "swin=",swin,"sskip=",sskip)
        if (desired_length-msig.size) in [0, 1]:
            if msig.size==desired_length-1:
                print("msig.size = desl - 1")
                mtime, msig, merr = median_filt(stime, signal, swin+1, skipix=sskip-1)
                mtime = mtime[:desired_length]
                msig = msig[:desired_length]
                merr = merr[:desired_length]
                break
            elif msig.size==desired_length:
                print("done!")
                break
            else:
                print("other")
        elif msig.size > desired_length:
            swin+=1
        elif msig.size < desired_length and sskip > 1:
            sskip-=1
        else:
            print("failed to make same length...")
            break
    if not debug_:
        sys.stdout = oldstdout
    return mtime, msig, merr
                
condwins = {"prewin": (0,0), "durwin": (0,0), "postwin": (0,0) } # experimental condition windows (seconds)

def parse_cond_wins(sid):
    config_dir = os.path.join(os.environ["CARDIO_SRC"], "config")
    with open(os.path.join(config_dir, sid+".ini"), "r") as cff:
        for cfln in cff.readlines():
            if any(wstr in cfln for wstr in ["prewin", "durwin", "postwin"]) and "#" not in cfln:
                # print(cfln)
                condwins[cfln.split(" ")[0]] = (
                    float(cfln.split(" ")[1].split(",")[0]),
                    float(cfln.split(" ")[1].split(",")[1])
                )
    return condwins

def plot_q(sid, signame):
    print("plotting Q")
    Qarr = np.loadtxt(os.path.join(cardio_dir, "Q_{}.cardio").format(sid),
                      dtype='float64',delimiter=",", ndmin=2)
    epochs = np.arange(Qarr.size/2)
    Q = Qarr[:,0]
    Qerr = Qarr[:,1]
    time = loadf(sid,"time")
    qtime = np.linspace(time.min(), time.max(), epochs.size)
    NR_WINS = epochs.size
    plt.figure()
    plt.errorbar(qtime, Q, yerr=Qerr, color='k', marker="o", ecolor='r', ms=7)
    plt.xticks(qtime[::2],["{:.1f}".format(qtt) for qtt in qtime[::2]],fontsize=12)
    plt.suptitle("RSA Partitioned {}".format(sid))
    plt.xlabel("time (sec)")
    plt.ylabel("RSA deviation (sec)")
    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"Qrsa")))
    plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"Qrsa")))
    plt.close()


def calculate_q_from_comps(cp, a0, A, B): # a0, A, B
    return A*np.cos(2*np.pi*(cp+B)) + a0 # + B*np.sin(2*np.pi*cp)

def compute_phase_amp(qpopt):
    amp = np.linalg.norm(qpopt[[0,1]])
    phase = np.pi*qpopt[2]/180.0 # phase in radians
    return phase, amp
    
from scipy.optimize import curve_fit

segfns = []

def plot_rsaseg(sid, signame):
    global segfns
    try:
        print("plotting rsa segments",sid)
        oldsegs = False
        segdir = save_path("{}/_{}_condsegs".format(sid,sid)) # old segs are moved here after plotting
        segfns = sorted([fn for fn in os.listdir(cardio_dir) if "rsaseg_" in fn and sid in fn])
        if len(segfns)==0: # no new segs, check the "old segs" dir
            oldsegs = True
            print("** OLD RSA SEGS **")
            segfns = sorted([fn for fn in os.listdir(segdir) if "rsaseg_" in fn and sid in fn])
            segs = [np.loadtxt(os.path.join(segdir, fn),
                               dtype='float64',delimiter=",",ndmin=2) for fn in segfns]
        else:
            segs = [np.loadtxt(os.path.join(cardio_dir, fn),
                               dtype='float64',delimiter=",",ndmin=2) for fn in segfns]
        print(len(segs))
        for seg in segs:
            print(seg.shape)
        condsegs = {
            "prewin":
            {
                "phase": [], "rdiff":[],"err":[], "q":[], "rdiffR":[], "phaseR":[], "qc":[],
                "bpm": [], "bpms": []
            },
            "durwin":
            {
                "phase": [], "rdiff":[],"err":[], "q":[], "rdiffR":[], "phaseR":[], "qc":[],
                "bpm": [], "bpms": []
            },
            "postwin":
            {
                "phase": [], "rdiff":[],"err":[], "q":[], "rdiffR":[], "phaseR":[], "qc":[],
                "bpm": [], "bpms": []
            }
        }
        qtime = np.loadtxt(os.path.join(cardio_dir, "qtime_{}.cardio").format(sid),
                           dtype='float64')
        Qarr = np.loadtxt(os.path.join(cardio_dir, "Q_{}.cardio").format(sid),
                          dtype='float64',delimiter=",", ndmin=2)
        Qcomps = np.loadtxt(os.path.join(cardio_dir, "Qcomps_{}.cardio").format(sid),
                            dtype='float64',delimiter=",")
        maxrdiff = np.max([np.max(seg[:,1]) for seg in segs])
        minrdiff = np.min([np.max(seg[:,1]) for seg in segs])
        maxrerr = np.max([np.max(seg[:,2]) for seg in segs])
        rphaseR = loadf(sid,"hrsaphaseR")
        rdiffR = loadf(sid,"hrridiffR")
        tbeats = loadf(sid,"timebeat")
        qcomps = loadf(sid, "qcomps") # components of Q from entire RSA series

        bpmresp = loadf(sid, "bpmresp_nat") # blood pressure modulation vs resp phase (measured)
        bpmrmin, bpmrmax = np.min(bpmresp), np.max(bpmresp)
        
        bpmsynth = loadf(sid, "bpmresp_synth") # blood pressure modulation vs resp phase (synth)
        bpmsmin, bpmsmax = np.min(bpmsynth), np.max(bpmsynth)
        
        for xis, seg in enumerate(segs):
            for csk in list(condwins.keys()): # (sigix, ixslabels)
                if qtime[xis] >= condwins[csk][0] and qtime[xis] < condwins[csk][1]:
                    condsegs[csk]["phase"].extend(seg[:,0].tolist())
                    condsegs[csk]["rdiff"].extend(seg[:,1].tolist())
                    condsegs[csk]["err"].extend(
                        [np.sum(Qarr[:,1])/np.sqrt(seg[:,1].size),]*seg[:,1].size
                    )
                    condsegs[csk]["q"].append(Qarr[xis,0])
                    condsegs[csk]["qc"].append(Qcomps[xis])
        rdiffRixs = split_signal_by_conditions(tbeats)

        print(rphaseR.size, rdiffR.size)
        
        for rix, csk in enumerate(["prewin", "durwin", "postwin"]):
            crixs = rdiffRixs[rix]
            crixs = np.array([rx for rx in rdiffRixs[rix] if rx < rphaseR.size],dtype=np.int)
            print(crixs.size)
            condsegs[csk]["phaseR"] = normalize(rphaseR[crixs])
            condsegs[csk]["rdiffR"] = rdiffR[crixs]
            condsegs[csk]["bpm"] = bpmresp[crixs]
            condsegs[csk]["bpms"] = bpmsynth[crixs]
            qcc = np.concatenate(condsegs[csk]["qc"],axis=0).reshape((-1,3))
            condsegs[csk]["qc"] = qcc[np.argmax(np.mean(qcc,axis=1))]
        rtitles = {"prewin": "Baseline", "durwin": "SDB", "postwin": "Post-SDB"}

        ### BP phase plot
        bpmtheta = []
        bpmaves = []
        bpmerrs = []
        bpmstheta = []
        bpmsaves = []
        bpmserrs = []
        fig, axs = plt.subplots(ncols=3,figsize=(36,12))
        plt.suptitle("bpmresp {}".format(sid),fontsize=14,ha="center",x=0.05)
        for eix, epoch in enumerate(["prewin", "durwin","postwin"]):
            rhix = np.argsort(condsegs[epoch]["phaseR"])
            Nrepoch = len(condsegs[epoch]["bpm"][rhix])
            bpmerrs.append( np.std(condsegs[epoch]["bpm"][rhix]) / np.sqrt(Nrepoch) ) # BPM Error for each epoch
            bpmserrs.append( np.std(condsegs[epoch]["bpms"][rhix]) / np.sqrt(Nrepoch) ) # BPM (Synth) Error for each epoch
            axs[eix].plot(condsegs[epoch]["phaseR"][rhix], condsegs[epoch]["bpm"][rhix],
                          marker='.', color='r', ls='', label='meas')
            axs[eix].plot(condsegs[epoch]["phaseR"][rhix], condsegs[epoch]["bpms"][rhix],
                          marker="o", color='k', ls='', label='synth')
            qpopt, qpcov = curve_fit(calculate_q_from_comps,
                                     condsegs[epoch]["phaseR"][rhix],
                                     condsegs[epoch]["bpm"][rhix],
                                     p0=[1.0,0.01,0.1])
            qpopt1, qpcov1 = curve_fit(calculate_q_from_comps, # synthetic bp
                                       condsegs[epoch]["phaseR"][rhix],
                                       condsegs[epoch]["bpms"][rhix],
                                       p0=[1.0,0.01,0.1])
            print("(BPM) Optimized a0, A, B: ", qpopt)
            print("(BPMsynth) Optimized a0, A, B: ", qpopt)
            qpoly = calculate_q_from_comps(condsegs[epoch]["phaseR"][rhix], *qpopt)
            qpoly1 = calculate_q_from_comps(condsegs[epoch]["phaseR"][rhix], *qpopt1) # synthetic
            axs[eix].plot(condsegs[epoch]["phaseR"][rhix], qpoly, color='r', lw=7)
            axs[eix].plot(condsegs[epoch]["phaseR"][rhix], qpoly1, color='k', lw=7) # synth
            axs[eix].axhline(linestyle="--", color="k")
            axs[eix].axvline(0.5, linestyle="--", color='k', lw=4)
            axs[eix].text(0.2, -0.105, "Expiration", fontsize=24, color='b')
            axs[eix].text(0.7, -0.105, "Inspiration", fontsize=24, color='b')
            # BP-phasemod average for each epoch
            Qp, Qe = compute_phase_amp(qpopt) # Natural BPM
            bpmaves.append(Qe)
            bpmtheta.append(Qp)
            Qps, Qes = compute_phase_amp(qpopt1) # Synth BPM
            bpmsaves.append(Qes)
            bpmstheta.append(Qps)
            axs[eix].set_title("{} : (n,s): {:.3f},{:.3f} mmHg : (theta={:.2f},{:.2f})".format( rtitles[epoch], Qe, Qes, Qp, Qps )) # text that shows depth
            axs[eix].set_ylim([-3.5, 3.5])
            axs[eix].set_xlim([0., 1.])
            axs[eix].set_xticks([0.0, 0.5, 1.0])
            axs[eix].set_xticklabels([str(pstr) for pstr in [0.0, 0.5, 1.0]],
                                     fontdict=dict(fontsize=20))
        axs[0].set_ylabel("BP (mmHg)")
        axs[1].set_xlabel("Respiratory Phase")
        axs[1].set_yticks([])
        axs[2].set_yticks([])
        axs[0].legend()
        plt.tight_layout()
        plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"BPresp")))
        plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"BPresp")))
        plt.close()
        bpmout = np.array([(bph, ba, be) for bph, ba, be in zip(bpmtheta, bpmaves, bpmerrs)]).reshape(-1,3)
        print("BPM OUT = ", bpmout, "\n")
        np.savetxt(save_path("{}/_{}_BPMresp.txt".format(sid,sid)), bpmout)
        bpmsout = np.array([(bph, ba, be) for bph, ba, be in zip(bpmstheta, bpmsaves, bpmserrs)]).reshape(-1,3)
        print("BPMS OUT = ", bpmsout, "\n")
        np.savetxt(save_path("{}/_{}_BPMsynthresp.txt".format(sid,sid)), bpmsout)
        print("\n")
        
        rsa_aves = []
        rsa_theta = []
        rsa_errs = []
        ### RSA phase plot
        fig, axs = plt.subplots(ncols=3,figsize=(36,12))
        plt.suptitle("rsasegs {}".format(sid),fontsize=14,ha="center",x=0.05)
        for eix, epoch in enumerate(["prewin", "durwin","postwin"]):
            rhix = np.argsort(condsegs[epoch]["phaseR"])
            axs[eix].plot(condsegs[epoch]["phaseR"][rhix], condsegs[epoch]["rdiffR"][rhix],
                          marker='.', color='k', ls='')
            Nrepoch = len(condsegs[epoch]["rdiffR"][rhix])
            rsa_errs.append( np.std(condsegs[epoch]["rdiffR"][rhix]) /
                             np.sqrt(Nrepoch) ) # RSA Error for each epoch
            print("Qcomps (a0, A, B) = ", qcomps[0], qcomps[1], qcomps[2])
            qpopt, qpcov = curve_fit(calculate_q_from_comps,
                                     condsegs[epoch]["phaseR"][rhix],
                                     condsegs[epoch]["rdiffR"][rhix],
                                     p0=[0.001,0.01,0.01])
            print("Optimized a0, A, B: ", qpopt)
            qpoly = calculate_q_from_comps(condsegs[epoch]["phaseR"][rhix], *qpopt)
            axs[eix].plot(condsegs[epoch]["phaseR"][rhix], qpoly, color='r', lw=7)
            axs[eix].axhline(linestyle="--", color="b")
            axs[eix].axvline(0.5, linestyle="--", color='b', lw=4)
            axs[eix].text(0.2, -0.105, "Expiration", fontsize=24, color='b')
            axs[eix].text(0.7, -0.105, "Inspiration", fontsize=24, color='b')
            # Qe = np.linalg.norm(qpopt) # RSA average for each epoch
            Qpr, Qer = compute_phase_amp(qpopt)
            rsa_theta.append(Qpr)
            rsa_aves.append(Qer)
            axs[eix].set_title("{} : {:.3f} sec (theta={:.2f})".format( rtitles[epoch], Qer, Qpr )) # text that shows depth
            axs[eix].set_ylim([-0.12,0.12])
            axs[eix].set_xlim([0., 1.])
            axs[eix].set_xticks([0.0, 0.5, 1.0])
            axs[eix].set_xticklabels([str(pstr) for pstr in [0.0, 0.5, 1.0]], fontdict=dict(fontsize=20))
        axs[0].set_ylabel("RRI deviation (sec)")
        axs[1].set_xlabel("Respiratory Phase")
        axs[1].set_yticks([])
        axs[2].set_yticks([])
        plt.tight_layout()
        plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"rsasegs")))
        plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"rsasegs")))
        plt.close()
        rsaout = np.array([(rph, ra, re) for rph, ra, re in zip(rsa_theta, rsa_aves, rsa_errs)]).reshape(-1,3)
        np.savetxt(save_path("{}/_{}_RSAconds.txt".format(sid,sid)), rsaout)
        
        ### RSA segment bar plot
        fig2 = plt.figure()
        plt.suptitle("RSA",fontsize=16)
        bar_width = 0.4
        indices = np.arange(3)
        plt.bar(indices, rsa_aves, bar_width,
                facecolor="grey", edgecolor='k',
                color=(1,1,1,0), capsize=1.0,
                yerr=rsa_errs, error_kw=dict(ecolor='k',elinewidth=2.0))
        plt.ylabel("RSA (sec)", fontsize=16)
        plt.xticks(indices, ('Baseline', 'SDB', 'Post-SDB'), fontsize=9)
        plt.ylim(bottom=np.min(rsa_aves)-np.max(rsa_errs)*1.045,
                 top=np.max(rsa_aves)+np.max(rsa_errs)*1.045)
        plt.tight_layout()
        plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"rsaBarPlot")))
        plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"rsaBarPlot")))
        plt.close()

        ### RRI-epoch bar plot
        rri_aves, rri_errs = [], []
        rri = loadf(sid,"hrri")
        for exi, rrixs in enumerate(rdiffRixs):
            rri_aves.append(np.mean(rri[rrixs]))
            rri_errs.append(np.std(rri[rrixs])/np.sqrt(len(rrixs)))
        fig3 = plt.figure()
        plt.suptitle("RRI",fontsize=16)
        bar_width = 0.4
        indices = np.arange(3)
        plt.bar(indices, rri_aves, bar_width,
                facecolor="grey", edgecolor='k',
                color=(1,1,1,0), capsize=1.0,
                yerr=rsa_errs, error_kw=dict(ecolor='k',elinewidth=2.0))
        plt.ylabel("RRI (sec)", fontsize=16)
        plt.xticks(indices, ('Baseline', 'SDB', 'Post-SDB'), fontsize=9)
        plt.ylim(bottom=np.min(rri_aves)-np.max(rri_errs)*1.045,
                 top=np.max(rri_aves)+np.max(rri_errs)*1.045)
        plt.tight_layout()
        plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"rriBarPlot")))
        plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"rriBarPlot")))
        plt.close()
        
        if not oldsegs:
            # keep in mind this only happens if everything else completes successfully :)
            print("moving rsaseg files...")
            from shutil import copyfile as copyfile
            try:
                os.mkdir(segdir)
            except FileExistsError:
                print()
            for rff in os.listdir(segdir): # remove any files already in the "oldseg" dir
                os.remove(os.path.join(segdir, rff))
            for rfn in segfns: # copy new files to the "oldseg" dir, remove the originals
                copyfile(os.path.join(cardio_dir, rfn), "{}/{}".format(segdir,rfn))
                os.remove(os.path.join(cardio_dir, rfn))
        
    except Exception as rsaseg_excep:
        print("exception encountered in plot_rsaseg")
        print(rsaseg_excep)
        print(traceback.format_exc())
    

def align_axes(axs, times):
    start_time = np.max([tspace[0] for tspace in times]) # the first possible t0
    end_time = np.min([tspace[-1] for tspace in times]) # the last possible t1
    for axx in axs:
        axx.set_xlim([start_time, end_time])

def mark_condwins(axs, aix, mtime, meds, errs):
    if condwins["prewin"][1] > 0:
        axs[aix].set_ylim([meds.min()-errs.max(), meds.max()+errs.max()])
        axs[aix].fill_betweenx([meds.min()-errs.max(),meds.max()+errs.max()],
                             x1=condwins["prewin"][0],
                             x2=condwins["prewin"][1],
                             color='b', alpha=0.2)
        # axs[aix].text(sum(condwins["prewin"])/2, axs[aix].get_ylim()[1]/1.5, "Pre")
        axs[aix].fill_betweenx([meds.min()-errs.max(),meds.max()+errs.max()],
                            x1=condwins["durwin"][0],
                             x2=condwins["durwin"][1],
                             color='g', alpha=0.2)
        # axs[aix].text(sum(condwins["durwin"])/2, meds.mean()*0.85, "SDB")
        axs[aix].fill_betweenx([meds.min()-errs.max(),meds.max()+errs.max()],
                             x1=condwins["postwin"][0],
                             x2=condwins["postwin"][1],
                             color='r', alpha=0.2)
        # axs[aix].text(condwins["postwin"][0]*1.15, meds.mean()*1.05, "Post")
 
def split_signal_by_conditions(signal_time):
    presix = np.where((signal_time > condwins["prewin"][0]) & (signal_time < condwins["prewin"][1]))[0]
    dursix = np.where((signal_time > condwins["durwin"][0]) & (signal_time < condwins["durwin"][1]))[0]
    postsix = np.where((signal_time > condwins["postwin"][0]) & (signal_time < condwins["postwin"][1]))[0]
    return presix, dursix, postsix
    
def plot_cvc(sid, signame):
    try:
        print("plotting cvc")
        cvcphase = loadf(sid,"beat2insp",'float64') # unsorted phase for phasegram
        cvcphase1 = np.sort(cvcphase) # sorted phase
        cdf = np.linspace(0, 1, cvcphase.size)
        timecvc = loadf(sid,"time_b2i")

        cvcp = cvcphase.copy() # unsorted cvcphase for pdf/time

        Qarr = np.loadtxt(os.path.join(cardio_dir, "Q_{}.cardio").format(sid),
                          dtype='float64',delimiter=",", ndmin=2)
        Q = Qarr[:,0]
        Qerr = Qarr[:,1]
        qtime = np.loadtxt(os.path.join(cardio_dir, "qtime_{}.cardio").format(sid),
                           dtype='float64')
        NR_WINS = Q.size

        # cvc from states
        cvctimes = loadf(sid, "cvctime")
        cvcdiffs = loadf(sid, "cvcdist")
        cvcerrs = loadf(sid, "cvcerr")

        ### Plot magnitude (cdf/time)
        mags = []
        tmags = []
        smags = []
        mags_act = []
        if cvcp.size==0:
            cvcp = cvcdiffs
            timecvc = cvctimes
        ws = np.int(1.25*cvcp.size/(NR_WINS+1)) # window size in indices
        print("  NR_WINS=", NR_WINS)
        ix = 0
        figfns = []
        print("cvcphase.size=",cvcp.size)
        for i in range(int(ws/2),cvcp.size-int(ws/2),int(ws/2)):
            tpi = np.mean(timecvc[i-int(ws/2):i+int(ws/2)])
            cpi = np.sort(cvcphase[i-int(ws/2):i+int(ws/2)]) # sorted for cdf
            cdfi = np.linspace(0, 1, cpi.size) # cdf_i
            pdiff = np.sqrt( np.power(cpi - cdfi, 2) )
            pmag = np.argmax(pdiff)
            mact = pdiff.max()
            print(i, "  window_size > ", cpi.size)        
            mags_act.append( mact ) # max pdf - (min pdf, phase > pmag)
            mags.append(pmag)
            tmags.append(tpi)
            smags.append(np.std(pdiff))
            ix += 1

        tmags = np.array(tmags)
        mags_act = np.array(mags_act)
        # mags_act = normalize(mags_act)
        smags = np.array(smags)

        # save cdf in time
        np.savetxt(save_path("{}/_{}_cvcCDF.txt".format(sid,sid)),
                   mags_act)
        np.savetxt(save_path("{}/_{}_cvcTime.txt".format(sid,sid)),
                   tmags)
        np.savetxt(save_path("{}/_{}_cvcErr.txt".format(sid,sid)),
                   smags)
        np.savetxt(
            os.path.join(cardio_dir,
                         "_{}_cvcTime.txt".format(sid,sid)), tmags)
        np.savetxt(
            os.path.join(cardio_dir,
                         "_{}_cvcCDF.txt".format(sid,sid)), mags_act)
        np.savetxt(
            os.path.join(cardio_dir,
                         "_{}_cvcErr.txt".format(sid,sid)), smags)

        ### Plot CDF v Time
        plt.figure()
        plt.suptitle("CVC cdf vs time {}".format(sid))
        plt.xlabel("time (sec)")
        plt.errorbar(tmags, mags_act, yerr=smags, color='k',
                     ecolor='c', marker='o', ms=7, rasterized=True)
        if "Erica" in sid:
            trueix = np.where((tmags >= 700) & (tmags <= 1550))[0].astype(np.int).ravel()
            print(trueix, trueix.dtype)
            plt.plot(tmags[trueix], mags_act[trueix], color='r', marker='*', ms=8,
                     label="slow_breathing", rasterized=True)
        plt.ylabel("Max Distance (cdf-bisector)")
        plt.xticks(tmags[::int(tmags.size/5)],
                   ["{:.1f}".format(tmi) for tmi in tmags[::int(tmags.size/5)]],
                   fontsize=10)
        plt.legend(loc='best')
        plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"cvcCDFvTime")))
        plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"cvcCDFvTime")))
        plt.close()

        ### Plot cvc from states

        plt.figure()
        plt.suptitle("cvc from states {}".format(sid))
        plt.xlabel("time")
        plt.errorbar(cvctimes, cvcdiffs, yerr=cvcerrs, color='k',
                     ecolor='c', marker='o', ms=7, rasterized=True)
        plt.ylabel('cvc max diff')
        plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"CVCstates")))
        plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"CVCstates")))
        plt.close()

        ### Plot pdf
        plt.figure()
        plt.hist(cvcp, density=True, bins='fd')
        plt.suptitle("CVC PDF {}".format(sid))
        plt.ylabel("pdf")
        plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"PDF")))
        plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"PDF")))
        plt.close()

        ### ### ###     ### ### ###     ### ### ###     ### ### ###

        ### Plot All Signals ###
        fig, axs = plt.subplots(nrows=6)
        plt.suptitle("Phaseogram \n{}".format(sid),fontsize=12)
        fig.subplots_adjust(hspace=0.4)

        # phase contour
        pdf, px, py = np.histogram2d(timecvc, cvcphase, bins=NR_WINS/2, density=True)
        cs=axs[0].contour(px[:-1], py[:-1], pdf.T, linewidths=0.01, colors='k')
        cntf=axs[0].contourf(px[:-1], py[:-1], pdf.T, cmap="Reds")
        axs[0].axhline(y=0.5, color='k', ls='--', label='$I_{0}$', zorder=2, lw=1)
        axs[0].set_ylabel(r'$\phi (\iota_0 \Rightarrow \iota_0$)',fontsize=12)
        # axs[0].set_xlim([barotime[0], timecvc[-1]])

        # cvc
        axs[1].plot(loadf(sid,"timecvc"), loadf(sid,"hcvcphase"),
                    linestyle='', color='b', marker='.', ms=5, label="CVC")
        # axs[1].errorbar(tmags, mags_act, yerr=smags, color='k',
        #                 ecolor='c', marker='o', ms=7, rasterized=True)
        axs[1].legend(loc="best")
        axs[1].set_ylabel("CVC", fontsize=12)
        # axs[1].set_ylim([-0.05, 0.4])
        # axs[1].set_xlim([barotime[0], cvctimes[-1]])

        # respdur
        rdtime = loadf(sid,"timeresp")
        rdur = loadf(sid, "respdur")
        rdwin = np.int(rdur.size/NR_WINS)
        rdspace, rdmeds, rderrs = median_filt(rdtime, rdur, rdwin,
                                              skipix=int(rdwin*0.2))
        axs[2].errorbar(rdspace, rdmeds, yerr=rderrs,
                        color='c', ecolor='k', label='resp dur')
        mark_condwins(axs, 2, rdspace, rdmeds, rderrs)
        axs[2].set_ylabel('Resp Dur.\n(sec)',fontsize=12)
        axs[2].legend(loc='best')

        # rri
        rri = loadf(sid,"hrri")
        tbeat = loadf(sid,"timebeat")
        riwin = np.int(rri.size/NR_WINS)
        rispace, rimeds, rierrs = median_filt(tbeat, rri*1000, riwin,
                                              skipix=int(riwin*0.2))
        axs[3].errorbar(rispace, rimeds, yerr=rierrs,
                        color='m', ecolor='c', ms=7, label='rri')
        mark_condwins(axs, 3, rispace, rimeds, rierrs)
        axs[3].set_ylabel('RRI\n(msec)',fontsize=12)
        from matplotlib.ticker import FormatStrFormatter
        axs[3].yaxis.set_major_formatter(FormatStrFormatter('%.1f'))
        axs[3].legend(loc='best')

        # BP
        if bpload:
            bpsig = loadf(sid,"bp")
            timet = loadf(sid,"time")
            bpwin = np.int(bpsig.size/NR_WINS)
            bpskip = int(bpwin*0.1)
            bptime, bpmeds, bpstds = median_filt(timet, bpsig, bpwin,skipix=bpskip)
            if bptime.size > bpmeds.size: bptime = bptime[:bpmeds.size]
            elif bpmeds.size > bptime.size: bpmeds = bpmeds[:bptime.size]
            print("bpmeds.size=",bpmeds.size,"bpwins=",bpwin,"bpskip=",bpskip)
            svdiff = loadf(sid,"bpsysdiff")
            svtime = loadf(sid,"bpsystime")
            svspace, svmeds, sverr = make_signal_length_equal(svtime, svdiff, bpmeds.size, NR_WINS)
            axs[4].errorbar(bptime, y=bpmeds, color='k', ecolor='c', label='MAP')
            if condwins["prewin"][1] > 0:
                presvix, dursvix, postsvix = split_signal_by_conditions(bptime)
                axs[4].bar([(condwins["prewin"][1]+condwins["prewin"][0])/2.0,
                            (condwins["durwin"][1]+condwins["durwin"][0])/2.0,
                            (condwins["postwin"][1]+condwins["postwin"][0])/2.0],
                           [np.max(svmeds[presvix])+np.min(svmeds[presvix]),
                            np.max(svmeds[dursvix])+np.min(svmeds[dursvix]),
                            np.max(svmeds[postsvix])+np.min(svmeds[postsvix])],
                           width=[(condwins["prewin"][1]-condwins["prewin"][0]),
                                  (condwins["durwin"][1]-condwins["durwin"][0]),
                                  (condwins["postwin"][1]-condwins["postwin"][0])],
                           bottom=np.min(bpmeds), color="b", alpha=0.25, label="BP Oscillation Amplitude")
            axs[4].set_ylabel('BP\n(mmHg)', fontsize=13)
            axs[4].legend(loc='best')
            
            # BP Pulse Length
            bpsix = loadf(sid,"bp_pulseix",np.int32)
            bplen = loadf(sid,"bpplen")
            if bpsix.size > bplen.size:
                bpsix = bpsix[:bplen.size]
            bplwin = np.int(1.2*bplen.size/NR_WINS)
            bplskip = np.int(0.2*bplwin)
            time=loadf(sid,"time")
            bpltime, bplmeds, bplstds = median_filt(time[bpsix], bplen, bplwin, skipix=bplskip)
            axs[5].plot(bpltime, bplmeds, 'g', label="BP Pulse Length")
            axs[5].set_ylabel("sec")
        align_axes(axs, [timecvc, cvctimes, rdspace, rispace, bptime, bpltime])
        plt.xlabel("time")
        for pci in range(len(axs)):
            axs[pci].margins(x=0, y=0)
        fig.align_ylabels()
        fig.tight_layout(pad=4.0,h_pad=0.01)
        plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"PhaseContour")))
        plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"PhaseContour")))
        plt.close()

        bpmins = loadf(sid,"bp_mins",np.int32)
        
        def mark_resp_phase_bp(axb, bpnx, bpex, bt, bx, txlim, bpsig):
            bpnx, bpex = bpnx.tolist(), bpex.tolist()
            bpmax = bpsig.max()
            print(len(bpnx), len(bpex), len(bx), bpmax)
            print("txlim", txlim)
            bpintime = [(bt[ix0], bt[ex0]) for ix0, ex0 in zip(bpnx, bpex) \
                        if all(bt[xx] > bt[bx].min() and bt[xx] < bt[bx].max() for xx in [ix0,ex0])]
            print(min(bpintime, key=lambda bxx: bxx[0]), max(bpintime, key=lambda bxx: bxx[1]))
            ct0 = False
            for tin0, tin1 in bpintime:
                if tin0 > tin1:
                    hv = axb.axvspan(tin1, tin0, facecolor=(1, 1, 1, 0.5), edgecolor='none')
                if not ct0:
                    hv.set_label('Expiration')
                    ct0 = True
            ct1 = False
            for cycle_ix, tex in enumerate(bpintime[:-1]):
                tex0, tex1 = tex
                hv1 = axb.axvspan(tex0, bpintime[cycle_ix+1][1], facecolor=(0.6, 0.6, 0.6, 0.5), edgecolor='none')
                if not ct1:
                    hv1.set_label("Inspiration")
                    ct1 = True
            bpminsx = bpmins[(bt[bpmins] > txlim[0]+1.0) & (bt[bpmins] < txlim[1]-1.0)]
            bpmaxx, bpminx = np.argmax(bpsig[bpminsx]), np.argmin(bpsig[bpminsx])
            axb.vlines(bt[bpminsx][bpmaxx], ymin=bpsig[bpminsx][bpminx], ymax=bpsig[bpminsx][bpmaxx],
                       linewidth=3, zorder=5, colors=(0.,0.,0.,1.0), label="Modulation strength")
            axb.plot([bt[bpminsx][bpmaxx]-0.2, bt[bpminsx][bpmaxx]+0.2], [bpsig[bpminsx][bpminx],]*2,
                     linewidth=1.4, zorder=5, color=(0.,0.,0.,1.0))
            axb.plot([bt[bpminsx][bpmaxx]-0.2, bt[bpminsx][bpmaxx]+0.2], [bpsig[bpminsx][bpmaxx],]*2,
                     linewidth=1.4, zorder=5, color=(0.,0.,0.,1.0))
            return axb
        
        ### Plot BP in each condition
        if bpload and condwins["prewin"][1] > 0:

            prebix, durbix, postbix = split_signal_by_conditions(timet)

            print("median BP (conds)", np.median(bpsig[prebix]), np.median(bpsig[durbix]), np.median(bpsig[postbix]))
            print("median BPmod (conds)", np.median(svmeds[presvix]), np.median(svmeds[dursvix]), np.median(svmeds[postsvix]))
            
            insp0ix = loadf(sid,'linsp0ix',np.int32)
            exp0ix = loadf(sid,'lexp0ix',np.int32)

            from matplotlib.gridspec import GridSpec
            from matplotlib.patches import Rectangle
            
            fig = plt.figure(figsize=(26,10), constrained_layout=True,)
            gs = GridSpec(1, 26, figure=fig, wspace=0.05)
            plt.suptitle("{} Blood pressure - conditions".format(sid),fontsize=10)

            msoff = 1.0
            isoff = 1.0
            
            bpave_base = np.median(bpsig[prebix])
            bperr_base = np.std(bpsig[prebix]) / np.sqrt(bpsig[prebix].size)
            bpmod_base = np.median(svmeds[presvix])
            bpmerr_base = compute_mad(svmeds[presvix])
            print("bpmerr_base",bpmerr_base)
            ax0 = fig.add_subplot(gs[0,:6])
            ax0.set_title("Baseline",fontsize=18)
            ax0.plot(timet[prebix], bpsig[prebix], c='k', lw=msoff)
            bt0, bt1 = -480, -460 # S9
            # bt0, bt1 = -300,-280 # S1
            time_xlim = [timet[prebix][-1]+bt0, timet[prebix][-1]+bt1]
            ax0 = mark_resp_phase_bp(ax0, insp0ix, exp0ix, timet, prebix, time_xlim, bpsig)
            xtr = 5
            ax0.set_ylabel("mmHg",fontsize=18)
            ax0.set_xlim(left=time_xlim[0], right=time_xlim[1])
            ax0.set_ylim([bpsig.min(), bpsig.max()])
            ax0.set_xticks(np.linspace(timet[prebix][-1]+bt0, timet[prebix][-1]+bt1, int((-bt0+bt1)/xtr)))
            pret = np.linspace(0, -bt0+bt1, (-bt0+bt1)*sample_rate, endpoint=False)[0::sample_rate*xtr]
            ax0.set_xticklabels([]) #(["{:.0f}".format(bt) for bt in pret])
            
            # BP CONDITIONS TIME SCALE BAR
            bpy = bpsig.min()+3.0
            bstime0, bstime1 = time_xlim[0]+0.5, time_xlim[0]+5.5
            ax0.hlines(y=bpy, xmin=bstime0, xmax=bstime1, linewidth=2.0, zorder=500)
            ax0.vlines([bstime0, bstime1], ymin=bpy-0.25, ymax=bpy+1.0, linewidth=1.0, zorder=500)
            ax0.text(-0.2+(bstime1+bstime0)/2.0, bpy-1.3, "5 s", verticalalignment="center", zorder=500, fontsize=12)
            ax0.add_patch(Rectangle((time_xlim[0]+0.1, bpy-2.0), width=5.5, height=3.7, lw=0.85,
                                    facecolor=(1.,1.,1.,0.8), edgecolor='none',
                                    zorder=499, transform=ax0.transData))
            ax0.text(0.05, 1.05, "A", fontsize=45, transform=ax0.transAxes, zorder=500)

            bpave_sdb = np.median(bpsig[durbix])
            bperr_sdb = np.std(bpsig[durbix]) / np.sqrt(bpsig[durbix].size)
            bpmod_sdb = np.median(svmeds[dursvix])
            bpmerr_sdb = compute_mad(svmeds[dursvix])
            print("bpmerr_sdb",bpmerr_sdb)
            ax1 = fig.add_subplot(gs[0,6:12])
            ax1.set_title("SDB",fontsize=18)
            ax1.plot(timet[durbix], bpsig[durbix], c='k', lw=msoff)
            bsx = 100.0 # 15
            time_xlim = [timet[durbix][0]+bsx, timet[durbix][0]+bsx-bt0+bt1]
            ax1 = mark_resp_phase_bp(ax1, insp0ix, exp0ix, timet, durbix, time_xlim, bpsig)
            ax1.set_xlim(left=time_xlim[0], right=time_xlim[1])
            ax1.set_ylim([bpsig.min(), bpsig.max()])
            ax1.set_xticks(np.linspace(timet[durbix][0]+bsx, timet[durbix][0]+bsx-bt0+bt1, int((-bt0+bt1)/xtr)))
            ax1.set_xticklabels([]) #(["{:.0f}".format(bt) for bt in pret])
            ax1.tick_params(axis='y', which='both', left=False, right=False, top=False)
            ax1.set_yticklabels([],[])

            bpave_post = np.median(bpsig[postbix])
            bperr_post = np.std(bpsig[postbix]) / np.sqrt(bpsig[postbix].size)
            bpmod_post = np.median(svmeds[postsvix])
            bpmerr_post = compute_mad(svmeds[postsvix]) #/ np.sqrt(svmeds[postsvix].size/2)
            print("bpmerr_post",bpmerr_post)
            ax2 = fig.add_subplot(gs[0,12:18])
            ax2.set_title("Post",fontsize=18)
            ax2.plot(timet[postbix], bpsig[postbix], c='k', lw=msoff)
            time_xlim = [timet[postbix][0]+bsx, timet[postbix][0]+bsx-bt0+bt1]
            ax2 = mark_resp_phase_bp(ax2, insp0ix, exp0ix, timet, postbix, time_xlim, bpsig)
            legend2 = ax2.legend(loc='upper right', bbox_to_anchor=(0.95, 1.13), fontsize=10)
            ax2.set_xlim(left=time_xlim[0], right=time_xlim[1])
            ax2.set_ylim([bpsig.min(), bpsig.max()])
            ax2.set_xticks(np.linspace(timet[postbix][0]+bsx, timet[postbix][0]+bsx-bt0+bt1, int((-bt0+bt1)/xtr)))
            ax2.set_xticklabels([])
            ax2.tick_params(axis='y', which='both', left=False, right=False, top=False)
            ax2.set_yticklabels([],[])

            ax3 = fig.add_subplot(gs[0,19:22])
            ax3.set_title("Ave. BP",fontsize=18)
            bpaves = np.array([bpave_base, bpave_sdb, bpave_post])
            bperrs = np.array([bperr_base, bperr_sdb, bperr_post])
            if "test-model" not in sid and "Erica" in sid:
                bpAves = np.loadtxt(os.path.join(os.environ.get("CARDIO_OUT"), "bp_EricaAnalysisGroupAve.txt"))
                print(bpAves.shape)
                bpaves = bpAves[0,:]
                bperrs = bpAves[1,:]
            print(bpaves.size, bperrs.size)
            ax3.bar([0, 1, 2], bpaves, color=(1,1,1,0), edgecolor='k',
                    yerr=bperrs, ecolor='black', facecolor='grey',
                    error_kw=dict(linewidth=2), capsize=1.0)
            ax3.set_xticks([0, 1, 2])
            ax3.set_xticklabels(["Baseline", "SDB", "Post"])
            minsig = np.min(bpaves)
            maxsig = np.max(bpaves)
            maxerr=np.max(bperrs)
            ax3.set_ylim([minsig-maxerr, maxsig+maxerr*1.2])
            ax3.set_ylabel("mmHg",fontsize=18)
            ax3.text(0.05, 1.05, "B", fontsize=45, zorder=500, transform=ax3.transAxes)

            ax4 = fig.add_subplot(gs[0,23:])
            bpmaves = [bpmod_base, bpmod_sdb, bpmod_post]
            bpmerrs = [bpmerr_base, bpmerr_sdb, bpmerr_post]
            if "test-model" not in sid and "Erica" in sid:
                bpmAves = np.loadtxt(os.path.join(os.environ.get("CARDIO_OUT"), "bpmod_EricaAnalysisGroupAve.txt"))
                print(bpAves.shape)
                bpmaves = bpmAves[0,:]
                bpmerrs = bpmAves[1,:]
            ax4.set_title("Ave. Modulation",fontsize=18)
            ax4.bar([0, 1, 2], bpmaves, color=(1,1,1,0), edgecolor='k',
                    yerr=bpmerrs, ecolor='black', facecolor='grey',
                    error_kw=dict(linewidth=2), capsize=1.0)
            ax4.set_xticks([0, 1, 2])
            maxmod = np.max(bpmaves)
            minmod = np.min(bpmaves)
            maxerr = np.max(bpmerrs)
            ax4.set_ylim([minmod-maxerr, maxmod+maxerr*1.2])
            # ax4.set_ylabel("mmHg",fontsize=18)
            ax4.set_xticklabels(["Baseline", "SDB", "Post"])

            # gs.tight_layout(fig, w_pad=0.05)
            
            plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"BPconditions")))
            plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"BPconditions")))
            plt.close()
            
        ### Plot Phasegram
        plt.figure()
        plt.scatter(timecvc, cvcphase, color='k', marker='.', rasterized=True)
        plt.xlabel('time')
        plt.ylabel('Heartbeat phase')
        plt.suptitle("Phaseogram {}".format(sid))
        plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"Phase")))
        plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"Phase")))
        plt.close()

        ### Plot Inspogram
        plt.figure()
        b2i=loadf(sid,"beat2insp")
        tb2i=loadf(sid,"time_b2i")
        plt.scatter(tb2i, b2i, color='b', marker='.', rasterized=True)
        plt.xlabel("time")
        plt.ylabel("sec -> insp")
        plt.suptitle("Inspogram {}".format(sid))
        plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"InspoBeats")))
    except Exception as cvcexcept:
        print("Exception in plot_cvc", cvcexcept)
        print(traceback.format_exc())

def plot_bplen(sid, signame):
    print("plotting BP Pulse Lengths...")
    try:
        bpsix = loadf(sid,"bp_pulseix",np.int32)
        # bpsix1 = loadf(sid,"bp_pulseix1",np.int32)
        bplen = loadf(sid,signame)
        if bpsix.size > bplen.size:
            bpsix = bpsix[:bplen.size]
        time = loadf(sid,"time")
        plt.figure()
        plt.suptitle("BP Pulse Lengths {}".format(sid))
        plt.plot(time[bpsix], bplen, color='b', linestyle='', marker='.')
        bpwin = np.int(1.2*bplen.size/NR_WINS)
        bpskip = np.int(0.2*bpwin)
        bptime, bpmeds, bpstds = median_filt(time[bpsix], bplen, bpwin, skipix=bpskip)
        plt.errorbar(bptime, bpmeds, yerr=bpstds, color='k', ecolor='r')
        plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"BPpulseLen")))
        plt.close()
    except Exception as eexcept:
        print("Error trying to plot BP Pulse lengths! {}".format(eexcept))
    return 0

def plot_rsa(sid, signame):
    print("plotting rsa")
    
    rsaphase = loadf(sid,signame)
    try:
        rsaphaseR = loadf(sid,"hrsaphaseR")
    except FileNotFoundError:
        rsaphaseR = loadf(sid,"hrsaphase")
    rridiff = loadf(sid,"hrridiff")
    try:
        rridiffR = loadf(sid,"hrridiffR")
    except FileNotFoundError:
        rridiffR = loadf(sid,"hrridiff")
    rsastd = loadf(sid,"hrsastderr")
    timebeat = loadf(sid,"timebeat")

    ### load rri
    rri = loadf(sid,"hrri")
    try:
        rrir = loadf(sid,"hrriR")
    except FileNotFoundError:
        rrir = rri.copy()
        print('  hrriR not found.')
    print('  nr_rrir=',rrir.size)
    print('  nr_rri(filt)=',rri.size)
    
    tb_ix = np.argsort(timebeat)
    timebeat = timebeat[tb_ix]
    rri = rri[tb_ix]
    rrir = rrir[tb_ix]

    tspace, rmed, rstd = median_filt(timebeat, rrir, np.int(rri.size/NR_WINS))
    
    ### plot rri
    plt.figure()
    plt.suptitle("RRI {}".format(sid))
    plt.scatter(timebeat, rrir, color='k', marker='.', zorder=1,
                label='raw', rasterized=True)
    plt.scatter(timebeat, rri, color='r', marker='o',
                alpha=0.75, label='MAD filter', zorder=2,
                rasterized=True)
    plt.errorbar(tspace, rmed, yerr=rstd, color='b',
                 ecolor='c', label='median', zorder=0,
                 rasterized=True)
    # plt.xticks(tspace[::int(tspace.size/10)])
    plt.xlabel('time (sec)')
    plt.ylabel('rri (sec)')
    plt.legend(loc='best')
    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"rri")))
    plt.close()

    ### rri vs resp
    timeresp = loadf(sid, "timeresp")
    expd = loadf(sid,"lexpdur")
    inspd = loadf(sid,"linspdur")
    tdur = expd+inspd
    tresp, respmed, respstd = median_filt(timeresp, tdur, np.int(tdur.size/NR_WINS))
    rri_use = []
    resp_use = []
    for i in range(1,tresp.size):
        riw = rmed[np.argwhere((tspace > tresp[i-1]) & (tspace <= tresp[i]+tdur[i]))].flatten().tolist()
        if len(riw) > 0:
            rri_use.extend(riw)
            resp_use.extend([respmed[i],]*len(riw))

    phase_ix = np.argsort(rsaphase)
    rridiff = rridiff[phase_ix] 
    rsaphase = rsaphase[phase_ix]
    
    rridiffR = rridiffR[np.argsort(rsaphaseR)]
    rrir = rrir[np.argsort(rsaphaseR)]
    rsaphaseR = np.sort(rsaphaseR)
    pmeds, rmeds, rstds = median_filt(rsaphaseR, rridiffR, 50)
    # print('rawstd=',np.max(rstds),'interpstd=',np.max(rsastd),'rri_std=',np.std(rri))
    
    ### plot RSA
    plt.figure()
    plt.suptitle("RSA {}".format(sid))
    # plt.plot(rsaphaseR, rrir - rrir.mean(), 'bx')
    # plt.plot(rsaphaseR, rridiffR, 'k.',label='raw')
    plt.plot(rsaphase, rridiff, 'c',label='rolling median')
    plt.hlines(y=0, xmin=0, xmax=1, linestyles='dashed', alpha=0.5)
    if isinstance(rsastd, np.ndarray):
        plt.fill_between(rsaphase, rridiff-rsastd, rridiff+rsastd, facecolor='r', lw=0, label="stderr")
    # plt.errorbar(pmeds, rmeds, rstds, color='b', alpha=0.5)
    plt.xlabel('Phase')
    plt.ylabel('RRI deviation (sec)')
    plt.xlim([0, 1])
    plt.legend(loc='best')
    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"RSA")))
    plt.close()
    
    ### plot rri dev
    plt.figure()
    plt.suptitle("RRIdev {}".format(sid))
    plt.plot(loadf(sid,"timebeat"), loadf(sid,"hrridiff"), 'b')
    plt.xlabel('time (sec)')
    plt.ylabel('rri_dev (sec)')
    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"rridev")))
    plt.close()

def plot_pi(sid, signame):
    print("plotting PI")
    pindex = loadf(sid,signame,np.int32)
    time_pm = loadf(sid,"tpm")
    plt.figure()
    plt.suptitle("PI {}".format(sid))
    plt.plot(time_pm / 60.0, pindex, label='PI')
    plt.xlabel('time (min)')
    plt.ylabel('Pulmonary index')
    plt.legend(loc='best')
    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"PI")))
    plt.close()
    
def plot_baroact(sid, signame):
    if not bpload: return 0
    print('plotting explicit baroact')
    timebaro = loadf(sid,"timebaro")
    baroact = loadf(sid,"baroact")
    wins = int(baroact.size/NR_WINS)
    print("  nr_baroact=",baroact.size)
    print("  win_size=", wins)
    print(" nr_wins=", NR_WINS)
    bspace = loadf(sid,"bspace")
    bmeds = loadf(sid,"baromed")
    bstds = loadf(sid,"bstds")
    plt.figure()
    plt.suptitle("Explicit Baroactivation {}".format(sid))
    plt.plot(timebaro, baroact, 'k.', markersize=1, rasterized=True)
    plt.errorbar(bspace, bmeds, yerr=bstds,
                 color='b', ecolor='c', rasterized=True)
    plt.xlabel('time (sec)')
    plt.ylabel("Baroactivation (sec/mmHg)")
    print("bspace.size=", bspace.shape,
          "bmeds.size=", bmeds.shape,
          "bstds.size=", bstds.shape)
    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"BaroActExpl")))
    plt.close()
    
def plot_spo2(sid, signame):
    print("plotting spo2")
    # time = loadf(sid,"time")
    time = loadf(sid,'timeresp')
    # plot spo2 v time
    spo2 = loadf(sid,signame)
    # spo2 = normalize(spo2)+1.0
    wins = int(spo2.size / NR_WINS)
    tspace, meds, stds = median_filt(time, spo2, wins, skipix=int(0.5*wins))
    plt.figure()
    plt.suptitle("SPO2 {}".format(sid))
    plt.errorbar(tspace, meds, yerr=stds, color='k', ecolor='c')
    plt.xlabel('time (sec)')
    plt.ylabel('SPO2 (% saturation)')
    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"spo2")))
    plt.close()
    
def load_plot(sid, signame):

    rcolor = 'm'
    rls = 0.7
    ralpha = 0.85
    
    print("  ", sid, signame)

    try:
        time = loadf(sid,'time','float64')
        print("regular time")
        if signame in ['linspdur','lexpdur']:
            print("insp/exp time")
            time = loadf(sid,'timeresp')
        sig = loadf(sid,signame,'float64')
        print(time.size, sig.size)
    except FileNotFoundError as EE:
        print(EE, signame)
        return

    if time.size > sig.size: time = time[:sig.size]

    if time[-1] == 0.0: time[-1] = time[-2] + (time[-2] - time[-3])
    if sig.size == 0: sys.exit("{} size was 0.".format(signame))
    
    plt.figure()
    plt.suptitle("{} {}".format(signame,sid))    
    try:
        if "ecg" in signame:
            beat_ix = np.fromfile(os.path.join(cardio_dir, "{}_{}.cardio".format("beatix",sid)),dtype=np.int32)
            try:
                ecgR = loadf(sid,'hecgR','float64')
            except FileNotFoundError:
                ecgR = loadf(sid,'hecg','float64')
        elif "tv" in signame:
            if sig.size < 1e4: sys.exit("\n\ntv size less than 1e4")
            try:
                tvR = loadf(sid,'ltvR','float64')
            except FileNotFoundError:
                tvR = loadf(sid,'ltv','float64')
            exp0ix = loadf(sid,'lexp0ix',np.int32)
            insp0ix = loadf(sid,'linsp0ix',np.int32)

        ### Tidal Volume, ECG, Blood Pressure
        #### ZOOMED FIGURE
        if signame in ["ltv", 'hecg', 'bp'] or "z" in signame:
            try:
                plt.figure()
                plt.suptitle("{} {} zoomed".format(signame,sid))
                plt.plot(time, sig, lw=1.5, c='k', rasterized=True)
                if signame == 'bp':
                    # tvbp = loadf(sid,"ltv",'float64')
                    print(' --> bpmean = ', bp.mean())
                    print("bpmax=",bp.max())
                    print("bpmin=",bp.min())
                    try:
                        bpsynth = loadf(sid,"bpsynth")
                        plt.plot(time, bpsynth, color="r", label="BP Synth", rasterized=True)
                    except Exception as bpex:
                        print(bpex)
                        print("bp synth not loaded.\n")
                elif "tv" in signame:
                    print("exp0ix size {:d} ; insp0ix size {:d}".format(exp0ix.size,
                                                                    insp0ix.size))
                    print(time.size, tvR.size, sig.size)
                    if tvR.size != time.size: tvR = sig
                    plt.plot(time, tvR, rcolor, lw=rls, alpha=ralpha, rasterized=True)
                    plt.plot(time[exp0ix], sig[exp0ix], color='#ff6666',
                             ls='', marker='o',label='exp0', rasterized=True)
                    plt.plot(time[insp0ix], sig[insp0ix], color='#2233AA',
                             ls='', marker='o',label='insp0', rasterized=True)
                    print("plotted ltv")
                if "ecg" in signame:
                    plt.plot(time[beat_ix], sig[beat_ix], "r*",ms=10, rasterized=True)

                # set xlim for zoom
                sig[np.isnan(sig)] = 0
                mnix = int( 0.0 / sample_rate ) # from
                szoom = time[-1]-time[mnix] # from + srate*szoom
                if os.environ.get("MNIX"):
                    mnix = int(int(os.environ.get("MNIX")) * sample_rate)
                if os.environ.get("SZOOM"):
                    szoom = int(os.environ.get("SZOOM"))
                print("  MNIX = ",mnix,"; SZOOM = ",szoom)
                sigrng = sig[mnix:mnix+int(szoom*sample_rate)]
                plt.xlim([time[mnix], time[mnix]+szoom])

                # Plot med-std threshold
                if 'tv' in signame:
                    lmed = np.median(sig)
                    plt.axhline(lmed, xmin=0, xmax=plt.xlim()[1],
                                ls="--", c='#ff9933', label='median')
                    lstd = np.std(sig)
                    plt.axhline(lmed-0.5*lstd, xmin=0, xmax=plt.xlim()[1],
                                ls="--", c='#00ff00', label='median-0.5*std')
                    plt.axhline(lmed-lstd, xmin=0, xmax=plt.xlim()[1],
                                ls="--", c='#0066ff', label='median-std')
                    print("plotted med-std thresh")
                plt.ylim([sigrng.min()-sigrng.std(), sigrng.max()+sigrng.std()])
                print("set ylim")
                plt.xlabel("time (sec)")
                plt.ylabel("{}".format(signame))
                plt.legend(loc='best')
                print("saving figure")
                plt.savefig(save_path("{}/_{}_{}_zoomed.svg".format(sid,sid,signame)))
                plt.savefig(save_path("{}/_{}_{}_zoomed.png".format(sid,sid,signame)))
                plt.close()
                
                if "tv" in signame: # Plot inspiration - expiration durations
                    print("loading insp/expd")
                    inspd = loadf(sid, "linspdur")
                    expd = loadf(sid, "lexpdur")
                    print("inspd size {:d} expd size {:d}".format(inspd.size,
                                                                  expd.size))
                    plt.figure()
                    plt.suptitle("Insp/Exp {}".format(sid))
                    plt.plot(expd, inspd, 'k.', rasterized=True)
                    plt.xlabel("Exp. dur. (sec)")
                    plt.ylabel("Insp. dur. (sec)")
                    x1 = inspd.max() if inspd.max() > expd.max() else expd.max()
                    y1 = x1
                    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"inspdexpd")))
                    plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"inspdexpd")))
                    plt.close()

                    tresp = loadf(sid, "timeresp")

                    # plot expiration vs time
                    tspace_e, emeds, estds = median_filt(tresp, expd, 50)
                    plt.figure()
                    plt.suptitle("Expiration vs time {}".format(sid))
                    # plt.scatter(tresp, expd, 'k',marker=None)
                    plt.errorbar(tspace_e, emeds,
                                 yerr=estds, color='r',
                                 ecolor='c',lw=1.5,
                                 rasterized=True)
                    plt.xlabel('time (sec)')
                    plt.ylabel('Te (sec)')
                    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"ExpVtime")))
                    plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"ExpVtime")))
                    plt.close()
                    
                    # plot insp vs time
                    tspace_i, imeds, istds = median_filt(tresp, inspd, 50)
                    plt.figure()
                    plt.suptitle("Inspiration vs time {}".format(sid))
                    plt.errorbar(tspace_i, imeds, yerr=istds, color='r',ecolor='c',lw=1.5)
                    plt.xlabel('time (sec)')
                    plt.ylabel('Ti (sec)')
                    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"InspVtime")))
                    plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"InspVtime")))
                    plt.close()

                    tdur = expd+inspd
                    tspace, tmeds, tstds = median_filt(tresp,tdur,50)

                    # plot heart stroke volume
                    plt.figure()
                    plt.suptitle("Stroke volume{}".format(sid))
                    svtime=loadf(sid, "svtime",'float64')
                    svl=loadf(sid,"stroke_vol",'float64')
                    svspace, svmeds, svstds = median_filt(svtime, svl, 50)
                    print("svtime end: ",svtime[-1], "svpspace end: ",svspace[-1])
                    plt.errorbar(svspace, svmeds, yerr=svstds, color='k',ecolor='c',lw=1.5,label="SV")
                    plt.plot(svtime, svl, "gx", zorder=0, label="raw SV", rasterized=True)
                    plt.xlabel("time (sec)")
                    plt.legend()
                    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"svol")))
                    plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"svol")))
                    
                    # plot total resp cycle duration 
                    plt.figure()
                    plt.suptitle("Resp cycle duration {}".format(sid))
                    plt.plot(tresp,tdur,'k.',rasterized=True)
                    plt.errorbar(tspace,tmeds,yerr=tstds,color='b',ecolor='c',lw=1.5)
                    plt.ylabel('sec')
                    plt.xlabel("time resp")
                    plt.savefig(save_path("{}/_{}_{}.svg".format(sid,sid,"respdur")))
                    plt.savefig(save_path("{}/_{}_{}.png".format(sid,sid,"respdur")))
                    plt.close()
            except IndexError as E1:
                print(signame, E1)
                pass

    except (FileNotFoundError, OSError) as E2:
        print(signame, E2)
        pass
    
if __name__ == "__main__":

    if len(sys.argv[1:]) == 2:
        sid, signame = sys.argv[1:]
        sid = sid.replace("_","-")
        signames = [signame,]
        
    elif len(sys.argv[1:]) < 2 or ('A0' in sys.argv[1] and len(sys.argv[1:])==1):
        signames = sorted([os.path.splitext(fn)[0] for fn in os.listdir(cardio_dir) if os.path.splitext(fn)[1] == '.cardio'],
                          key=lambda x: os.path.getmtime(x+".cardio"), reverse=True)
        
        if len(sys.argv[1:]) == 1:
            sid = sys.argv[-1]
        else:
            sid = signames[0].split("_")[1]
        sid = sid.replace("_", "-")
        print("SID= ",sid)
        signames = sorted(list(set([sn.split("_")[0] for sn in signames])))

    # Set sampling rate
    time0 = loadf(sid, "time")
    sample_rate = int(1.0 / (time0[1] - time0[0]))

    # read the experimental condition windows (sec)
    parse_cond_wins(sid)
    
    # Create save directory
    savedir = save_path("{}".format(sid))
    if not os.path.exists(savedir):
        try:
            os.makedirs(savedir)
        except OSError as mkErr:
            print(mkErr)
            pass
    
    print("\n  sampling rate = {} \n".format(sample_rate))

    Qarr = np.loadtxt(os.path.join(cardio_dir, "Q_{}.cardio").format(sid),
                      dtype='float64',delimiter=",", ndmin=2)
    Q = Qarr[:,0]
    NR_WINS = Q.size

    print("\n  nr_wins = ", NR_WINS)
    
    # Write descriptive stats to txt file
    hrri = loadf(sid, "hrri")
    inspd = loadf(sid, "linspdur")
    expd = loadf(sid, "lexpdur")
    try:
        bp = loadf(sid, "bp")
        ave_bp = np.median(bp)
        min_bp, max_bp = np.min(bp), np.max(bp)
        bpload = True
    except FileNotFoundError:
        pass
    ave_hr = 60.0 / np.median(hrri)
    max_hr = np.max(60.0 / hrri)
    min_hr = np.min(60.0 / hrri)
    min_resp = 60.0 / (np.max(inspd)+np.max(expd))
    med_resp = 60.0 / (np.median(inspd)+np.median(expd))
    max_resp = 60.0 / (np.min(inspd)+np.min(expd))
    with open(save_path("{}/stats_{}.txt".format(sid,sid)), "w") as fst:
        fst.write("\n min_hr \t med_hr \t max_hr  |  beats/min")
        fst.write("\n {:.4f} \t {:.4f} \t {:.4f}  +- {:.4f}".format(min_hr,ave_hr,max_hr,np.std(hrri)))
        fst.write("\n")
        if bpload:
            fst.write("\n min_bp \t med_bp \t max_bp  |  mmHg")
            fst.write("\n {:.4f} \t {:.4f} \t {:.4f}  +- {:.4f}".format(min_bp,ave_bp,max_bp,np.std(bp)))
            fst.write("\n")
        fst.write("\n min_RespR \t med_RespR \t max_RespR  |  breaths/min")
        fst.write("\n {:.4f} \t {:.4f} \t {:.4f}  +- {:.4f}".format(min_resp,med_resp,max_resp,np.std(inspd+expd)))
        fst.write("\n")
        
        # fst.write("\nave_insp_dur={:.4f} sec; ave_exp_dur={:.4f} sec".format(inspd.mean(),expd.mean()))
        # fst.write("\nmedian_insp_dur={:.4f} sec; median_exp_dur={:.4f} sec".format(np.median(inspd),np.median(expd)))

    # Plot all signals found
    rsaseg_done = False
    for signame in signames:
        try:
            if signame in ["ltv", "hecg",
                           "linspdur", "lexpdur",
                           "bp",] or "z" in signame:
                print(signame)
                load_plot(sid, signame)
            elif signame in ["bpplen"]:
                print(signame)
                plot_bplen(sid, signame)
            elif signame in ["hrsaphase"]:
                print(signame)
                plot_rsa(sid, signame)
            elif signame in ["hcvcphase"]:
                print(signame)
                plot_cvc(sid, signame)
            elif signame in ["Q"]:
                print(signame)
                plot_q(sid, signame)
            elif "rsaseg" in signame and not rsaseg_done:
                rsaseg_done = True
                plot_rsaseg(sid, signame)
            else: print("{} not found".format(signame))
            print('  done\n')
        except IndexError as index_error_message:
            print('index error in {}: {}'.format(signame,index_error_message))

    try:
        cdf = np.loadtxt(save_path("{}/_{}_cvcCDF.txt".format(sid,sid)))
        Qarr = np.loadtxt(os.path.join(cardio_dir, "Q_{}.cardio").format(sid),
                          dtype='float64',delimiter=",", ndmin=2)
        Q = Qarr[:,0]
        cdfplot = cdf[:Q.size] if Q.size < cdf.size else cdf
        Qplt = Q[:cdf.size] if cdf.size < Q.size else Q
        Rcoef = ((cdfplot - cdfplot.mean())*(Qplt-Qplt.mean())).sum() /\
                ( np.sqrt( ((cdfplot - cdfplot.mean())**2).sum() ) * np.sqrt( ((Qplt - Qplt.mean())**2).sum() ) )
        with open(save_path("{}/stats_{}.txt".format(sid,sid)), "a") as fst:
            fst.write("\n")
            fst.write("\n minRSA \t medRSA \t maxRSA  |  sec")
            fst.write("\n {:.4f} \t {:.4f} \t {:.4f}  +- {:.4f}".format(np.min(Q),np.median(Q),np.max(Q),np.mean(Qarr[:,1])))
            fst.write("\n")
            fst.write("\n R( RSA(t), CVC(t) ) = {:.3f}".format(Rcoef,))
    except OSError:
        pass
