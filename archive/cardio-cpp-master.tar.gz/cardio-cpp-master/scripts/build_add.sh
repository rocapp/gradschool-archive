#!/bin/bash

# builds, then asks if the subject ID should be added to the list of usable subjects

export -p SID=$1 TESTS=test_hdf5 H5=1 CONFIG=./config/$1.ini

echo Removing old rsasegment files...

rm -v /home/rocapp/Documents/cardio-output/rsaseg_*

echo Building...

cd /home/rocapp/Git/cardio-cpp && make runtest

echo Plotting...

echo `./scripts/plot.py ${SID/_/-} hcvcphase` &

ask_use()
{
    echo "Add this subject to usable.txt? (y/n) "
    read boolvar;
    if [ "$boolvar" = "y" ]
    then
	echo $SID >> "./usable.txt"
	echo Added.
    fi
}

if [ -f "usable.txt" ]
then
    ask_use;
else
    touch "usable.txt"
    ask_use;
fi

exit;
