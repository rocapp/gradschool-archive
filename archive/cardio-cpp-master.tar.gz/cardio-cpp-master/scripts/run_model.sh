#!/usr/bin/env bash

TESTS=test_model

CARDIO_SRC=${CARDIO_SRC:-/home/$USER/Git/cardio-cpp/}
CARDIO_SRC=$(realpath -ms $CARDIO_SRC)
printf '%s\n' "$CARDIO_SRC"

CARDIO_OUT=${CARDIO_OUT:-/home/$USER/Documents/cardio-output/}
CARDIO_OUT=$(realpath -ms $CARDIO_OUT)
printf '%s\n' "$CARDIO_OUT"

CARDIO_DATA=${CARDIO_DATA:-/home/$USER/Git/cardio-cpp/data/}
CARDIO_DATA=$(realpath -ms $CARDIO_DATA)
printf '%s\n' "$CARDIO_DATA"

CONFIG=${CONFIG:-$CARDIO_SRC/config/$1.ini}
printf '%s\n' "$CONFIG"

CARDIO_FIG=${CARDIO_FIG:-/home/$USER/public_html/sepsis_data/figs/}
CARDIO_FIG=$(realpath -ms $CARDIO_FIG)
printf '%s\n' "$CARDIO_FIG"
sleep 1;

export -p SID=$1 H5=1 TESTS CARDIO_FIG CARDIO_DATA CARDIO_SRC CARDIO_OUT CONFIG

# If configuration file does not exist, copy the default one
[[ ! -e "$CONFIG" ]] &&\
    echo `cp ./config/config_000.ini $CONFIG &&\
    sed -i "s/REC_NAME.*/$SID/" $CONFIG &&\
    sed -i "s/HDF5_NAME.*/$DFN/" $CONFIG &&\
    echo created config file : $CONFIG &&\
    echo DFN=$DFN &&\
    echo ` || echo Config file already exists.

echo Removing old rsasegment files...
echo

set +x
rm -v $CARDIO_OUT/rsaseg_*
set -x

set -e # any failures beyond here will cause an exit

cd $CARDIO_SRC && make runtest

sleep 1;

echo Plotting...
echo

[[ $TESTS == "test_model" && ! $SID == *"test-model"* ]] && SID="test-model-${SID}"

echo `cp $CONFIG "$CARDIO_FIG/$SID/_${SID}_config_$(date +%s).txt"`

echo `./scripts/plot.py`
