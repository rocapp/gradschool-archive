#ifdef __NVCC__
#include <cuda.h>
#endif

#include "model_output.h"
#include <string>
#include <iostream>
#include <vector>
#include "config.h"

int main(int argc, char** argv)
{

  printf("running model simulation...\n");
  
  if(argc < 2)
    {
      printf("error! no config file defined... please refer to the usage description below:\n");
      printUsage();
      exit(0);
    }

  Config conf(argc, argv);
  SaveData saver(conf.cmap["opath"]); // saver class instance
  static Model m(conf.cmap["i"], conf.cmap["dpath"], &saver, conf.dparams);

  printf("...running model.setup()...\n");
  m.debug = 1;
  m.setup(conf);
  printf("...finished model.setup().\n\n");

  // set the internal model parameters from the configuration object
  parameters params = parameters();
  parameters *pparams = &params; 
  std::map<std::string, double*> paddr;
  pset params_set(params, pparams, paddr);
  conf.setParams(params_set, conf.params, 1);
  
  m.run(params_set.pparams);
  printf("saving to folder : %s...\n", saver.output_folder.c_str());
  m.save(conf.cmap["record"]);
  printf("==model sim success==\n");
  return 0;
}
