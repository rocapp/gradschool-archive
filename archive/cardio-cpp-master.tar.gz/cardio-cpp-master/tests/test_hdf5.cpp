#include "load_data.h"
#include <iostream>
#include <string>
#include "config.h"
#include <sys/resource.h>

using namespace std;


int main(int argc, char** argv)
{

  // modify the stack size if needed
  const rlim_t stacksz = (int) 9 * 1024 * 1e6;
  struct rlimit rlim;
  int result;
  result = getrlimit(RLIMIT_STACK, &rlim);
  if (result == 0){
    if (rlim.rlim_cur < stacksz){
      std::cout << "\nstack size changed." << std::endl;
      rlim.rlim_cur = stacksz;
      result = setrlimit(RLIMIT_STACK, &rlim);
      if (result != 0){
	std::cout << "\n!ERROR CODE TRYING TO CHANGE STACK SIZE: " << result << std::endl;
      }
    }
  }

  Config conf(argc, argv); // load config
  SaveData saver(conf.cmap["opath"]); // saver class instance
  static H5DB data(conf.cmap["i"], conf.cmap["dpath"], &saver, conf.dparams); // instantiate data class
  data.debug = 1; // debug switch
  data.sfreq = conf.fs; // set sampling frequency
  data.dfn = conf.cmap["dfn"]; // set data file name
  std::cout << "dpath set to " << conf.cmap["dpath"] << std::endl;
  std::cout << "dfn set to " << conf.cmap["dfn"] << std::endl;
  std::cout << "sampling freq set to: " << data.sfreq << std::endl;
  std::cout << "instantiated data class.\n" << std::endl;
  data.load(); // load hdf5 data
  data.process_data(0);
  
  std::cout << "\nnow saving..." << std::endl;
  data.save_qmap(conf.cmap["i"], conf.cmap["opath"]);
  data.save(conf.cmap["i"]);

  
  return 0;
}
