#include <iostream>
#include "config.h"
#include "parameters.h"
#include <string>
#include <map>

int main(int argc, char **argv){

  Config config(argc, argv);

  parameters params = parameters();
  parameters *pparams = &params;
  std::map<std::string, double*> paddr;
  pset params_set(pparams, paddr);
  
  config.setParams(params_set, config.params, 1);

  std::cout << "\nparams_set.rsa1=" << params_set.pparams->rsa1;

  config.setParam(params_set, "rsa1", 15.99, 0);

  std::cout << "\nparams_set.rsa1=" << params_set.pparams->rsa1;

  parameters params1 = parameters();
  parameters *pparams1 = &params1;
  std::map<std::string, double*> paddr1;
  pset params_set1(pparams1, paddr1);

  config.setParams(params_set1, config.params, 1);

  std::cout << "\nparams_set1.rsa1=" << params_set1.pparams->rsa1;

  config.setParam(params_set1, "rsa1", 13.2, 0);

  std::cout << "\nparams_set1.rsa1=" << params_set1.pparams->rsa1;

  std::cout << "\nparams_set.rsa1=" << params_set.pparams->rsa1;

  

  std::cout << std::endl;
  
  return 0;
}
