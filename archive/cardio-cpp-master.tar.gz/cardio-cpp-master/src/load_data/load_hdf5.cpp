#include "load_data.h"
#include <iostream>
#include "utils.h"
#include <algorithm>
#include <stdlib.h>
#include <stdio.h>
#include <map>
#include <utility>
#include <numeric>

void positive_signal(std::vector<double>& signal);
void positive_signal(std::vector<double>& signal)
{
  if(signal.size() > 0)
    {
      double minsg = *std::min_element(signal.begin(), signal.end());
      if(minsg < 0)
	{
	  for(double& sg: signal)
	    sg += std::abs(minsg);
	}
    }
}

void H5DB::thresh_bp()
{
  std::cout << "thresholding blood pressure (bpmin = " << dparams.bpminmax[0] << ") "
	    << " (bpmax = " << dparams.bpminmax[1] << ")" << std::endl;
  if(dparams.bpminmax[0]>0)
    {
      double medbp = median_full(bp);
      if(medbp > dparams.bpminmax[1] || medbp < dparams.bpminmax[0])
	medbp = dparams.bpminmax[0]+(dparams.bpminmax[1]-dparams.bpminmax[0])/3.0;
      std::cout << "median bp (thresholded values replaced with this) = " << medbp << std::endl;
      for(double& bpv: bp)
	{
	  if(bpv < dparams.bpminmax[0] || bpv > dparams.bpminmax[1])
	    bpv = medbp;
	}
    }
}

// read attributes, based on this example: http://web.mit.edu/fwtools_v3.1.0/www/Intro/IntroExamples.html#ReadWriteAttributes
herr_t attr_info(hid_t loc_id, const char *name, void *opdata)
{
  H5std_string sepname("t0");
  std::vector<ChannelMap>* opmap  = static_cast<std::vector<ChannelMap>*>(opdata);
  if (std::string(name).compare(std::string(sepname)) != 0)
    {
      int vix;
      hid_t attr_id = H5Aopen(loc_id, name, H5P_DEFAULT);
      H5Aread(attr_id, H5T_NATIVE_INT, &vix);
      const H5std_string vname(name);
      printf("  %s : %d\n", name, vix);
      ChannelMap vpair(vname, vix);
      opmap->push_back(vpair);
    }
  return 0;
}

void H5DB::load()
{
  std::cout << "loading hdf5 file: " << dpath << dfn << std::endl;
  
  // load main file
  const H5std_string fn(dpath + dfn);

  H5File file(fn, H5F_ACC_RDONLY);
  std::cout << "\nfile found and open." << std::endl;

  // open rec_dataset
  DataSet dset(file.openDataSet( db ));
  DataType dtype(dset.getDataType());
  DataSpace dspace(dset.getSpace());
  const int npts = dspace.getSimpleExtentNpoints();
  hsize_t dims_out[2];
  const int ndims = dspace.getSimpleExtentDims(dims_out, NULL); // get dimensionality of dataset
  std::cout << "\nnpts(total)=" << npts << std::endl;
  std::cout << "ndims=" << ndims << std::endl;
  std::cout << (unsigned long) dims_out[0] << " x " << (unsigned long) dims_out[1] << std::endl;

  // info for loading data into vectors
  FloatType fltype = dset.getFloatType();
  H5std_string order_string;
  H5T_order_t order = fltype.getOrder( order_string );
  size_t size = fltype.getSize();

  // map channel index to channel name via attributes
  std::vector<ChannelMap> channel_map;
  hid_t fileiter = H5Fopen((const char*)fn.c_str(), H5F_ACC_RDONLY, H5P_DEFAULT);
  hid_t dsetiter = H5Dopen(fileiter,(const char*)db.c_str());
  int vidx = H5Aiterate(dsetiter, NULL, attr_info, &channel_map);
  printf("done with h5aiterate.\n");
  
  // load data
  printf("dims_out[0]=%d ; dims_out[1]=%d\n",(int)dims_out[0], (int)dims_out[1]);
  _load(order, size, dset, dspace, (int)dims_out[0], channel_map);

  // is this the sepsis one?
  const H5std_string sepname("t0");
  bool issep = dset.attrExists( sepname );
  std::cout << "\nissep=" << issep << std::endl;

  std::cout << "\ntv_size=" << tv.size() << std::endl;
  positive_signal(tv);
  std::cout << "ecg_size=" << ecg.size() << std::endl;
  positive_signal(ecg);
  std::cout << "spo2_size=" << spo2.size() << std::endl;
  positive_signal(spo2);
  std::cout << "v_size=" << v_vect.size() << std::endl;
  positive_signal(v_vect);
  std::cout << "bp_size=" << bp.size() << std::endl;
  positive_signal(bp);
  thresh_bp(); // threshold BP
  double bpmean = 0.0;
  std::cout << "bp_mean=" << std::accumulate(bp.begin(), bp.end(), bpmean) / (int)(bp.size()) << std::endl;
  
  // define time vector
  time = linspace(0, (double) tv.size() / sfreq, tv.size());

  // if t0 sepsis is defined, get the attribute
  if (issep)
    {
      Attribute sep0(dset.openAttribute(sepname));
      int rdsep[1];
      sep0.read(PredType::NATIVE_INT, rdsep);
      int sep_ix = rdsep[0];
      std::cout << "\n  sep_ix = " << sep_ix << std::endl;
    }

  H5Dclose(dsetiter);
  H5Fclose(fileiter);
  
  
}

void H5DB::_load(H5T_order_t order, size_t size,
		 DataSet dset, DataSpace dspace,
		 int npts,
		 std::vector<ChannelMap> channel_map)
{

  int nr_chans = (int)channel_map.size();
  printf("  nr_chans=%d\n",nr_chans);
  printf("  npts=%d\n",npts);
  
  // allocate buffer
  double dbuf[npts][nr_chans];
  printf("allocated dbuf.\n");

  // memspace to define size of output buffer
  hsize_t dimsm[2] = {(hsize_t)npts, (hsize_t)nr_chans};
  printf("allocated dimsm.\n");
  DataSpace memspace(2, dimsm);
  printf("allocated memspace.\n");
  
  memspace.selectAll();
  dspace.selectAll();

  std::cout << "order=" << order << " size=" << size << std::endl;
  std::cout << "dspace nselected=" << dspace.getSelectNpoints() << " mspace nselected=" << memspace.getSelectNpoints() << std::endl;

  if ( order==0 )
    {
      if (size == 4)
	{
	  dset.read((double**)dbuf, PredType::IEEE_F32LE, memspace, dspace);
	  std::cout << "  float32 data" << std::endl;
	}
      else if (size == 8)
	{
	  dset.read((double**)dbuf, PredType::IEEE_F64LE, memspace, dspace);
	  std::cout << "  float64 data" << std::endl;
	}
    }
  else if (order == 1)
    {
      if (size == 4)
	{
	  dset.read((double**)dbuf, PredType::IEEE_F32BE, memspace, dspace);
	}
      else if (size == 8)
	{
	  dset.read((double**)dbuf, PredType::IEEE_F64BE, memspace, dspace);
	}
    }

  std::cout << "finished reading to dbuffer." << std::endl;

  for (int i=0; i < npts; i++)
    {      
      for ( auto& kv : channel_map)
	{
	  // printf("kv.name=%s\n",kv.name.c_str());
	  // printf("kv.ix=%d\n",kv.ix);
	  if (kv.name=="CO2")
	    {
	      tv.push_back(dbuf[i][kv.ix]);
	    }
	  else if(kv.name=="BP"||
		  kv.name=="PA2"||
		  kv.name=="CVP3"||
		  kv.name=="CVP2")
	    {
	      bp.push_back(dbuf[i][kv.ix]);
	    }
	  else if(kv.name == "II")
	    {
	      ecg.push_back(dbuf[i][kv.ix]);
	    }
	  else if(kv.name=="SPO2")
	    {
	      spo2.push_back(100.0-dbuf[i][kv.ix]);
	    }
	  else if(kv.name=="V")
	    {
	      v_vect.push_back(dbuf[i][kv.ix]);
	    }
	}
    }

  std::cout << "\nfinished storing dbuf to vectors." << std::endl;
    
}
