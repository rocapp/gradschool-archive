var searchData=
[
  ['dataparams',['dataParams',['../structdataParams.html',1,'']]],
  ['db',['DB',['../classDB.html',1,'']]]
];
