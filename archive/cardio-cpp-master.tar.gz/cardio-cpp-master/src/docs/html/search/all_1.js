var searchData=
[
  ['beat_5fix',['beat_ix',['../classDB.html#af16b2a562fe543a11831b777494a7fd2',1,'DB']]],
  ['beatix',['Beatix',['../structBeatix.html',1,'']]]
];
