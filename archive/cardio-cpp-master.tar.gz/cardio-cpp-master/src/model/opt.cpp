#include "opt.hpp"
#include "utils.h"
#include <vector>

float RandomNumber () { return (float)(rand()) / (RAND_MAX); }

std::vector<float> Optimizer::train_once_supervised(std::vector<float> x, std::vector<float> y)
{
  X_train.push_back(p_); // current parameters
  R_train.push_back(cost_func(x, y)); // current residual
  if((int)X_train.size() > 1)
    {
      float rd = 0.0;
      for(int ri=0; ri < (int)X_train.back().size(); ri++)
	{
	  rd += std::abs(X_train.back().at(ri) - X_train.at(X_train.size()-2).at(ri));
	}
      if(rd <= 1e-2*sigma*sigma/(float)(X_train.size()))
	{
	  converged = true;
	  return p();
	}
      std::vector<float> jc((int)M_,0);
      for(int pi=0; pi < (int)M_; pi++)
	{
	  jc.at(pi) = 2.0*(sigma*sigma+R_train.back().at(pi)-R_train.at(R_train.size()-2).at(pi)) /
			(p_.at(pi)-X_train.at(X_train.size()-2).at(pi)+sigma); // jacobian estimate
	  p_.at(pi) -= sigma * jc.at(pi);
	}
      Jac.push_back(jc);
      if((int)Jac.size() > 1)
      	{
      	  for(int pi=0; pi < (int)M_; pi++)
      	    {
      	      p_.at(pi) -= 4.0 * sigma * sigma *
      		(jc.at(pi)-Jac.at(Jac.size()-2).at(pi)) * (R_train.at(R_train.size()-2).at(pi)-R_train.back().at(pi));
      	    }
      	}
    }
  else
    {
      for(int pi=0; pi < (int)M_; pi++)
	{
	  p_.at(pi) -= sigma * p_.at(pi);
	}
    }    
  return p();
}

std::vector<float> Optimizer::train_once_modelfree(std::vector<float> rwd)
{
  R_train.push_back(rwd); // latest reward
  if((int)R_train.size() > 2)
    {
      for(int pi=0; pi < (int)M_; pi++)
	{

	  /* 
	     reinforcement (with sigma as the learning rate),
	     Inversely proportional to number of times visited (N_visits)
	  */
	  p_.at(pi) += sigma * rwd.at(pi) / N_visits.at(pi);

	  /*
	    Temporal difference learning
	    previous rewards are averaged with the most recent reward, weighted by recency
	    (gamma as the temporal constant)
	  */
	  if((int)R_train.size() > 10)
	    {
	      for(int ri=9; ri > 2; ri--)
		p_.at(pi) += R_train.at((int)R_train.size()-ri).at(pi)*gamma/ri;
	    }

	  /*
	    Decay of reward, increases with N_Visits
	    (beta as decay constant)
	  */
	  p_.at(pi) -= beta * N_visits.at(pi) * R_train.at((int)R_train.size()-2).at(pi);
	}
      
      // cap reward [-1, 1]
      for(int pj=0; pj < (int)M_; pj++)
	{
	  if(p_.at(pj) > 1.0)
	    p_.at(pj) = 1.0;
	  if(p_.at(pj) < -1.0)
	    p_.at(pj) = -1.0;
	}
    }
  return p();
}
