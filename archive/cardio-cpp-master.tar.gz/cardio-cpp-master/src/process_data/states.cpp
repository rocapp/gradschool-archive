#include "process_data.h"
#include "utils.h"
#include <string>
#include <numeric>
#include <iostream>
#include <fstream>

void States::appendPro(std::string signame,
		       int swsize,
		       std::vector<int> ixs,
		       std::vector<double> time, //!<< windowed time (one for each index in ixs)
		       std::vector<double> mags,
		       std::vector<double> errs)
{
  // turn off stdout for this function
  stbuff = std::cout.rdbuf();
  std::ofstream dnull("/dev/null");
  std::cout.rdbuf(dnull.rdbuf());
  freopen("/dev/null","w",stdout);
  
  printf("\n  --> appending pro-states for signal: %s ...\n", signame.c_str());
  ProState cpr(signame, swsize);
  cpr.ixs = std::set<int>(std::make_move_iterator(ixs.begin()),
			  std::make_move_iterator(ixs.end()));
  cpr.time = time;
  for(auto &tt : cpr.time)
    printf("   ---> pro-state time : %.3f,\n", tt);
  cpr.trans = mags;
  cpr.errs = errs;
  signames.push_back(signame);
  prostates.push_back(cpr);

  std::cout.rdbuf(stbuff);
  
}

void States::identifyProStates()
{

  // turn off stdout for this function
  stbuff = std::cout.rdbuf();
  std::ofstream dnull("/dev/null");
  std::cout.rdbuf(dnull.rdbuf());
  freopen("/dev/null","w",stdout);
  
  double diffwin, errwin;
  for( auto& sig : signals )
    {
      wsize = (int)(sig.size()/nwins);
      int si = &sig - &signals[0];
      ProState pstate(signames[si], wsize);
      printf("\n  ** created prostate for %s **\n", pstate.name.c_str());
      double sigdiff[sig.size()];
      std::adjacent_difference(sig.begin(), sig.end(), sigdiff);
      printf(" ...took adjacent difference.\n");
      std::vector<double> sigdiff1(sigdiff, sigdiff+sig.size());
      printf("  ...grabbing sigtime vector\n");
      std::vector<double> sigtime = sigtimes[si];
      printf("  ...grabbed sigtime vector.\n");
      for(int i=0; i < nwins; i++)
	{
	  std::vector<double> dwin(sigdiff1.begin()+i*wsize,
				   sigdiff1.begin()+(i+1)*wsize);
	  diffwin = 2*( *std::max_element(dwin.begin(), dwin.end()) ) +
	    3*pow(*std::max_element(dwin.begin(), dwin.end()) -
		  *std::min_element(dwin.begin(), dwin.end()), 2);
	  errwin = stand_dev(dwin);
	  errwin /= sqrt((double)(wsize));
	  std::vector<double> win(sig.begin()+i*wsize,
				  sig.begin()+(i+1)*wsize);
	  double winmed = median_full(win);
	  printf("  errwin = %.5f ; winamp = %.4f\n", winmed + diffwin);
	  if(true) //errwin <= 2*std::abs(winmed*diffwin))
	    { // store each possible state in the pstate struct
	      pstate.trans.push_back(winmed);
	      pstate.errs.push_back(errwin);
	      pstate.ixs.insert(i);
	      pstate.time.push_back(sigtime[i*wsize]);
	      printf("   ...prostate: %d : %.1f ; trans=%.5f +- %.5f\n\n", i, sigtime[i*wsize], diffwin, errwin);
	    }
	}
      prostates.push_back(pstate);
    }
  std::cout.rdbuf(stbuff);
}

void States::combineStates()
{
  
  // Find the intersection of ixs for all prostates[si].
  // For the indices ixs where all signals are present,
  // make a new State(ix).

  // turn off stdout for this function
  stbuff = std::cout.rdbuf();
  std::ofstream dnull("/dev/null");
  std::cout.rdbuf(dnull.rdbuf());
  freopen("/dev/null","w",stdout);
  
  std::set<int> unique_ixs;
  int isin = 0;
  int pix, tmpi;
  printf("  combining prostates from %d signals...\n", (int)prostates.size());
  for(auto &pstate : prostates)
    {
      for(auto &ptime : pstate.time)
	{
	  pix = &ptime - &pstate.time[0];
	  tmpi = *std::next(pstate.ixs.begin(), pix);
	  if(unique_ixs.find(tmpi)!=unique_ixs.end())
	    continue;
	  isin = 0;
	  for(auto &pstate1 : prostates)
	    {
	      if(pstate1.name == pstate.name)
		continue;
	      for(auto &ptime1 : pstate1.time)
	      	{
		  if(
		     std::abs(ptime1 - ptime) <= ttol &&
		     *std::next(pstate.ixs.begin(),&ptime1 - &pstate1.time[0]) == tmpi
		     )
		    {
		      isin += 1;
		      break;
		    }
		}
	    }
	  // printf("   ===> isin counter for pstate %s_%d : %d\n",
		 // pstate.name.c_str(), tmpi, isin);
	  if(isin >= prostates.size()-1)
	    {
	      printf("  -> unique prostate %d is usable.\n", tmpi);
	      unique_ixs.insert(tmpi);
	    }
	}
    }
  printf("\n\n === Creating ensemble of unique states...\n");
  int ixix = 0;
  for(auto &uix : unique_ixs)
    {
      printf("  --> unique_ix = %d\n", uix);
      State cstate(signames, uix);
      for( auto &pstate : prostates)
	{
	  if(pstate.ixs.find(uix) != pstate.ixs.end())
	    {
	      ixix = std::distance(pstate.ixs.begin(),
				   pstate.ixs.find(uix));
	      cstate.t.push_back(pstate.time.at(ixix));
	      cstate.M.push_back(pstate.trans.at(ixix));
	      cstate.E.push_back(pstate.errs.at(ixix));
	    }
	}
      states.push_back(cstate);
    }
  
  std::cout.rdbuf(stbuff);
}

void States::saveStates(std::string fn_ext,
			std::string output_dir)
{
  std::cout << "\n  saving states..." << std::endl;

  fn_ext = replace_underscores(fn_ext); // replace underscores in fn_ext
  
  std::ofstream mfile;
  std::string ext = ".txt";
  std::string fn = output_dir + "States_" + fn_ext + ext;
  mfile.open(fn, std::ios::out);
  std::string signame;
  char * strf = new char[1000];
  sprintf(strf, "%-10s, %-10s, %-10s, %-10s, %-10s ",
	  "Index", "Time", "Signal",
	  "Amp", "Err");
  mfile << std::string(strf) << "\n" << std::endl;
  delete[] strf;
  for (auto &state : states)
    {
      for(int i=0; i < state.signames.size(); i++)
	{
	  char * strf = new char[1000];
	  sprintf(strf, " %-10d, %-10d, %-10s, %-10.3e, %-10.3e \n",
		  state.ix,
		  (int)(state.t[i]),
		  state.signames[i].c_str(),
		  state.M[i], state.E[i]);
	  mfile << std::string(strf) << std::endl << std::endl;
	  delete[] strf;
	}
    }
  mfile.close();
}

ProState States::getPstate(std::string name)
{
  for( auto &pstate : prostates)
    {
      if(pstate.name == name)
	return pstate;
    }
}
