
#include "process_data.h"
#include <numeric>
#include <stdexcept>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <iterator>
#include "utils.h"
#include "kmeds.h"

void SaveData::save_double(std::string fn_ext, std::string signame, std::vector<double> sig)
{ // fn_ext = patient ID, signame = name of signal (e.g. 'time')
  
  std::cout << "\nsaving " << signame << std::endl;

  fn_ext = replace_underscores(fn_ext); // replace underscores in fn_ext

  std::ofstream mfile;
  std::string ext = ".cardio";

  std::string fn = output_folder + signame + "_" + fn_ext + ext;
  std::cout << " ... to file : " << fn << std::endl;
  
  mfile.open(fn, std::ios::out | std::ios::binary);
  mfile.write(reinterpret_cast<char*>(&sig[0]), sig.size() * sizeof(double));
  mfile.close();
}

void SaveData::save_int(std::string fn_ext, std::string signame, std::vector<int> sig)
{
  std::cout << "\nsaving " << signame << std::endl;

  fn_ext = replace_underscores(fn_ext); // replace underscores in fn_ext

  std::ofstream mfile;
  std::string ext = ".cardio";

  std::string fn = output_folder + signame + "_" + fn_ext + ext;
  mfile.open(fn, std::ios::out | std::ios::binary);
  mfile.write(reinterpret_cast<char*>(&sig[0]), sig.size() * sizeof(int));
  mfile.close();
}

void SaveData::save_dstats(std::string fn_ext, avgstats dstats)
{

  dstats.print();
  
  std::cout << "\nsaving dstats..." << std::endl;

  fn_ext = replace_underscores(fn_ext); // replace underscores in fn_ext

  std::ofstream mfile;
  std::string ext = ".cardio";

  std::string fn = output_folder + "dstats_" + fn_ext + ext;
  mfile.open(fn, std::ios::out | std::ios::binary);
  mfile.write(reinterpret_cast<char*>(&dstats.avg_rri), sizeof(double));
  mfile.write(reinterpret_cast<char*>(&dstats.avg_insp), sizeof(double));
  mfile.write(reinterpret_cast<char*>(&dstats.avg_exp), sizeof(double));
  mfile.write(reinterpret_cast<char*>(&dstats.err_rri), sizeof(double));
  mfile.write(reinterpret_cast<char*>(&dstats.err_resp), sizeof(double));
  mfile.write(reinterpret_cast<char*>(&dstats.N_rri), sizeof(int));
  mfile.write(reinterpret_cast<char*>(&dstats.N_resp), sizeof(int));
  mfile.close();
}

void DB::check_for_nans(){
  for (int i = 0; i < tv.size()-1; i++)
    {
      if( std::isnan(tv.at(i)) )
	{
	  tv[i] = tv[i+1];
	}
      if( std::isnan(ecg.at(i)) )
	{
	  ecg[i] = ecg[i+1];
	}
    }
}

void DB::resp_peaks()
{
  try {
  std::cout << "  finding CO2/TV phases..." << std::endl;
  printf("  co2/tv_size=%d ; resporder=%d\n",(int)tv.size(),dparams.resporder);
  std::cout << "e2i_minratio = " << dparams.e2i_minratio << std::endl;
  std::cout << "e2i_mindiff = " << dparams.e2i_mindiff << std::endl;
  if(ismodel == 0 && dparams.e0scale!=-999)
    {
      printf(" * using find_phase, which makes most sense with co2 data\n");
      find_phase(exp0_ix, insp0_ix, tv,
		 dparams.e0scale,
		 dparams.i0scale,
		 dparams.resporder);
    }
  else
    {
      printf(" * using find_peaks, which makes most sense with tidal volume\n");
      find_peaks(exp0_ix, tv, dparams.resporder, 1, "max", 0);
      find_peaks(insp0_ix, tv, dparams.resporder, 1, "min", 0);
      int nr_removed = 0;
      for(int ivx = insp0_ix.size()-1; ivx > 0; ivx--)
	{
	  int ek=exp0_ix.size()-1;
	  while(ek > 0)
	    { 
	      if( ( exp0_ix[ek-1] <= insp0_ix.at(ivx) && exp0_ix[ek] >= insp0_ix.at(ivx) ) &&
		 ( ( (tv[exp0_ix.at(ek)]/tv[insp0_ix.at(ivx)]) < dparams.e2i_minratio ) ||
		   ( std::abs(tv[exp0_ix.at(ek)] - tv[insp0_ix.at(ivx)]) <= dparams.e2i_mindiff ) )
		  )
		{
		  /* Uncomment this to print out a warning for each resp cycle removed */ 
		  // std::cout << "time=" << time[exp0_ix[ek]]
		  // 	    << " E2Idiff=" << std::abs(tv[exp0_ix.at(ek)]-tv[insp0_ix.at(ivx)])
		  // 	    << " E2Iratio=" << (tv[exp0_ix.at(ek)]/tv[insp0_ix.at(ivx)])
		  // 	    << std::endl;
		  exp0_ix.erase(exp0_ix.begin()+ek);
		  nr_removed++;
		  break;
		}
	      ek--;
	    }
	}
      std::cout << "  nr_exp_removed = " << nr_removed << std::endl;
    }
  std::cout << "  nr_exp0: " << exp0_ix.size()<<std::endl;
  std::cout << "  nr_insp0: " << insp0_ix.size()<<std::endl;
  std::cout << "  found CO2 phases." << std::endl;
  if(exp0_ix.size()==0||insp0_ix.size()==0)
    {
      throw std::runtime_error("  Not enough respiratory cycles produced/calculated.\n");
      dstats.avg_exp = -999; dstats.avg_insp = -999;
    }
  printf("  finding cycle durations...\n");
  double tin=0, tex=0, tex1=0, tresp=0, avg_insp=0, avg_exp=0, avg_resp=0, err_resp=0;
  int nr_cycles = 0;
  int k=0;
  std::vector<int> exp0temp, insp0temp;
  int nlowr=0, nlowi=0, nhighi=0;
  for(int i=0; i < exp0_ix.size()-1; i++)
    {
      tex = time[exp0_ix[i]];
      tex1 = time[exp0_ix[i+1]];
      
      while(k < insp0_ix.size())
	{
	  tin = time[insp0_ix[k]];
	  if(tin > tex)
	    {
	      break;
	    }
	  k += 1;
	}

      if(tex1 - tex < dparams.rlow)
	nlowr += 1;
      if(tex1 - tin < dparams.ilow)
	nlowi += 1;
      if(tex1 - tin > dparams.ithresh)
	nhighi += 1;
      
      if(
	 tin > tex && // inspiration starts after expiration
	 tex1 - tex <= dparams.rthresh && // total cycle duration limited
	 tex1 > tin && // next expiration starts after current
	 tex1 - tin < dparams.ithresh && // limit inspiration duration
	 tex1 - tex > dparams.rlow && // total cycle duration minimum
	 tex1 - tin > dparams.ilow && // inspuration duration minimum
	 tin - tex < dparams.ethresh // limit expiration duration
	 )
	{
	  insp_dur.push_back(tex1 - tin);
	  exp_dur.push_back(tin - tex);
	  co2_diff.push_back(std::abs(tv[insp0_ix[k]] - tv[exp0_ix[i]]));
	  resp_rate.push_back(60.0/(tex1-tex));
	  tresp = (tex + tin) / 2.0;
	  time_resp.push_back(tresp);
	  respdur.push_back(tex1-tex);
	  resp_ix.push_back(i);
	  exp0temp.push_back(exp0_ix[i]);
	  insp0temp.push_back(insp0_ix[k]);
	  time_exp0.push_back(tex);
	  avg_resp += (tex1 - tex);
	  avg_insp += (tex1 - tin);
	  avg_exp += (tin - tex);
	  nr_cycles += 1;
	}
    }
  // normalize co2_diff as percent
  normalize_d(co2_diff, 0.0, 50.0);
  printf(" nr_ilow=%d | nr_rlow=%d | nr_highI=%d \n",
	 nlowr, nlowi, nhighi);
  insp0_ix = insp0temp;
  exp0_ix = exp0temp;
  std::cout << "  insp_dur size= " << insp_dur.size() << "; exp_dur size= " << exp_dur.size() << std::endl;
  printf("  insp0_ix.size = %d; exp0_ix.size = %d\n",(int)insp0_ix.size(),(int)exp0_ix.size());
  printf("  finished finding cycle durations.\n");

  avg_insp /= (double) insp_dur.size();
  avg_exp /= (double) exp_dur.size();
  avg_resp /= (double) nr_cycles;
  for (int i=0; i < insp_dur.size(); i++)
    {
      err_resp += pow( (avg_resp - (insp_dur[i] + exp_dur[i])), 2);
    }
  err_resp /= (double) nr_cycles;
  err_resp = sqrt(err_resp);
  err_resp /= (double) sqrt(nr_cycles);
  
  dstats.avg_insp = avg_insp;
  dstats.avg_exp = avg_exp;
  dstats.err_resp = err_resp;
  dstats.N_resp = nr_cycles;

  std::cout << "avg_insp = " << avg_insp << " avg_exp = " << avg_exp << std::endl;
  
  } catch(std::exception& resp_excep)
    {
      std::cout << resp_excep.what() << std::endl;
      return;
    }  
}

void DB::heart_peaks()
{
  printf("\n  finding heart beats...\n");
  find_peaks(beat_ix, ecg, dparams.horder, 1, "max", 0);
  printf("  finished finding heart beats.\n\n");
  printf("  nr_beats=%d.\n",(int) beat_ix.size());
  printf("  cleaning/validating heart beats...\n");
  // for(int ei=0; ei < ecg.size(); ei++)
  //   ecg[ei] = ecg[ei] + ecg[ei]*bp[ei];
  clean_beats2(beat_ix,
	       ecg,
	       (int)(dparams.horder/2),
	       (int)(dparams.hlow*sfreq),
	       (int)(dparams.hthresh*sfreq),
	       dparams.hheight,
	       dparams.hmaxheight);
  printf("  beats were cleaned.\n");
  printf("  (after clean) nr_beats=%d.\n", (int) beat_ix.size());
  printf("\ndone with heart_peaks.\n\n");
}

void DB::calc_rsa()
{
  /* calculate rr interval and RSA phase,
     from [end of Expiration -> beginning of Expiration]
  */
  if(!ismodel)
    { // compute synthetic bp
      int bshift = 0;
      std::vector<int>::iterator itb;
      double dbp = 0.0;
      double taup = dparams.taup;
      double svb = dparams.bpminmax[1]-dparams.bpminmax[0];
      double po = dparams.bpminmax[0];
      bpsynth.push_back(bp.at(0));
      if(bpsynth.at(0) < po)
	bpsynth.at(0) = po;
      double tt=time.at(0);
      double hdt = 5e-3;
      int shift0 = (int)(sfreq*1.3);
      for(int ti=1; ti < (int)time.size(); ti++)
	{
	  po = dparams.bpminmax[0];
	  if(beat_ix.at(bshift) > shift0 && beat_ix.at(bshift)+100 < (int)bp.size())
	    {
	      auto bmin = std::min_element(bp.begin()+beat_ix.at(bshift)-shift0, bp.begin()+beat_ix.at(bshift)+100);
	      po = *bmin;
	    }
	  taup = dparams.taup;
	  if(bshift+1 < (int)beat_ix.size() && bshift > 0)
	    {
	      auto bmin1 = std::min_element(bp.begin()+beat_ix.at(bshift-1), bp.begin()+beat_ix.at(bshift+1));
	      int bx1 = std::distance(bp.begin(), bmin1);
	      taup = std::abs( time.at(bx1) - time.at(beat_ix.at(bshift)) );
	      if(taup < 0.1 || taup > 1.5*taup)
		taup = dparams.taup;
	      // printf("hb %d | taup = %.1f\n",bshift,taup);	      
	    }
	  while(dbp > po) // tt < time.at(ti)
	    {
	      dbp += hdt*(po-bpsynth.back())/taup;
	      tt += hdt;
	    }
	  itb = std::find(beat_ix.begin()+bshift, beat_ix.end(), ti);
	  if(itb!=beat_ix.end())
	    {
	      svb = dparams.bpminmax[1]-dparams.bpminmax[0];
	      bshift = (int)std::distance(beat_ix.begin(), itb);
	      if(beat_ix.at(bshift)+(int)shift0 < (int)bp.size())
	      	{
	      	  auto bminmax = std::minmax_element(bp.begin()+beat_ix.at(bshift), bp.begin()+beat_ix.at(bshift)+(int)shift0);
	      	  svb = std::abs(*bminmax.second-*bminmax.first);
		  // printf("hb %d | svb = %.1f\n",bshift,svb);
	      	}
	      dbp += svb;
	    }
	  bpsynth.push_back(dbp);
	  if(bpsynth.back() < po)
	    bpsynth.at((int)bpsynth.size()-1) = po;
	  if(bpsynth.back() > dparams.bpminmax[1])
	    bpsynth.at((int)bpsynth.size()-1) = dparams.bpminmax[1];
	}
    }
  double beat0, beat1, rri, middle, resp0, resp1, rphase, maph, maphs;
  int bix0, bix1, cbix=0;
  for(int t0=0; t0 < beat_ix.size()-1; t0++){
    bix0 = beat_ix.at(t0);
    bix1 = beat_ix.at(t0+1);
    beat0 = time.at(bix0);
    beat1 = time.at(bix1);
    if(!ismodel)
      {
	maph = calc_MAP(bp, bix0, bix1); // MAP (for one heart beat) vs resp phase
	bpresp_nat.push_back(maph);
	maphs = calc_MAP(bpsynth, bix0, bix1); // synth MAP (one heart beat) v resp phase
	bpresp_synth.push_back(maphs);
      }
    rri = beat1 - beat0;
    middle = (beat0 + beat1) / 2.0;
    if (rri <= dparams.hthresh && rri > dparams.hlow){
      for(int tj=0; tj < time_exp0.size()-1; tj++){
	resp0 = time_exp0[tj]; // end of previous expiration
	resp1 = time_exp0[tj+1]; // beginning of next expiration
	if ( middle < resp1 &&
	     middle > resp0 &&
	     resp1 - resp0 <= dparams.rthresh &&
	     resp1 - resp0 > dparams.rlow
	     ){
	  if(!ismodel)
	    {
	      double mapr = calc_MAP(bp, exp0_ix[tj], exp0_ix[tj+1]);
	      double bpmr = maph - mapr; // BP modulation vs resp phase
	      bpmresp_nat.push_back(bpmr);
	      bpmresp_synth.push_back( maphs - calc_MAP(bpsynth, exp0_ix[tj], exp0_ix[tj+1]) );
	    }
	  rphase = (middle-resp0)/(resp1-resp0); // synth bp modulation v resp phase
	  Beatix cbeat;
	  cbeat.ix = cbix;
	  cbeat.time_beat = middle;
	  cbeat.phase = rphase;
	  Bmap.push_back(cbeat);
	  rri_vect.push_back(rri);
	  rsa_phase.push_back(rphase);
	  hr_vect.push_back(60.0/(rri));
	  time_beat.push_back(middle);
	  cbix += 1;
	  break;
	}
      }
    }
  }

  saver->save_double(db, "hrsaphaseR", rsa_phase);
  saver->save_double(db, "hrriR", rri_vect);
  printf("  rsa_phase_size=%d ; rri_size=%d ; Bmap_size=%d\n",
	 (int)rsa_phase.size(), (int)rri_vect.size(),
	 (int)Bmap.size());
  if((int)rsa_phase.size()==0||(int)rri_vect.size()==0)
    return;

  double rri_mean = median_full(rri_vect);
  printf("  rri_mean=%.4f\n",rri_mean);
  dstats.avg_rri = rri_mean;
  double err_rri = compute_mad(rri_vect);
  std::vector<double>().swap(rri_diff);
  rri_diff.push_back(0);
  int dorder = (int)(0.85*rri_vect.size()/(double)(dparams.Qwins));
  printf("dorder=%d\n",dorder);
  for(int i=1; i < dorder; i++)
    rri_diff.push_back(rri_vect.at(i) - rri_vect.at(i-1));
  for(int i=dorder; i < rri_vect.size()-dorder; i++)
    {
      double rdiff = 0.0;
      for(int j=-dorder; j < dorder; j++)
	{
	  if(j!=0)
	    rdiff += (rri_vect.at(i) - rri_vect.at(i+j));//*std::abs(1.0*std::exp(-std::abs(pow(0.25*j,3))/pow(0.25*dorder,2)));
	}
      rri_diff.push_back(0.5*rdiff/dorder);
    }
  for(int i=1; i < dorder+1; i++)
    rri_diff.push_back(rri_vect.at(rri_vect.size()-i) - rri_vect.at(i-1));
  printf("  max(rri_diff)=%.4f ; ave(rri_diff)=%.4f ; min(rri_diff)=%.4f\n",
	 *std::max_element(rri_diff.begin(), rri_diff.end()),
	 compute_mean(rri_diff),
	 *std::min_element(rri_diff.begin(), rri_diff.end()));
  printf("  rsa_phase_size=%d ; rri_size=%d ; Bmap_size=%d\n",
	 (int)rsa_phase.size(), (int)rri_vect.size(),
	 (int)Bmap.size());
  printf("  rri_diff.size=%d\n",(int)rri_diff.size());
  saver->save_double(db, "hrridiffR", rri_diff);
  dstats.err_rri = err_rri;
  dstats.N_rri = (int) rri_vect.size();
  rsa_stderr.assign(dstats.N_rri,err_rri);

  for(int ri=0; ri < rri_diff.size(); ri++)
    {
      if(ri < Bmap.size())
	{
	  Bmap.at(ri).time_beat = time_beat.at(ri);
	  Bmap.at(ri).phase = rsa_phase.at(ri);
	  Bmap.at(ri).rri_diff = rri_diff.at(ri);
	}
    }
}

void DB::calc_b2i(){
  /* calculate the time from/to inspiration 
     for each heart beat,
     using the median inspiration duration as a window. */
  double med_insp = 1.0; //median_full(insp_dur);
  for(int tix=0; tix < insp0_ix.size(); tix++)
    {
      int inx = insp0_ix.at(tix);
      for(int& bix: beat_ix)
	{
	  if(std::abs(time[inx] - time[bix]) < med_insp)
	    {
	      beat2insp.push_back(time[bix]-time[inx]); // (negative is before, positive is after)
	      time_b2i.push_back(time[bix]);
	      cvc_phase.push_back((time[bix]-time[inx]));
	      time_cvc.push_back(time[bix]);
	    }
	}
    }
}

void DB::calc_cvc(){
  /* calculate CVC,
     from [onset of Inspiration -> onset of Inspiration]
     Also separately, [Inspiration(t) - med(Inspiration), Inspiration(t) + med(Inspiration)]
  */

  // calculate the distance of the CDF from the bisector (windowed)
  // uses KMedians, later is thresholded and averaged via states
  int winsize = (int)(cvc_phase.size()/dparams.Qwins);
  if(winsize < 2)
    return;
  // printf("  cvc winsize=%d\n", winsize);
  int i0 = 0, i1 = winsize, cdix = 0;
  double ave_bsize = 0;
  for(int i=0; i < dparams.Qwins-1; i++)
    {
      i0 = (int)(winsize*(i));
      i1 = (int)(winsize*(i+1));
      cvcixs.push_back(i);
      if(i1 >= beat2insp.size())
	break;
      std::vector<double> win(beat2insp.begin()+i0,
			      beat2insp.begin()+i1);
      KMeds kmi(win, 9); // k-medians class initialization
      kmi.calc();
      // printf("  --> kmi.magnitude = %.3f\n",kmi.magnitude);
      // printf("  --> kmi.err = %.3f\n",kmi.error);
      // printf("  --> kmi.nr_groups = %d\n",(int)(kmi.groups.size()));
      // printf("\n");
      ave_bsize += (double)kmi.groups.size();
      cvcdist.push_back(kmi.magnitude);
      cvcerr.push_back(kmi.error);
      cvctime.push_back(time_b2i.at((int)((i0+i1)/2.0)));
    }
  ave_bsize /= (double)(dparams.Qwins-1);
  // std::cout << "Average Number of Groups = " << ave_bsize << std::endl;
}

void DB::process_data(int lflag){

  stbuff = std::cout.rdbuf();
  
  if(debug!=1)
    { // turn off stdout if debug flag not set
      printf("*debugging off.*\n");
      std::ofstream dnull("/dev/null");
      std::cout.rdbuf(dnull.rdbuf());
      freopen("/dev/null","w",stdout);
    }

  std::cout << "\nstarting process_data." << std::endl;

  if(lflag==0)
    {

      check_for_nans();
      std::cout << "\nfinished checking nans." << std::endl;
      
      std::cout << "\nsaving raw data..." << std::endl;
      save_raw(db);

      heart_peaks();

      printf("  median filter of co2.\n");
      std::vector<std::vector<double>>W(1,std::vector<double>());
      tv = median_filter(tv, dparams.co2order, W);
      std::cout << "finished filtering." << std::endl;

      resp_peaks();
      std::cout << "finished resp_peaks\n" << std::endl;
      if(insp0_ix.size()==0||exp0_ix.size()==0)
	return;

      std::cout << "calculating RSA" << std::endl;
      calc_rsa();
      if((int)rsa_phase.size()==0||(int)rri_vect.size()==0)
	return;
      std::cout << "finished calc_rsa\n" << std::endl;

      std::cout << "calculating b2i...\n" << std::endl;
      calc_b2i();
      std::cout << "finished calc_b2i\n" << std::endl;
      
      std::cout << "calculating cvc" << std::endl;
      calc_cvc();
      std::cout << "finished calc_cvc\n" << std::endl;
      
      if(bp.size() > 0)
	{
	  printf("\ncalculating bp stuff...\n");
	  calc_bp();
	  printf("\ndone calculting bp.\n");
	}
      
    }

  std::cout << "\nFinding Qrsa..." << std::endl;
  printf("  ---> dparams.Qwins = %d\n", dparams.Qwins);
  interp_rsa_segs(dparams.Qwins, rsa_phase, rri_diff,
		  time_beat, Qmap,
		  saver->output_folder, db);

  printf("\ninterpolating entire RSA series...\n");
  double qc[3];
  std::vector<Beatix> BmapInterp = interp_rsa(qc, rri_diff.size(), Bmap);
  qcomps.assign(qc, qc+3);
  for(int i=0; i < BmapInterp.size(); i++)
    {
      time_rdinterp.push_back(BmapInterp.at(i).time_beat);
      rsa_phase.at(i) = BmapInterp.at(i).phase;
      rri_diff.at(i) = BmapInterp.at(i).rri_diff;
    }
  std::cout << "finished interpolating rsa.\n" << std::endl;
}

void DB::save_qmap(std::string fn_ext,
		   std::string output_dir)
{
  std::cout << "saving qmap..." << std::endl;

  fn_ext = replace_underscores(fn_ext); // replace underscores in fn_ext
  
  std::ofstream mfile, nfile, ofile;
  std::string ext = ".cardio";
  std::string fn = output_dir + "Q_" + fn_ext + ext;
  std::string fnn = output_dir + "qtime_" + fn_ext + ext;
  std::string fnnn = output_dir + "Qcomps_" + fn_ext + ext;
  mfile.open(fn, std::ios::out);
  nfile.open(fnn, std::ios::out);
  ofile.open(fnnn, std::ios::out);
  std::vector<std::string> clabels{"a0", "A", "B"};
  ofile << "#";
  for(int j=0; j < 3; j++)
    {
      ofile << clabels.at(j);
      if(j < 2)
	ofile << ",";
    }
  ofile << std::endl;
  double Q, Qerr;
  for (int i=0; i < Qmap.size(); i++)
    {
      Q = Qmap[i].Q;
      Qerr = Qmap[i].Qerr;
      mfile << std::to_string(Q) << "," << std::to_string(Qerr) << std::endl;
      nfile << std::to_string(Qmap[i].time) << std::endl;
      for(int j=0; j < 3; j++)
	{
	  ofile << std::to_string(Qmap[i].Qcomps[j]);
	  if(j < 2)
	    ofile << ",";
	}
      ofile << std::endl;
    }
  mfile.close();
  nfile.close();
  ofile.close();
}

void DB::save_raw(std::string fn_ext)
{
  fn_ext = replace_underscores(fn_ext); // replace underscores in fn_ext
  
  std::ofstream mfile;
  std::string ext = ".cardio";
  
  saver->save_double(fn_ext, "hecgR", ecg);
  saver->save_double(fn_ext, "ltvR", tv);  
}

void DB::save(std::string fn_ext){

  std::cout << "\nsaving to .cardio..." << std::endl;

  fn_ext = replace_underscores(fn_ext); // replace underscores in fn_ext
  
  std::ofstream mfile;
  std::string fn;

  // time
  saver->save_double(fn_ext, "time", time);
  saver->save_double(fn_ext, "timecvc", time_cvc);
  saver->save_double(fn_ext, "timebeat", time_beat);
  saver->save_double(fn_ext, "timeresp", time_resp);
  saver->save_double(fn_ext, "cvctime", cvctime);
  saver->save_double(fn_ext, "time_rdinterp", time_rdinterp);
  if(bp.size() > 0)
    {
      saver->save_double(fn_ext, "bpsystime", bpsystime);
    }
  saver->save_double(fn_ext, "svtime", svtime);
  saver->save_double(fn_ext, "beat2insp", beat2insp);
  saver->save_double(fn_ext, "time_b2i", time_b2i);
  
  // blood pressure
  if(bp.size() > 0)
    {
      saver->save_double(fn_ext, "bp", bp);
      saver->save_double(fn_ext, "svol_diff", svol_diff);
      saver->save_double(fn_ext, "stroke_vol", stroke_vol);
      saver->save_int(fn_ext, "bp_maxs", bp_maxs);
      saver->save_int(fn_ext, "bp_mins", bp_mins);
      saver->save_int(fn_ext, "bp_pulseix", bp_pulseix);
      saver->save_double(fn_ext, "bpplen", bp_len); // pulse time lengths
      saver->save_int(fn_ext, "bp_pulseix1", bp_pulseix1);
      saver->save_double(fn_ext, "bpsynth", bpsynth); // synthetic BP
      saver->save_double(fn_ext, "bpresp_synth", bpresp_synth); // bp vs resp phase (synth)
      saver->save_double(fn_ext, "bpmresp_synth", bpmresp_synth); // bpm vs resp phase (synth)
      saver->save_double(fn_ext, "bpresp_nat", bpresp_nat); // bp vs resp phase (measured)
      saver->save_double(fn_ext, "bpmresp_nat", bpmresp_nat); // bpm vs resp phase (measured)
    }
  
  if(bp.size() > 0)
    {
        saver->save_double(fn_ext, "bpsysdiff", bpsysdiff);
    }
  
  // heart signals
  saver->save_double(fn_ext, "qcomps", qcomps);
  saver->save_int(fn_ext, "beatix", beat_ix);
  saver->save_double(fn_ext, "hrri", rri_vect);
  saver->save_double(fn_ext, "hrridiff", rri_diff);
  saver->save_double(fn_ext, "hrsastderr", rsa_stderr);
  saver->save_double(fn_ext, "hrsaphase", rsa_phase);
  saver->save_double(fn_ext, "hcvcphase", cvc_phase);
  saver->save_double(fn_ext, "hecg", ecg);
  saver->save_double(fn_ext, "cvcdist", cvcdist);
  saver->save_double(fn_ext, "cvcerr", cvcerr);
  
  // Lung signals
  saver->save_int(fn_ext, "lexp0ix", exp0_ix);
  saver->save_int(fn_ext, "linsp0ix", insp0_ix);
  saver->save_double(fn_ext, "linspdur", insp_dur);
  saver->save_double(fn_ext, "lexpdur", exp_dur);
  saver->save_double(fn_ext, "respdur", respdur);
  saver->save_double(fn_ext, "ltv", tv);

  // save dstats
  saver->save_dstats(fn_ext, dstats);
  
  std::cout << "\nData saved with ID: " << fn_ext << "\n" << std::endl;
}

void DB::calc_bp()
{
  printf("bp.size=%d\n",(int)bp.size());
  if(ismodel==0)
    {
      // std::vector<std::vector<double>>W(1,std::vector<double>());
      // bp = median_filter(bp, (int)(dparams.bporder), W);
      find_peaks(bp_maxs, bp, dparams.horder, 1, "max", 0);
      find_peaks(bp_mins, bp, dparams.horder, 1, "min", 0);
    }
  else
    {
      double bpd=0, bpr=0;
      double bpMAD = compute_mad(bp), bpMED = median_full(bp);
      for(int bi=0; bi < (int)bp.size()-1; bi++)
      	{
      	  bpd = bp.at(bi+1)-bp.at(bi);
      	  bool bcheck = true;
      	  if(bpd < 0 && bpr >=0 && bp.at(bi) >= bpMED+bpMAD*dparams.bpMinMaxScale[1])
      	    {
	      bp_maxs.push_back(bi);
      	    }
      	  else if(bpd > 0 && bpr < 0 && bp.at(bi) <= bpMED-bpMAD*dparams.bpMinMaxScale[0])
      	    {
	      bp_mins.push_back(bi);
      	    }
	  bpr = bpd;
      	}
    }
  printf("bp_mins=%d bp_maxs=%d\n",(int)bp_mins.size(),(int)bp_maxs.size());

  /* Blood pressure modulation calc */
  bpsysdiff.push_back(0);
  bpsystime.push_back(0);
  for(int sy=dparams.bporder; sy < bp_mins.size()-dparams.bporder; sy++)
    {
      double bpsd = 0.0;
      for(int sj=-dparams.bporder; sj < dparams.bporder; sj++)
	if(sj!=0)
	  bpsd += std::abs(bp.at(bp_mins.at(sy))-bp.at(bp_mins.at(sy+sj)))/2.0;
      bpsd /= dparams.bporder;
      bpsysdiff.push_back(bpsd);
      bpsystime.push_back(time.at(bp_mins.at(sy)));
    }
  for(int sy=2; sy < dparams.bporder; sy++)
    {
      bpsysdiff.push_back(std::abs(bp.at(bp_mins.at(bp_mins.size()-sy))-bp.at(bp_mins.at(bp_mins.size()-sy+1)))/2.0);
      bpsystime.push_back(time.at(bp_mins.at(bp_mins.size()-sy)));
    }

  std::cout << "finished calculating bp modulation.\n";
  
  for(const auto& bmn : bp_mins)
    {
      int bx=0;
      int blim=bp_maxs.size()-1;
      while(bx < blim)
	{
	  int bpre = bp_maxs.at(bx);
	  int bpost = bp_maxs.at(bx+1);
	  if(bpre < bmn && bpost > bmn)
	    {
	      double svol = ( bp.at(bpre) - bp.at(bmn) + bp.at(bpost) - bp.at(bmn) ) / 2.0;
	      // if(svol > 30 && svol < 75)
		{
		  stroke_vol.push_back( svol );
		  svtime.push_back(time.at(bmn));
		  break;
		}
	    }
	  bx+=1;
	}
    }
  
  // double svave = median_full(stroke_vol);
  svol_diff.push_back(0.0);
  if(stroke_vol.size() > 1)
    {
      for(int si=0; si < svtime.size()-1; si++)
	{
	  svol_diff.push_back(std::abs(stroke_vol.at(si) - stroke_vol.at(si+1)));
	}
    }
  std::cout << "finished calculating stroke volume\n";
  
  /* find blood pressure pulses, widths */  
  double pi, pi1;
  double pmed = median_full(bp);
  for(int i=0; i < bp.size()-1; i++)
    {
      pi = bp[i];
      pi1 = bp[i+1];
      // std::cout << "pi=" << pi << " pi1=" << pi1 << " pmed=" << pmed << std::endl; 
      if(pi < pmed && pi1 >= pmed)
	{
	  bp_pulseix.push_back(i);
	}
      else if (pi > pmed && pi1 <= pmed)
	{
	  bp_pulseix1.push_back(i); // end of pulse wave
	}
    }
  printf("bp_pulseix.size=%d\n",(int)bp_pulseix.size());
  printf("bp_pulseix1.size=%d\n",(int)bp_pulseix1.size());

  // find bp pulse lengths (sec)
  int ix1=0, pix1;
  for(int pix0 : bp_pulseix)
    {
      while(ix1 < bp_pulseix1.size())
	{
	  pix1 = bp_pulseix1[ix1];
	  if(pix1>pix0)
	    {
	      bp_len.push_back(time[pix1]-time[pix0]);
	      break;
	    }
	  ix1+=1;
	}
    }
  std::cout << "finished calculating pulse widths\n";
  dstats.avg_bp = compute_mean(bp);
  dstats.err_bp = stand_dev(bp);
  std::cout << "finished calc_bp\n";
}
