#include <set>
#include <utility>
#include <cmath>
#include <string>
#include <iostream>
#include <stdio.h>
#include <vector>
#include <algorithm>

#ifndef UTILS_H
#define UTILS_H
#include "utils.h"
#endif

#include "kmeds.h"

std::string replace_underscores(std::string fn_ext)
{
  // replace underscores in fn_ext
  std::vector<std::string::size_type> epos;
  std::string::size_type pos;
  for(int i=0; i<fn_ext.size(); i++){
    pos = fn_ext.find('_', i);
    if (pos != std::string::npos){
      epos.push_back(pos);
    }
  }
  for(int i=0; i<epos.size(); i++){
    fn_ext.replace(epos[i], 1, std::string("-"));
  }
  return fn_ext;
}

double beat(double phi) { return( pow( (1+sin(phi*2.0*M_PI))/2, 20 )); }

std::vector<double> cvertf2d(std::vector<float> vec)
{
  std::vector<double> vecd;
  for(float& vf: vec)
    vecd.push_back((double)vf);
  return vecd;
}

std::vector<float> cvertd2f(std::vector<double> vecd)
{
  std::vector<float> vecf;
  for(double& vd: vecd)
    vecf.push_back((float)vd);
  return vecf;
}

std::vector<double> normalize_d(std::vector<double> signal,
				double nMin, double nMax)
{
  // normalize the signal vector from nMin to nMax
  auto extrema = std::minmax_element(signal.begin(), signal.end());
  std::vector<double> sigcopy(signal), sigout;
  for(int si=0; si < (int)signal.size(); si++)
    {
      sigout.push_back(nMin + ( (nMax-nMin)*(sigcopy.at(si)-*extrema.first)/(*extrema.second-*extrema.first) ));
    }
  return sigout;
}

std::vector<float> normalize_f(std::vector<float> signal,
			        float nMin, float nMax)
{
  // normalize the signal vector from nMin to nMax
  auto extrema = std::minmax_element(signal.begin(), signal.end());
  std::vector<float> sigcopy(signal), sigout;
  for(int si=0; si < (int)signal.size(); si++)
    {
      sigout.push_back(nMin + ( (nMax-nMin)*(sigcopy.at(si)-*extrema.first)/(*extrema.second-*extrema.first) ));
    }
  return sigout;
}

std::vector<double> linspace(double start, double end, int num)
{
  int parts = num - 1;
  std::vector<double> pts;
  double length = (end - start) / parts;
  pts.push_back(start);
  for(int i=1; i < num -1; i++){
    pts.push_back(start + i * length);
  }
  pts.push_back(end);
  return pts;
}

double median(std::vector<double> vec)
{ // vector version
  double med = vec.size() % 2 != 0 ? vec.at(vec.size()/2) : (vec[vec.size()/2]+vec[vec.size()/2+1])/2.0;
  return med;
}

double median(double vec[], int n)
{ // array version
  double med = n % 2 != 0 ? vec[n/2] : (vec[n/2]+vec[n/2+1])/2.0;
  return med;
}

double median_full(std::vector<double> vec)
{
  std::sort(vec.begin(), vec.end());
  double med = median(vec);
  return med;
}

double compute_mean(std::vector<double> vec)
{
  double ave=0.0;
  for(double& v: vec)
    ave += v;
  return (ave/(double)(vec.size()));
}

double stand_dev(std::vector<double> vec)
{
  double vmean=0, vstd=0;
  for(int i=0; i<vec.size(); i++)
    {
      vmean += vec[i];
    }
  vmean /= vec.size();
  for(int i=0; i<vec.size(); i++)
    {
      vstd += pow(vec[i] - vmean,2);
    }
  vstd /= vec.size()-1;
  vstd = sqrt(vstd);
  return vstd;
}

double calc_MAP(std::vector<double> bp, int x0, int x1)
{
  auto bprels = std::minmax_element(bp.begin()+x0, bp.begin()+x1);
  return *bprels.first + (*bprels.second-*bprels.first)/3.0; // mean arterial pressure (standard definition)
}

std::vector<double> combine_signals(std::vector<double> sig0,
				    std::vector<double> sig1)
{
  std::vector<double> stemp(sig0);
  for(int i=0; i < sig0.size(); i++)
    {
      stemp[i] = sig0[i] + (std::abs(sig0[i]))*std::abs(sig1[i]);
    }
  return stemp;
}

void clean_peaks(std::vector<int>& pks, int mode)
{ /* remove bias in respiratory phase transitions */
  std::vector<int> rmpks;
  int rix;
  for(int i=0; i < pks.size()-1; i++)
    {
      if(std::abs(pks[i] - pks[i+1]) <= 120) // if two peaks are close,
  	{
	  rix = (mode==0) ? i : i+1; // mode=0: i, mode=1: i+1
  	  rmpks.push_back(rix); // indicate the current peak should be removed (by convention)
  	}
    }
  for(int i=rmpks.size()-1; i >= 0; i--) // iterate in reverse order to maintain index
    {
      pks.erase(pks.begin()+rmpks[i]);
    }
}

void find_peaks(std::vector<int>& pks_out,
		std::vector<double> signal,
		int order,
		int skip,
		std::string mode, // mode = "min" or "max"
		int concat=0) 
{

  /* peak finder

     output: a sorted int vector whose elements are indices of the peaks found
      in the signal vector.
     
     args: 
       pks_out = reference to vector that will contain the output indices of peaks.
       signal = the input signal vector.
       order = the number of points each point will be compared to, in order to
         determine whether it's a peak.
       skip = number of points to skip when iterating through the signal vector.
       mode = either "min" or "max"
       concat = is the pks_out vector a previously used vector
  */
  
  std::function<bool(double,double)> comparator;
  if (mode == "min"){
    comparator = std::less_equal<double>();
  } else if (mode == "max"){
    comparator = std::greater_equal<double>();
  }

  std::vector<int> pks;
  int is_pk = 1;
  int pshift, sshift;
  for(int ix=0; ix<signal.size(); ix+=skip)
    {
      is_pk = 1;
    
      for(int shift=1; shift < order+1; shift++)
	{
	  pshift = ix+shift < signal.size() ? ix+shift : signal.size()-1;
	  sshift = ix-shift >= 0 ? ix-shift : 0;
	  is_pk = ( comparator(signal.at(ix), signal.at(pshift)) &
		    comparator(signal.at(ix), signal.at(sshift)) )
	    ? 1 : 0;
	  if(is_pk == 0)
	    {
	      break;
	    }
	}
    
      if (pks.size() > 0 && is_pk == 1)
	{
	  if (pks.back() != 1)
	    {
	      pks.push_back(is_pk);
	    }
	  else
	    {
	      pks.push_back(0);
	    }
	}
      else
	{
	  pks.push_back(is_pk);
	}
    }

  int ixx;
  for(int i=0; i<pks.size(); i++)
    {
      if (pks.at(i) == 1)
	{
	  ixx = i;
	  if(concat>0)
	    {
	      ixx += concat;
	    }
	  pks_out.push_back(ixx);
	}
    }
  if(concat > 0)
    { // sort the output vector if it is not empty
      std::sort(pks_out.begin(), pks_out.end());
    }
}

std::vector<int> find_closest_int(std::vector<int> v1, std::vector<int> v2)
{
  /* Find the integer in v2 that's closest to each element in v1 */
  std::vector<int> closest;
  for(int& val1: v1)
    {
      std::vector<int> tmpv;
      for(int& val2: v2)
	{
	  tmpv.push_back(std::abs(val1 - val2));
	}
      closest.push_back(v2.at(std::distance(tmpv.begin(), std::min_element(tmpv.begin(), tmpv.end()))));
    }
  return closest;
}

void clean_beats2(std::vector<int>& beatix,
		  std::vector<double> ecg,
		  int horder,
		  int h,
		  int h1,
		  double hheight,
		  double hmaxheight)
{ // remove beats that are too close/far in proximity or aren't the right amplitude to be R peaks
  int nh=0, nh1=0, nl=0, nm=0;
  std::vector<int> tmpbeats;
  std::vector<double> tmpecg;
  int maxix = 0;
  for(int i=beatix.size()-1; i > 0; i--)
    {
      if(beatix[i] - beatix[i-1] < h |
	 ecg[beatix[i]] < hheight |
	 ecg[beatix[i]] > hmaxheight)
	{
	  if(beatix[i] - beatix[i-1] < h)
	    nh += 1;
	  else if(ecg[beatix[i]] < hheight)
	    nl += 1;
	  else if(ecg[beatix[i]] > hmaxheight)
	    nm += 1;
	  beatix.erase(beatix.begin()+i);
	}
      else if(beatix[i] - beatix[i-1] >= h1) // too long rri
	{
	  nh1 += 1;
	  tmpecg.assign(ecg.begin()+beatix[i-1], ecg.begin()+beatix[i]);
	  find_peaks(tmpbeats, tmpecg, horder, 1, "max", 0);
	  if(tmpbeats.size() > 0)
	    {
	      maxix = 0;
	      for(int k=1; k < tmpbeats.size(); k++)
	  	{
	  	  if(ecg[tmpbeats[k]+beatix[i-1]] >= ecg[tmpbeats[k-1]+beatix[i-1]])
	  	    {
	  	      maxix = k;
	  	    }
	  	}
	      std::vector<double>().swap(tmpecg);
	      if(tmpbeats[maxix]+beatix[i-1] > beatix[i-1] &&
	  	 tmpbeats[maxix]+beatix[i-1] < beatix[i] &&
	  	 beatix.begin()+i !=					\
	  	 std::find(beatix.begin(), beatix.begin()+i, tmpbeats[maxix]+beatix[i-1])
	  	 )
	  	beatix.insert( beatix.begin()+i-1, tmpbeats[maxix]+beatix[i-1] );
	      std::vector<int>().swap(tmpbeats);
	    }
	  else
	    {
	      beatix.insert(beatix.begin()+i-1, (int)(beatix[i-1] + horder*2));
	    }
	}
    }
  printf("clean params: \n   horder=%d, hlow=%d, hmax=%d\n", horder, h, h1);
  printf("cleaning results: \n  nr_too_close=%d; nr_too_far*=%d; nr_too_short=%d; nr_too_high=%d\n",
	 nh, nh1, nl, nm);
}

std::vector<int> clean_beats(std::vector<int> beatix,
			     std::vector<double> ecg,
			     double hn, double hp)
{
  /* Where are the actual heart beats?
     Are they close to the chosen maxima?
     Is there another maximum close-by that is more likely 
     to be a heart beat? */
  double ei, ei1, dif, bdiff;
  int bii,bix,bcnt;
  bool bad = false;
  std::vector<int> beatix_new(beatix), pkstemp;
  std::vector<double> etemp;
  
  for (int ii=beatix.size()-2; ii >= 0; ii--)
    {
      bix = beatix[ii];
      ei = ecg[bix];
      
      bad = false;
      bcnt = 0;
      for(int ip=-1; ip >= -hn; ip--)
	{
	  bii = bix+ip > 0 ? bix+ip : 1;
	  ei = ecg[bii-1];
	  ei1 = ecg[bii];
	  dif = ei1 - ei; // (higher - lower)
	  if (dif < 0)
	    {
	      // printf("bad.\n");
	      bcnt += 1;
	      if (bcnt > 1)
		{
		  bad = true;
		}
	      break;
	    }
	}
      for(int in=1; in <= hp; in++)
	{
	  bii = bix+in < ecg.size()-1 ? bix+in : ecg.size()-1;
	  ei1 = ecg[bii];
	  ei = ecg[bii+1];
	  dif = ei1 - ei; // (higher - lower)
	  if (dif < 0)
	    {
	      // printf("bad.\n");
	      bcnt += 1;
	      if (bcnt > 1)
		{
		  bad = true;
		}
	      break;
	    }
	}
      
      bdiff = std::abs(bix-beatix[ii+1]);
      if (bad)
	{
	  beatix_new.erase(beatix_new.begin()+ii);
	}
      else if(bdiff<100) // 150
	{
	  beatix_new[ii+1] = (bix + beatix[ii+1]) / 2.0;
	  beatix_new.erase(beatix_new.begin()+ii);
	}
    }
  return beatix_new;
}

std::vector<double> rolling_median(std::vector<double> signal, int h)
{
  std::vector<double> stemp(signal);
  for(int i=h; i < signal.size()-h; i++)
    {
      std::vector<double> win(signal.begin()+i-h, signal.begin()+i+h);
      stemp.at(i) = median_full(win);
    }
  for(int i=0; i < h; i++)
    {
      stemp[i] = (stemp[i] + stemp[i+1] + stemp[i+2]) / 3.0;
      stemp[stemp.size()-h+i-1] = ( stemp[stemp.size()-h+i-1] + stemp[stemp.size()-h+i] + stemp[stemp.size()-h+i+1] ) / 3.0;
    }
  return stemp;
}

void find_phase(std::vector<int> &exp0_ix,
		std::vector<int> &insp0_ix,
		std::vector<double> signal,
		double e0_scale,
		double i0_scale,
		int h)
{
  /* compute the points where inspiration, expiration occur,
     given a co2 time series */
  // double med = median_full(signal);
  double med;
  printf("  computing rolling median of co2 trace.\n");
  std::vector<double> sigmed = rolling_median(signal, h);
  printf("  done with median of co2 trace.\n");
  double sstd = stand_dev(signal);
  printf("  i0scale=%.1f, e0scale=%.1f\n",i0_scale,e0_scale);
  printf("  find_phase: med=%.4f ; sstd=%.4f\n",med,sstd);
  double diff;
  for(int i=0; i < signal.size()-1; i++)
    {
      med = sigmed.at(i);
      diff = signal[i+1]-signal[i];
      if(diff > 0 && signal[i]<med-sstd*e0_scale) // 3.0 for A084
	{ // exp0 occurs as an increase from below
	  exp0_ix.push_back(i);
	}
      else if(diff < 0 && signal[i]>=med-sstd*i0_scale && signal[i]<=med)
	{ // insp0 occurs as a decrease from above
	  insp0_ix.push_back(i);
	}
    }
}
 
double compute_mad(std::vector<double> vec)
{ /* compute the median absolute difference: median{ |xi - x_med| } */
  std::sort(vec.begin(), vec.end());
  double med = median(vec);
  double mad,ad;
  std::vector<double> vtemp(vec);
  for(int i = 0; i < vtemp.size(); i++)
    {
      ad = std::abs( vec[i] - med );
      vtemp[i] = ad;
    }
  std::sort(vtemp.begin(), vtemp.end());
  mad = median(vtemp);
  return mad;
}

std::vector<double> cap_median(std::vector<double> signal, int h)
{
  /* find the median at each "cap" (begin, begin+h) and ( end-h, end) of a vector */ 
  double medi,mede;
  std::vector<double> stemp(signal), wtempi(h), wtempe(h);
  wtempi.assign(signal.begin(), signal.begin()+h);
  wtempe.assign(signal.end()-h, signal.end());
  medi = median_full(wtempi);
  mede = median_full(wtempe);
  for(int i=0; i < h; i++)
    {
      stemp[i] = medi;
      stemp[stemp.size()-1-i] = mede;
    }
  return stemp;
}

std::vector<std::vector<double>> rolling_median2(std::vector<double> signalx,
						std::vector<double> signaly,
						int h)
{
  double wmed;
  std::vector<double> w(h);
  std::vector<std::vector<double>> out(2,std::vector<double>());
  for(int i=0; i < signaly.size()-h; i++)
    {
      w.assign(signaly.begin()+i,signaly.begin()+i+h);
      wmed = median_full(w);
      out[1].push_back(wmed);
      w.assign(signalx.begin()+i,signalx.begin()+i+h);
      wmed = median_full(w);
      out[0].push_back(wmed);
    }
  return out;
}

std::vector<double> median_filter(std::vector<double> signal,
				  int h,
				  std::vector< std::vector<double> >& W)
{
  double med;
  std::vector<double> w(2*h+1);
  std::vector<double> stemp(signal);
  for(int i = h; i < signal.size()-h; i++)
    {
      w.assign(signal.begin()+i-h,signal.begin()+i+h);
      med = median_full(w);
      stemp[i] = med;
      if(W.size() == (int)(signal.size()/h) &&
	 i % h == 0 &&
	 i < W.size())
	{
	  W[i].swap(w);
	}
    }
  return stemp;
}

std::vector<double> median_perc_filter(std::vector<double> signal, int h)
{
  double med,mad,wstd;
  std::vector<double> w(2*h+1);
  std::vector<double> stemp(signal);
  stemp = cap_median(stemp,h);
  int nf = 0, hn, hp;
  for(int i = h; i < signal.size(); i+=2*h)
    {
      hn = i-h;
      hp = i+h;
      if(hp>signal.size()-1)
	{
	  hp = signal.size()-1;
	  hn = hp-w.size()-1;
	}
      w.assign(signal.begin()+hn,signal.begin()+hp);
      med = median_full(w);
      mad = compute_mad(w);
      wstd = stand_dev(w);
      for(int j=0; j<w.size(); j++)
	{
	  if ( std::abs(w[j] - med) <= 1.2*mad &&
	       std::abs(w[j] - med) <= wstd
	       )
	    {
	      stemp[i+j-h] = w[j];
	    }
	  else
	    {
	      stemp[i+j-h] = med;
	      nf += 1;
	    }
	}
      w.clear();
    }
  // printf("--> nf=%d (nr_rri_to_median during median_perc_filter)\n",nf);
  return stemp;
}

std::vector<double> recursive_median_filter(std::vector<double> signal, int h)
{
  std::vector< std::vector<double> > W( (int)signal.size()/h, std::vector<double>(2*h+1) ); // windows
  
  std::vector<double> stemp = median_filter(signal, h, W); // initial filter
  
  bool converged = false;
  double w_mad,w_mad1,mad_diff;

  double mad = compute_mad(stemp);
  double tol = 0.75*mad;
  int conv_tol = W.size();
  int max_iters = 1;

  int conv; // count of windows within tolerance  
  int ci = 0; // number of evals
  while (!converged)
    {
      conv = 0;
      for(int i=0; i < W.size(); i++)
	{
	  w_mad = compute_mad(W[i]); // for each window, find the median avg deviation
	  if(w_mad <= tol)
	    {
	      conv += 1; // if the window MAD <= tolerance, increment counter
	    }
	}

      printf("  eval %d ... windows_conv: %d / %d\n",ci,conv,conv_tol); 
      // converged when conv is large enough, or when max_iters evals are done
      converged = (conv >= conv_tol||ci>=max_iters) ? true : false;
      
      // if not converged, filter again and update the windows
      stemp = median_filter(stemp, h+ci, W);
      
      ci += 1;
    }
  return stemp;
}

int compute_order(std::vector<double> tvi, int morder, int pkorder)
{ /* 
     Compute the order parameter for median filtration,
     based on average cycle duration
  */

  // initial median filter on small subset of data
  std::vector<std::vector<double>>W(1,std::vector<double>());
  tvi = median_filter(tvi, morder, W);

  std::vector<int> pks, mins; // find peaks, mins
  find_peaks(pks, tvi, pkorder, 1, "min",0);
  find_peaks(mins, tvi, pkorder, 1, "min",0);
  clean_peaks(pks,1);
  clean_peaks(mins,0);

  // compute average cycle duration
  std::vector<double> timei = linspace(0, tvi.size() / 240, tvi.size());
  double tin, tin1, tex, ave_dur;
  ave_dur = 0.0;
  int ncycles = 0;
  for(int i=0; i < mins.size()-1; i++)
    {
      tin = timei[mins[i]];
      tin1 = timei[mins[i+1]];
      for(int j=0; j<pks.size(); j++)
	{
	  tex = timei[pks[j]];
	  if(tin1 <= tex)
	    {
	      break;
	    }
	  if( tex > tin && tex < tin1 )
	    {
	      ave_dur += (tin1 - tin);
	      ncycles += 1;
	    }
	}
    }
  ave_dur /= ncycles;

  int order = (int) ave_dur * 240 / 4; // compute order
  return order;
}

void rolling_minute(std::vector<double> &s_pm,
		    std::vector<double> sig,
		    std::vector<double> time_occur,
		    std::vector<double> *t_pm)
{
  double sm, ti, tj;
  int i=0, j=0, k=0;
  while (i < time_occur.size())
    {
      ti = time_occur[i];
      for (j=0; j < time_occur.size()-i; j++)
	{
	  tj = time_occur[j+i];
	  if (tj - ti >= 60.0) // if this spans 1 minute
	    {
	      // std::cout << tj - ti << std::endl;
	      k = i+j;
	      break;
	    }
	}
      sm = 0.0;
      for (int ip = i; ip < k; ip++)
	{
	  sm += sig[ip];
	}
      sm /= (double) j;
      s_pm.push_back(sm);
      t_pm->push_back(ti);

      i += j;
    }
}

void rolling_minute(std::vector<double> &s_pm,
		    std::vector<double> sig,
		    std::vector<double> time_occur)
{
  double sm, ti, tj;
  int i=0, j=0, k=0;
  while (i < time_occur.size())
    {
      ti = time_occur[i];
      for (j=0; j < time_occur.size()-i; j++)
	{
	  tj = time_occur[j+i];
	  if (tj - ti >= 60.0) // if this spans 1 minute
	    {
	      // std::cout << tj - ti << std::endl;
	      k = i+j;
	      break;
	    }
	}
      sm = 0.0;
      for (int ip = i; ip < k; ip++)
	{
	  sm += sig[ip];
	}
      sm /= (double) j;
      s_pm.push_back(sm);

      i += j;
    }
}

void smooth_signal(std::vector<double> &signal, int order)
{

  std::vector<double> window;
  window.assign(order,0);
  
  std::vector<double> pispace = linspace(-M_PI, M_PI, order);

  double nuttall[4] = {0.3635819, 0.4891775, 0.1365995, 0.0106411};

  double wsum = 0.0;
  for(int i=0; i<window.size(); i++){
    for(int j=0; j<4; j++){
      double csum = nuttall[j] * cos(j * pispace[i]);
      window[i] += csum;
      wsum += csum;
    }
  }
  
  std::vector<double> signal_s;
  signal_s.assign(signal.size(),0.0);
  
  for(int i=0; i<signal.size(); i++)
    {
      signal_s[i] = 0.0;
      for(int j=0; j<window.size(); j++)
	{
	  if ((i-j) >= 0)
	    {
	      signal_s[i] += (signal[i-j] * window[j]) / wsum;
	    } else
	    {
	      signal_s[i] = signal[i];
	    }
	}
    }
  signal = signal_s;
}

void round_d(std::vector<double>& vout,
	     std::vector<double> vec,
	     double xr=100.0)
{
  for(int wi=0; wi < vec.size(); wi++) // multiply each by xr, round to nearest integer
    vout.push_back(std::round(xr*vec.at(wi)));
}

void hist(std::vector<double> hOut[2],
	  std::vector<double> sig,
	  double xr=100.0)
{ // find a histogram with values rounded by xr orders
  std::vector<double> sigr;
  // round_d(sigr, sig, xr); // round by xr orders
  std::set<double> hset(sig.begin(), sig.end()); // unique
  hOut[0].assign(hset.begin(), hset.end());
  hOut[1].assign(hOut[0].size(), 0);
  for(auto& vii : sig)
    {
      if(hset.find(vii)!=hset.end())
	{
	  int hk = std::distance(hOut[0].begin(), std::find(hOut[0].begin(), hOut[0].end(), vii));
	  hOut[1][hk] += 1;
	}
    }
  // std::cout << "hist = " << std::endl;
  // for(int hi=0; hi < hOut[0].size(); hi++)
  //   std::cout << " ; " << hOut[0][hi];
  // std:: cout << std::endl;
  // for(int hi=0; hi < hOut[1].size(); hi++)
  //   std::cout << " ; " << hOut[1][hi];
  // std:: cout << std::endl;
}

std::pair<double,double> mode_d(std::vector<double> sig, double xr=100.0)
{ // find the mode using a histogram, returns a pair (mode, magnitude)
  std::vector<double> hXs, hNs;
  std::vector<double> harr[2]={hXs, hNs};
  hist(harr, sig, xr);
  auto maxiter = std::max_element(harr[1].begin(), harr[1].end());
  int mdix = std::distance(harr[1].begin(), maxiter);
  std::pair<double,double> modeout;
  modeout.first = harr[0][mdix];
  modeout.second = *maxiter;
  return modeout;
}

std::vector<double> calc_zscores(std::vector<double> signal)
{
  std::vector<double> zscores;
  double smed = median_full(signal);
  double smad = compute_mad(signal);
  for(double& sg: signal)
    {
      zscores.push_back(pow(sg - smed,2)/pow(smad,2));
    }
  return zscores;
}

double compute_kurtosis(std::vector<double> signal)
{
  // first, find zscores
  std::vector<double> zs = calc_zscores(signal);
  // find "variance" of zs
  return pow(compute_mad(zs),2);
}

void KMeds::calc()
{
  signal = normalize_d(signal, 1e-3, 1.001);
  // std::vector<double>nsig; //rounded signal
  // round_d(nsig, signal);
  // signal.assign(nsig.begin(), nsig.end());
  std::vector<int> sigt; // vector that holds all previously grouped indices
  std::vector<double> tempsig; // temporary vectors to hold the remaining signal
  int csz = sigt.size(); // current size of sigt
  int msz = meds.size(); // current number of medians found
  double cmed = 0.0;
  double smed = 0.0; // temporary std, median
  int ngps = 0;
  int iters = 0;
  double sigmad = compute_mad(signal);
  while(csz < signal.size() &&
	ngps < max_k &&
        msz < max_k*10 &&
	iters < signal.size()*max_k) // stop when either there are no more points, or we have reached max_k
    {      
      if(csz > 0)
	{
	  std::vector<double>().swap(tempsig);
	  for(int sti=0; sti < signal.size(); sti++)
	    {
	      if(std::find(sigt.begin(), sigt.end(), sti)==sigt.end())
		{
		  tempsig.push_back(signal.at(sti));
		}
	    }
	  cmed = median_full(tempsig); // find median from remaining signal
	  smed = compute_mad(tempsig); // find std
	  if(std::isnan(smed))
	    smed = cmed;
	}
      else
	{
	  cmed = median_full(signal); // find median from initial signal
	  smed = compute_mad(signal); // find std
	  if(std::isnan(smed))
	    smed = cmed;
	}
      std::vector<double> group; // new group
      for(int si=0; si < signal.size(); si++)
	{
	  // find group (within 1 std of med)
	  if((cmed + smed) >= signal.at(si) &&
	     (cmed - smed) <= signal.at(si) &&
	     std::find(sigt.begin(), sigt.end(), si) == sigt.end()) // not already grouped
	    {
	      group.push_back(signal.at(si)); // include in group
	      sigt.push_back(si);
	      csz = sigt.size();
	    }
	}
      if(group.size() > 1)
	{
	  groups.push_back(group);
	  meds.push_back(median_full(group));
	  stds.push_back(compute_mad(group));
	  msz = meds.size(); // update break conditionals
	  ngps = (int)groups.size();
	}
      iters += 1;
    }

  // std::cout << "csz = " << csz << " / " << (int)signal.size() << std::endl;
  // std::cout << "msz = " << msz << " / " << (max_k*10) << std::endl;
  // std::cout << "ngroups = " << ngps << " / " << max_k << std::endl;
  // std::cout << "niters = " << iters << " / " << max_k*signal.size()*100 << std::endl;
  // std::cout << " \n " << std::endl;

  // which groups are bands?
  for(int gi=0; gi < groups.size(); gi++)
    gsizes.push_back((double)groups.at(gi).size());
  double gstd = compute_mad(gsizes);
  auto gres = std::minmax_element(gsizes.begin(), gsizes.end());
  double gmed = median_full(gsizes);
  double sstd = median_full(stds) - 0.3*compute_mad(stds);
  std::vector<double> group_kurt;
  for(std::vector<double>& gr: groups)
    group_kurt.push_back(compute_kurtosis(gr));
  double kumed = median_full(group_kurt) - 1.5*compute_mad(group_kurt);
  for(int bi=0; bi < groups.size(); bi++)
    {
      // printf("%d : gsize=%.1f\n",bi,gsizes.at(bi));
      if(gmed <= gsizes.at(bi) &&
	 stds.at(bi) <= sstd &&
	 group_kurt.at(bi) >= kumed)
	{
	  // printf("|--- %d : isband. gsize=%.1f\n",bi,gsizes.at(bi));
	  bands.push_back(1);
	  nbands += 1;
	}
      else {
	bands.push_back(0);
      }
    }

  // std::cout << "\n number of bands = " << nbands << std::endl;
  // printf(" total number of groups = %d\n",bands.size());
  
  // calculate the magnitude of each band, and total magnitude
  magnitude = log(1.0 + nbands*sqrt(kumed / ((double)signal.size()*sqrt(1.0+ngps))));
  error = log(1.0 + (1.0+sstd) / ((double)signal.size()*sqrt(1.0+ngps)));
  // printf("calculated kmi.\n");
  if(std::isnan(magnitude))
    magnitude = 0.0;
  if(std::isnan(error))
    error = magnitude;
}

std::vector<double> vec2cdf(std::vector<double> signal)
{
  std::vector<double> vcdf(signal);
  std::sort(vcdf.begin(), vcdf.end());
  return vcdf;
}
