#ifndef PROCESS_DATA_H
#define PROCESS_DATA_H

#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <map>
#include <set>
#include <sys/stat.h>
#include <errno.h>
#include <err.h>
#include "config.h"

struct Beatix {
  int ix;
  double time_beat;
  double phase;
  double rri_diff;
Beatix():ix(0),time_beat(0),phase(0),rri_diff(0) {}
};

struct rsa_data { //!< for gsl interpolation
    double *phase;
    double *rri_diff;
    size_t n;
};

struct Qix { //!< allows ordering of interpolation results
  int ix;
  double time;
  double Q;
  double Qerr;
  double Qcomps[3]; //!<< components of Q (A, B, C, a0)
};

template <class T>
class fn_map {
public:
  std::string dname;
  std::vector<T>* dvec;
};

struct avgstats {
  int N_rri=0;
  int N_resp=0;
  double avg_rri;
  double avg_insp;
  double avg_exp;
  double avg_bp;
  double err_bp;
  double err_rri;
  double err_resp;
  void print()
  {
    std::cout << "=== Statistics Summary: ===" << std::endl;
    std::cout << " N_rri = " << N_rri << std::endl
	      << " N_resp = " << N_resp << std::endl
	      << " avg_rri = " << avg_rri << " +- " << err_rri << std::endl
	      << " avg_insp = " << avg_insp << " +- " << err_resp << std::endl
	      << " avg_exp = " << avg_exp << " +- " << err_resp << std::endl
	      << " avg_bp = " << avg_bp << " +- " << err_bp << std::endl << std::endl;
  }
};

// functions for rsa interpolation
void interp_rsa_segs(int parts,
		     std::vector<double> rsa_phase,
		     std::vector<double> rri_diff,
		     std::vector<double>time_beat,
		     std::vector<Qix>& Qmap,
		     std::string output_dir,
		     std::string fn_ext);
std::vector<Beatix> interp_rsa(double Qcomps[4], int n, std::vector<Beatix> Bmap);
void save_seg(int qix,
	      std::vector<double> rri_phase,
	      std::vector<double> rri_diff,
	      std::vector<double> rri_error,
	      std::string output_dir,
	      std::string fn_ext);
void calc_q(int qix, int N,
	    std::vector<Beatix> Bmap,
	    std::vector<Qix>& Qmap,
	    std::string output_dir,
	    std::string fn_ext);
bool order_qerr(Qix q0, Qix q1);

//! Class with functions to save output.
class SaveData {
public:
  std::string output_folder;
  SaveData(std::string opath) : output_folder(opath)
  {
    if(mkdir(output_folder.c_str(), 0777)==-1)
      {
	std::cerr << "  couldn't create output directory: " << output_folder << "\n";
	if(errno==EEXIST)
	  warn("%s ", output_folder.c_str());
	else
	  throw std::runtime_error("  Error creating output directory.\n");
      }
    else
      std::cout << "  created output directory: " << output_folder << "\n";
  }

  // save functions
  void save_double(std::string, std::string, std::vector<double>);
  void save_int(std::string, std::string, std::vector<int>);
  void save_dstats(std::string, avgstats);
  
};

//! Struct for storing dynamical state-related information
struct State {
  std::vector<std::string> signames; //!< names of signals
  int ix; //!< start index for the state (the "window number")
  std::vector<double> t; //!< time vector (order corresponds to signals)
  std::vector<double> M; //!< slope vector (order corresponds to signals)
  std::vector<double> E; //!< error vector (order corresponds to M, signals)
  State(std::vector<std::string> sign,
	int ix,
	std::vector<double> slope,
	std::vector<double> err) :
    signames(sign), ix(ix), M(slope), E(err) {}
  State(std::vector<std::string> sign, int ix) :
    signames(sign), ix(ix) {}
};

//! Struct for storing possible states for a signal
struct ProState {
  std::string name; //!< name of signal
  int wsize; //!< unique window size for the signal
  std::set<int> ixs; //!< starting index for each window
  std::vector<double> time; //!< time vector corresponding to the signal (windowed, per each ix in ixs)
  std::vector<double> trans; //!< transition magnitudes
  std::vector<double> errs; //!< stderrs for transitions
  ProState(std::string nm, int ws) : name(nm), wsize(ws) {}
};

//! Class for state-identification methods and storage of all state-related info
class States {
  std::streambuf* stbuff; //!< buffer for stdout
public:
  double ttol = 100.0; //!< tolerance for temporal proximity of states
  int wsize; //!< size of each window
  int nwins = 21; //!< number of windows to use when computing the states
  std::vector<std::string>signames; //!< vector of signal names
  std::vector<std::vector<double>> sigtimes; //!< vector raw signal times (full time, not windowed)
  std::vector<std::vector<double>>signals; //!< vector of signals
  std::vector<ProState> prostates; //!< vector of possible states (one Prostate per signal)
  std::vector<State> states; //!< vector of all dynamical states
  
  States(std::vector<std::vector<double>> sigtimes,
	 std::vector<std::vector<double>> signals,
	 std::vector<std::string> signames,
	 int nwins) :
    signames(signames), sigtimes(sigtimes),
    signals(signals), nwins(nwins)
  {
    wsize = (int)(signals[0].size()/nwins);
  }
  States()
    {
    }
  
  void identifyProStates(); //!< identify all possible states in the the given signals vector, store in the prostates vector.
  void appendPro(std::string signame,
		 int swsize,
		 std::vector<int> ixs,
		 std::vector<double> time,
		 std::vector<double> mags,
		 std::vector<double> errs); //!< create and append new Prostate to class prostates vector
  void combineStates(); //!< combine all prostates to find the smallest possible set of unique states that defines all dynamical transitions in the given signals
  void saveStates(std::string, std::string); //!< save the states vector to a text file
  ProState getPstate(std::string name); //!< get a specific pstate by name
};

//! Base data processing class.
/*!
  All data processing functions are defined here.
  See the file db.cpp for the implementation details.
*/
class DB {

 public:

  States *states; //!< States class instance pointer, for identifying all transition states in the provided data
  SaveData *saver; //!< SaveData class instance pointer, for saving output data to file (.cardio)
  dataParams dparams; //!< user-provided params
  std::streambuf* stbuff; //!< buffer for stdout
  int debug = 0; //!< print debug messages or not
  int ismodel = 0; //!< flag to identify if this is a model instance or not
  
  DB(std::string db, std::string dpath): db(db), dpath(dpath) {}
  DB(double ti, double te, int tlen): ti(ti), te(te), tlen(tlen) {}
  DB(std::string db, std::string dpath, dataParams dp): db(db), dpath(dpath), dparams(dp) {}
  DB(std::string db, //!<< Subject-ID
     std::string dpath, //!<< Path to input data
     SaveData *ss, //!<< pointer SaveData instance
     dataParams dparams //!<< dataParams from configuration
     ) :
    db(db),
    dpath(dpath),
    saver(ss),
    dparams(dparams),
    states(new States) {}

  ~DB()
  {
    delete states;
    if(debug!=1)
      {
	std::cout.rdbuf(stbuff);
	fclose(stdout);
      }
  }
  
  //! data-derived params
  int tlen;
  double ti, te, sfreq=240.0;
  std::string db, dpath;

  //! Input signals
  std::vector <double> time;
  std::vector <double> ecg;
  std::vector <double> tv;
  std::vector <double> spo2;
  std::vector <double> bp;
  std::vector <double> v_vect;

  //! indices
  std::vector <int> beat_ix;
  std::vector <int> exp0_ix;
  std::vector <int> insp0_ix;
  std::vector <int> resp_ix;
  std::vector <int> ptt_ix;
  std::vector <int> ptt_ix1;
  std::vector <int> pulm_index;
  std::vector <int> bp_pulseix, bp_pulseix1;
  std::vector <int> cvcixs;
  std::vector <int> bp_maxs, bp_mins;
  
  //! Processed signals
  std::vector <double> insp_dur;
  std::vector <double> exp_dur;
  std::vector <double> resp_rate;
  std::vector <double> co2_diff;
  std::vector <double> rri_vect;
  std::vector <double> rri_diff;
  std::vector <double> rsa_phase;
  std::vector <double> cvc_phase;
  std::vector <double> respdur;
  std::vector <double> cvcdist;
  std::vector <double> hr_vect;
  std::vector <double> pulse_delay;
  std::vector <double> pulse_rri;
  std::vector <double> baroact, baroeff;
  std::vector <double> pulselen;
  std::vector <double> bp_len;
  std::vector <double> stroke_vol;
  std::vector <double> svol_diff;
  std::vector <double> bpsysdiff;
  std::vector <double> qcomps;
  std::vector <double> bpsynth; // synthetic bp in time
  std::vector <double> bpresp_nat, bpresp_synth; // MAP relative to resp phase
  std::vector <double> bpmresp_nat, bpmresp_synth; // blood pressure modulation relative to resp phase
  std::vector <double> svolresp_nat, svolresp_synth; // svol relative to resp phase
  
  // processed times
  std::vector <double> time_beat;
  std::vector<double> time_cvc;
  std::vector<double> beat2insp; //!< time between heart beat and next inspiration
  std::vector<double> time_b2i; //!< time of the last heart beat before inspiration
  std::vector<double> time_rdinterp; //!< time for interpolated rridiffs (rsa_interp)
  std::vector <double> barotime;
  std::vector <double> time_resp;
  std::vector <double> time_exp0;
  std::vector <double> cvctime; //!< time corresponding to windowed CVC
  std::vector <double> rsatime; //!< time corresponding to windowed Qrsa (Qix)
  std::vector <double> svtime;
  std::vector <double> bpsystime;
  
  // signals per minute
  std::vector <double> co2_pm;
  std::vector <double> spo2_pm;
  std::vector <double> rr_pm;
  std::vector <double> hr_pm;
  std::vector <double> time_pm;
  
  // Maps
  std::vector <Qix> Qmap;
  std::vector <Beatix> Bmap;

  // std err
  std::vector <double> rsa_stderr;
  std::vector <double> cvcerr; //!< Error for windowed CVC
  
  // descriptive stats
  avgstats dstats;
  
  void check_for_nans();
  void calc_rsa();
  void calc_b2i();
  void calc_cvc();
  void calc_cbaro();
  void calc_baroact();
  void calc_bp();
  void calc_pi();
  void resp_peaks();
  void heart_peaks();
  void process_data(int);
  void load_cardio(std::string);
  void save(std::string);
  void save_raw(std::string);
  void save_qmap(std::string, std::string);
};

#endif
