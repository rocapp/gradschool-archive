#include <vector>
#include <utility>
#include <string>
#include <functional>

#ifndef UTILS_H
#define UTILS_H

#ifndef MEAN_H
#define MEAN_H
double compute_mean(std::vector<double> vec);
#endif

#ifndef CONVECT_H
#define CONVECT_H
std::vector<double> cvertf2d(std::vector<float>);
std::vector<float> cvertd2f(std::vector<double>);
#endif

#ifndef NORMALIZE_D_H
#define NORMALIZE_D_H
std::vector<double> normalize_d(std::vector<double>,double,double);
#endif

#ifndef NORMALIZE_F_H
#define NORMALIZE_F_H
std::vector<float> normalize_f(std::vector<float>,float,float);
#endif

#ifndef BEAT_H
#define BEAT_H
double beat(double);
#endif

#ifndef LINSPACE_H
#define LINSPACE_H
std::vector<double> linspace(double, double, int);
#endif

#ifndef CALC_MAP_H
#define CALC_MAP_H
double calc_MAP(std::vector<double>, int, int);
#endif

#ifndef FIND_PEAKS_H
#define FIND_PEAKS_H
void find_peaks(std::vector<int> &, std::vector<double>, int, int, std::string, int=0);
#endif

#ifndef FIND_CLOSEST_H
#define FIND_CLOSEST_H
std::vector<int> find_closest_int(std::vector<int> v1, std::vector<int> v2);
#endif

#ifndef SMOOTH_SIGNAL_H
#define SMOOTH_SIGNAL_H
void smooth_signal(std::vector<double> &, int);
#endif

#ifndef MEDIAN_FILTER_H
#define MEDIAN_FILTER_H
std::vector<double> median_filter(std::vector<double>,
				  int, std::vector< std::vector<double> >&);
#endif

#ifndef RECURSIVE_MEDIAN_FILTER_H
#define RECURSIVE_MEDIAN_FILTER_H
std::vector<double> recursive_median_filter(std::vector<double>, int);
#endif

#ifndef STANDDEV_H
#define STANDDEV_H
double stand_dev(std::vector<double> vec);
#endif

#ifndef MEDIAN_H
#define MEDIAN_H
double median(std::vector<double>);
double median(double vec[], int n);
#endif

#ifndef COMPUTE_MAD_H
#define COMPUTE_MAD_H
double compute_mad(std::vector<double>);
#endif

#ifndef COMBINE_SIGNALS_H
#define COMBINE_SIGNALS_H
std::vector<double> combine_signals(std::vector<double> sig0,
				    std::vector<double> sig1);
#endif

#ifndef COMPUTE_ORDER_H
#define COMPUTE_ORDER_H
int compute_order(std::vector<double>, int, int);
#endif

#ifndef CLEAN_PEAKS_H
#define CLEAN_PEAKS_H
void clean_peaks(std::vector<int>&, int);
#endif

#ifndef CLEAN_BEATS_H
#define CLEAN_BEATS_H
std::vector<int> clean_beats(std::vector<int> beatix,
			     std::vector<double> ecg,
			     double hn, double hp);
#endif

#ifndef CLEAN_BEATS2_H
#define CLEAN_BEATS2_H
void clean_beats2(std::vector<int>& beatix,
		  std::vector<double> ecg,
		  int horder,
		  int h, int h1,
		  double hheight,
		  double hmaxheight);
#endif


#ifndef DETECT_IMPULSES_H
#define DETECT_IMPULSES_H
void detect_impulses(std::vector<int> &, std::vector<double>, int, double);
#endif

#ifndef MEDIAN_FULL_H
#define MEDIAN_FULL_H
double median_full(std::vector<double>);
#endif

#ifndef CAP_MEDIAN_H
#define CAP_MEDIAN_H
std::vector<double> cap_median(std::vector<double>, int);
#endif

#ifndef ROLLING_MEDIAN
#define ROLLING_MEDIAN
std::vector<double> rolling_median(std::vector<double>, int);
#endif

#ifndef ROLLING_MEDIAN2_H
#define ROLLING_MEDIAN2_H
std::vector<std::vector<double>> rolling_median2(std::vector<double> signalx,
						std::vector<double> signaly,
						int h);
#endif

#ifndef MEDIAN_PERC_FILTER_H
#define MEDIAN_PERC_FILTER_H
std::vector<double> median_perc_filter(std::vector<double>, int);
#endif

#ifndef ROLLING_MINUTE_H
#define ROLLING_MINUTE_H
void rolling_minute(std::vector<double> &s_pm,
		    std::vector<double> sig,
		    std::vector<double> time_occur,
		    std::vector<double> *t_pm);
void rolling_minute(std::vector<double> &s_pm,
		    std::vector<double> sig,
		    std::vector<double> time_occur);
#endif

#ifndef FIND_PHASE_H
#define FIND_PHASE_H
void find_phase(std::vector<int> &,
		std::vector<int> &,
		std::vector<double>,
		double,
		double,
		int);
#endif

#ifndef ROUND_D_H
#define ROUND_D_H
std::vector<double> round_d(std::vector<double>&, std::vector<double>, double);
#endif

#ifndef HIST_H
#define HIST_H
void hist(std::vector<double> hOut[2],
	  std::vector<double> sig,
	  double xr=10.0);
#endif

#ifndef MODE_D_H
#define MODE_D_H
std::pair<double,double> mode_d(std::vector<double> sig, double xr=10.0);
#endif

std::vector<double> vec2cdf(std::vector<double> signal);

#ifndef REPLACE_UNDERSCORES_H
#define REPLACE_UNDERSCORES_H
std::string replace_underscores(std::string fn_ext);
#endif

#endif
