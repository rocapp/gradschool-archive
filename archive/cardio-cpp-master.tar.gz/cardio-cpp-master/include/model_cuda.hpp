#ifndef MODEL_CUDA
#define MODEL_CUDA

#include <cuda.h>
#include <cuda_runtime.h>
#include "parameters.h"
#include <stdio.h>

extern "C" {

  inline void cudaCheckError();
  inline void cudaCheckError()
  {
    cudaError err = cudaGetLastError();
    if(cudaSuccess != err)
      {
	fprintf(stderr, "cudaCheckError()!\n");
	fprintf(stderr, "cudaError Enum %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err));
	throw;
      }
  }
  
  __global__ void integrateCU (double ti0, // initial time
			       double te0, // final time
			       const int ln, // length of solution array (timescale * te)
			       double *uu, // solution array
			       double h, // integration time step
			       struct parameters *p, // parameters
			       struct dataParams *dparamsp,
			       double *y // initial conditions
			       );
}
#endif
