#include <stdlib.h>
#include "process_data.h"
#include "utils.h"
#include "config.h"

#ifndef LOAD_DATA_H
#define LOAD_DATA_H

#include "H5Cpp.h"
using namespace H5;

//! Data structure for temporarily mapping channel names to array indices when loading HDF5 data
struct ChannelMap {
  const H5std_string name;
  int ix;
  ChannelMap(const H5std_string n, int i) : name(n), ix(i) {}
};

herr_t attr_info(hid_t loc_id, const char *name, void *opdata);

//! HDF5 data loading class
class H5DB : public DB {
public:

  std::string dfn = "sepsis_data.hdf5"; //!< name of the hdf5 data file
  
  H5DB(std::string db, std::string dpath) :
    DB(db, dpath) {}
  H5DB(std::string db, std::string dpath, dataParams dparams) :
    DB(db, dpath, dparams) {}
  H5DB(std::string db, std::string dpath, SaveData* ss, dataParams dparams) :
    DB(db, dpath, ss, dparams) {}
  
  void load();
  void thresh_bp();
  
private:
  void _load(H5T_order_t order, size_t size,
	     DataSet dset, DataSpace dspace, int npts,
	     std::vector<ChannelMap> channel_map);
};

#endif
