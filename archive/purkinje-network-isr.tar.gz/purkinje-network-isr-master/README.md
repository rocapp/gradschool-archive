Inverse stochastic resonance studied in a pattern recognition network of Purkinje cells.

Sources
- (Buchin 2016)
- (Steuber 2007)