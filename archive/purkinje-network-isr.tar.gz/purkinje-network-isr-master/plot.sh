#!/bin/sh
export -p plt=${plt:-plot}
[[ $plt == "plot" ]] && export -p fns="v.png w.png" || export -p fns="v1.png w1.png"
gnuplot $plt.gplot
feh -Z $fns
