#include <vector>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "process_data.h"
#include "utils.h"
#include "parameters.h"

/* Robert Ahlroth Capps; April 2018; rocapp@gmail.com */

/* william barnett; March 2018; whbdupree@gmail.com */

#ifndef __NVCC__

// random number -0.5, 0.5
double rand_scale(){
  int r = rand();
  double rr = ((double) r / RAND_MAX);
  return 0.5 - rr;
}

// biophysics functions
double ninf(double v) { return( 1/(1+exp((v-v12n)/kn)) ); }
double mpinf(double v) { return( 1/(1+exp((v-v12mp)/kmp)) ); }
double hpinf(double v) { return( 1/(1+exp((v-v12hp)/khp)) ); }
double tauinf(double v) { return( 1/cosh((v-v12hp)/(khp)) ); }

double vlow = -50;
double vhigh = -20;
double f(double v) {
  if (v < vlow) { return( 0 ); }
  else if (v > vhigh) { return( 1 ); }
  else { return( (v-vlow)/(vhigh-vlow) ); }
}

int rhs (double t,
	 double h,
	 double y[],
	 double dy[],
	 struct parameters *p,
	 struct modelParams mparams);

void noisy_step(double y[],
		struct parameters *p,
		struct modelParams mparams,
		double h,
		double* tn,
		double t1,
		bool* spike)
{
  double rs = p->rs1*rand_scale();
  double eiAd;
  double dy[12];
  rhs(t1, h, y, dy, p, mparams);
  double rpre = y[9];
  double bpre = y[10];
  while (*tn < t1)
    {
      eiAd = rs + (f(y[1])-p->eiAd)/p->tad_ei; // early-i iAD activation
      p->eiAd += eiAd * h;
      for(int i=0; i < 12; i++)
	y[i] += dy[i] * h;
      *tn += h;
    }
  if(rpre<int(y[9]))
    {
      y[10] += p->svol;
    }
  else if(rpre >= int(y[9]))
    {
      // && rpre-double(int(y[9])) >= 0.45 && rpre-double(int(y[9])) <= 0.465
      // double psym = p->sym*(f(y[4])+f(y[3]));
      // y[10] += (0.2*p->svol) / (1.0+std::exp((y[11]*y[11]-(psym+p->svol))/(1e-2*p->taupp)));
      double sv2 = mparams["svol2"]; // slope of secondary BP peak
      double hp2 = mparams["bphase2"]; // heart phase where secondary BP peak is centered
      double hp1 = (double)(rpre-(double)((int)(y[9])));
      y[10] += (1.0/std::sqrt(2*M_PI*sv2*sv2))*std::exp(-pow(hp1-hp2,2)/(2.0*sv2*sv2))/(p->taupp*1e-2);
    }
}

int rhs (double t,
	 double h,
	 double y[],
	 double dy[],
	 struct parameters *p,
	 struct modelParams mparams)
{
  //pre-i/i
  double n0 = ninf(y[0]);
  dy[0]= -gKdr*n0*n0*n0*n0*(y[0]-EK)-gL*(y[0]-EL)-gNaP*mpinf(y[0])*y[5]*(y[0]-ENa);
  dy[0]+= -gE*p->d1*(y[0]-Ee)-gI*(b31*f(y[2])+b41*f(y[3]))*(y[0]-Ei);
  dy[0]/= C;

  //early-i
  double n1 = ninf(y[1]);
  dy[1]= -gKdr*n1*n1*n1*n1*(y[1]-EK)-gL*(y[1]-EL)-gAD*p->eiAd*(y[1]-EK);
  dy[1]+= -gE*(p->d2+a12*f(y[0]))*(y[1]-Ee)-gI*(b32*f(y[2])+b42*f(y[3])+hb2*y[8]+st2)*(y[1]-Ei);
  dy[1]/= C;

  //aug-e
  double n2 = ninf(y[2]);
  dy[2]= -gKdr*n2*n2*n2*n2*(y[2]-EK)-gL*(y[2]-EL)-gAD*y[6]*(y[2]-EK);
  dy[2]+= -gE*(p->d3)*(y[2]-Ee)-gI*(b23*f(y[1])+b43*f(y[3]))*(y[2]-Ei);
  dy[2]/= C;

  //ramp-i
  double n4 = ninf(y[4]);
  dy[4]= -gKdr*n4*n4*n4*n4*(y[4]-EK)-gL*(y[4]-EL);
  dy[4]+= -gE*(p->d5+a15*f(y[0]))*(y[4]-Ee)-gI*(b25*f(y[1])+b35*f(y[2])+b45*f(y[3]))*(y[4]-Ei);
  dy[4]/= C;

  //pre-i/i nap inactivation
  dy[5]= (hpinf(y[0])-y[5]+p->rs1*rand_scale()) / ( p->tauhp * tauinf(y[0]) );

  // aug-e iAD activation
  dy[6]= (f(y[2])-y[6]+p->rs1*rand_scale())/p->tad;

  // post-i iAD activation
  dy[7]= (f(y[3])-y[7]+p->rs1*rand_scale())/p->tad;

  dy[8]= ( f(y[4]) - y[8] + p->rs1*rand_scale() ) / p->taul; // tidal volume
  //post-i
  double n3 = ninf(y[3]);
  dy[3]= -gKdr*n3*n3*n3*n3*(y[3]-EK)-gL*(y[3]-EL)-gAD*y[7]*(y[3]-EK);
  double bflex = (dy[8]<0)?p->baro*y[10]:0.0;
  dy[3]+= -gE*(p->d4+hb*y[8]+st4+bflex)*(y[3]-Ee)-gI*(b24*f(y[1])+b34*f(y[2]))*(y[3]-Ei);
  dy[3]/= C;

  // heart rate
  dy[9] = (p->hr - p->rsa1*f(y[3]) + p->rsa2*f(y[4]) - p->db*y[10] ) + p->rs1*rand_scale();

  // blood pressure
  double psym = p->sym*(f(y[4])+f(y[3]))+p->sym*p->rs1*rand_scale();
  dy[10] = (psym-y[10]+p->po) / p->taup;
  
  // smoothed blood pressure
  dy[11]= (y[10]-y[11])/p->taupp;

  return 1;
}

void integrate (
		double t0, // initial time
		int ln, // length of solution array (timescale * te)
		double *uu, // solution array
		double h, // integration time step
		struct parameters *p, // parameters
		struct dataParams dparams,
		struct modelParams mparams, // model config params
		double *y // initial conditions
		)
{

  int nd = 12; // dimensions (excluding noisy param)
  int off0 = 20*dparams.fs; // initial offset (remove garbage)
  dparams.prewin[0] += off0/(double)dparams.fs;
  dparams.prewin[1] += off0/(double)dparams.fs;
  dparams.durwin[0] += off0/(double)dparams.fs;
  dparams.durwin[1] += off0/(double)dparams.fs;
  dparams.postwin[0] += off0/(double)dparams.fs;
  dparams.postwin[1] += off0/(double)dparams.fs;
  
  p->eiAd = 0.0; // slow variable init
  
  double t = t0*dparams.fs;

  printf("p->hr=%.7f\n",p->hr);
  printf("t0=%.3f\n",t0);
  printf("ln=%d\n",ln);
  printf("dparams.fs=%.2f\n",dparams.fs);
  printf("h=%.7f\n",h);

  if(p->erica_pert==1.0)
    printf("EricaSimulation.\n");

  bool pertdone0 = false, pertdone1 = false;
  bool spike = false;
  int j,l,s;
  struct parameters initp = *p;
  for(l=0; l < ln+off0; l++){

    double ti = (double)(l+t0*dparams.fs);

    // integrate noisy variables
    noisy_step(y, p, mparams, h, &t, ti, &spike);

    if( (p->erica_pert==1) && l >= off0 )
      {
	// introduce perturbation
	if( (ti/dparams.fs > dparams.durwin[0] && ti/dparams.fs < dparams.durwin[1]) )
	  {
	    p->d1 = 0.12;
	    if(p->d2 > 0.29)
	      p->d2 -= 0.0005;
	    if(p->d4 > 0.30)
	      p->d4 -= 0.0005;
	    if(p->d5 > 0.55)
	      p->d5 -= 0.0005;
	    if(p->rsa1 < mparams["rsa1p"])
	      p->rsa1 += 0.000005;
	    if(p->rsa2 < mparams["rsa2p"])
	      p->rsa2 += 0.000005;
	    if(!pertdone0)
	      {
		printf("erica_pert_happened_here, t=%.2f, ti=%.2f, l=%d\n",t/dparams.fs,ti/dparams.fs,l);
		pertdone0 = true;
	      }
	  }
	else if( ( ti/dparams.fs >= dparams.durwin[1] ) ||
		 ( ti/dparams.fs > dparams.prewin[0] && ti/dparams.fs <= dparams.prewin[1]) )
	  {
	    p->d2 = initp.d2;
	    p->d4 = initp.d4;
	    p->d5 = initp.d5;
	    p->rsa1 = initp.rsa1;
	    p->rsa2 = initp.rsa2;
	    if(!pertdone1 && ( ti/dparams.fs > dparams.durwin[1] ))
	      {
		printf("erica_pert_ended_here, t=%.2f, ti=%.2f, l=%d\n",t/dparams.fs,ti/dparams.fs,l);
		pertdone1 = true;
	      }
	  }
      }

    if(l >= off0)
      {
	int ix_t = (l-off0)*(nd+1); // index offset
	// store firing rates
	for(j=0; j<5; j++)
	  uu[ix_t+j] = f(y[j]);
	// inactivation/activation
	uu[ix_t+5] = y[5];
	uu[ix_t+6] = p->eiAd;
	for(j=7;j<nd+1;j++)
	  uu[ix_t+j]=y[j-1]; // everything else
      }
  }
  
  printf("model_simulation_seconds=%.2f\n",(t/dparams.fs-t0));
  printf("done with integrate.\n");
  
}

#else

void integrate (
		double t0, // initial time
		int ln, // length of solution array (timescale * te)
		double *uu, // solution array
		double h, // integration time step
		struct parameters *p, // parameters
		struct dataParams dparams,
		double *y // initial conditions
		){}
#endif
