#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include "utils.h"
#include <sys/resource.h>
#include <utility>
#include <functional>
#include <thread>
#include <vector>
#include <array>
#include <algorithm>
#include "thread_pool.h"

#if defined(__NVCC__) || defined(__CUDACC__) || defined(__CUDACC_RDC__)
#include "model_cuda.hpp"
#define CUDA_FLAG 1
#else
#endif

#include "model_output.h"

void Model::setup(Config conf)
{
  cuda = conf.cuda;
  if(debug!=1)
    {
      fd = fgetpos(stdout, &pos);
      std::string logfn = std::string(getenv("CARDIO_SRC")) + "/logs/model_" + db + ".log";
      freopen(logfn.c_str(), "w", stdout);
    }
  srand(std::time(0)); // random seed
  ismodel = 1; //!< identify this as a model instance
  // external model params (loaded directly from the configuration object)
  mparams = new modelParams(conf.model);
  // internal model params (correspond to Model class members)
  ti = conf.model["ti"];
  sfreq = conf.model["sfreq"];
  te = conf.model["te"];
  if(conf.model.find("nthreads")!=conf.model.end())
    nthreads = (int)conf.model["nthreads"];
  if(conf.model.find("tstep")!=conf.model.end())
    tstep = conf.model["tstep"];
  // data parameters
  dparams.co2order = conf.model["co2order"];
  dparams.horder = conf.model["horder"];
  // load range params
  sranges.insert(std::pair<std::string,double>("bpmin",65.0));
  sranges.insert(std::pair<std::string,double>("bpmax",147.0));
  sranges.insert(std::pair<std::string,double>("tvmin",550.0));
  sranges.insert(std::pair<std::string,double>("tvmax",1500.0));
  sranges.insert(std::pair<std::string,double>("ecgmin",0.0));
  sranges.insert(std::pair<std::string,double>("ecgmax",2.2));
  for(auto const& rng : sranges)
    {
      std::string rkey = rng.first;
      if(conf.model.find(rkey)!=conf.model.end())
	sranges[rkey] = conf.model[rkey];
    }

  //! Input signals
  std::vector<double>().swap( time);
  std::vector<double>().swap( ecg);
  std::vector<double>().swap( tv);
  std::vector<double>().swap( spo2);
  std::vector<double>().swap( bp);
  std::vector<double>().swap( v_vect);

  //! indices
  std::vector<int>().swap( beat_ix);
  std::vector<int>().swap( exp0_ix);
  std::vector<int>().swap( insp0_ix);
  std::vector<int>().swap( resp_ix);
  std::vector<int>().swap( ptt_ix);
  std::vector<int>().swap( ptt_ix1);
  std::vector<int>().swap(pulm_index);
  std::vector<int>().swap( bp_pulseix);
  std::vector<int>().swap(bp_pulseix1);
  std::vector<int>().swap( cvcixs);
  std::vector<int>().swap( bp_maxs);
  std::vector<int>().swap(bp_mins);
  
  //! Processed signals
  std::vector<double>().swap( insp_dur);
  std::vector<double>().swap( exp_dur);
  std::vector<double>().swap( resp_rate);
  std::vector<double>().swap( co2_diff);
  std::vector<double>().swap( rri_vect);
  std::vector<double>().swap( rri_diff);
  std::vector<double>().swap( rsa_phase);
  std::vector<double>().swap( cvc_phase);
  std::vector<double>().swap( respdur);
  std::vector<double>().swap( cvcdist);
  std::vector<double>().swap( hr_vect);
  std::vector<double>().swap( pulse_delay);
  std::vector<double>().swap( pulse_rri);
  std::vector<double>().swap( baroact);
  std::vector<double>().swap(baroeff);
  std::vector<double>().swap( pulselen);
  std::vector<double>().swap( bp_len);
  std::vector<double>().swap( stroke_vol);
  std::vector<double>().swap( svol_diff);
  std::vector<double>().swap( bpsysdiff);
  std::vector<double>().swap( qcomps);

  // processed times
  std::vector<double>().swap( time_beat);
  std::vector<double>().swap( time_cvc);
  std::vector<double>().swap( beat2insp); //!< time between heart beat and next inspiration
  std::vector<double>().swap( time_b2i); //!< time of the last heart beat before inspiration
  std::vector<double>().swap( time_rdinterp); //!< time for interpolated rridiffs (rsa_interp)
  std::vector<double>().swap( barotime);
  std::vector<double>().swap( time_resp);
  std::vector<double>().swap( time_exp0);
  std::vector<double>().swap( cvctime); //!< time corresponding to windowed CVC
  std::vector<double>().swap( rsatime); //!< time corresponding to windowed Qrsa (Qix)
  std::vector<double>().swap( svtime);
  std::vector<double>().swap( bpsystime);
  
  // signals per minute
  std::vector<double>().swap( co2_pm);
  std::vector<double>().swap( spo2_pm);
  std::vector<double>().swap( rr_pm);
  std::vector<double>().swap( hr_pm);
  std::vector<double>().swap( time_pm);
  
  // Maps
  std::vector <Qix>().swap( Qmap);
  std::vector <Beatix>().swap( Bmap);

  // std err
  std::vector<double>().swap( rsa_stderr);
  std::vector<double>().swap( cvcerr); //!< Error for windowed CVC

  std::vector<double>().swap(hr_phase); // model raw hr phase

  dstats = avgstats(); // reset averages

}

void Model::run(struct parameters *params)
{
  
  printf("  te=%f ti=%f sfreq=%f tstep=%f\n",te,ti,sfreq,tstep);
  tlen = (int)((te - ti)*sfreq);
  printf("  tlen=%d\n",tlen);
  
  // modify the stack size if needed
  struct rlimit rlim;
  int result;
  uintmax_t cur;
  result = getrlimit(RLIMIT_STACK, &rlim);
  cur = (uintmax_t)rlim.rlim_cur;
  const rlim_t stacksz = (uintmax_t)(tlen * 1024 * 1024 * 30 * nthreads) + cur;
  printf("rlim result = %d ; rlim = %ju \n", result, cur);
  if (result == 0)
    {
      printf("successfully checked rlim...\n");
      if (stacksz < rlim.rlim_max)
	{ // if current stack size+new < max
	  printf("stacksz < rlim_max\n");
	  rlim.rlim_cur = stacksz;
	  printf("set rlim.rlim_cur = stacksz.\n");
	  result = setrlimit(RLIMIT_STACK, &rlim);
	  printf("result of setrlimit=%d\n",result);
	  printf("stack size changed.\n");
	  if (result != 0)
	    {
	      std::cout << "\n!ERROR CODE TRYING TO CHANGE STACK SIZE: " << result << std::endl;
	    }
	} else {
	printf("rlim is already max.\n");
      }
    }

  double y[] = { -60, -65, -60, -75, -40, // neuronal signals
		 0.1, 0, 0, // activation variables
		 0.0, // Tidal Volume initial condition
		 0.0, params->po, params->po }; // heart, bp, smoothed bp

  double h_integ = tstep/(double)sfreq;

  if(nthreads > 1 && !cuda)
    {
      printf("...\nintegrating model on %d threads...\n", nthreads);
      ThreadPool threadpool;
      std::vector<std::thread> threads;
      std::vector<std::vector<double>> ys(nthreads);
      for(int yi=0; yi < ys.size(); yi++)
	ys.at(yi).assign(y, y+nvars);
      std::vector<std::vector<double>> solns(nthreads,std::vector<double>(tlen*nvars/nthreads));
      std::vector<struct parameters> pvec(nthreads,*params);
      std::vector<struct dataParams> dparms(nthreads,dparams);
      std::vector<struct modelParams> mparms(nthreads,*mparams);
      for(int thx=0; thx < nthreads; thx++)
	{
	  threads.emplace_back(std::thread(&ThreadPool::loop_func, &threadpool));
	}
      for(int thi=0; thi < nthreads; thi++)
	{
	  threadpool.push(std::bind(integrate,ti+(double)thi*(te-ti)/(double)nthreads,((tlen)/nthreads),solns[thi].data(),h_integ,&pvec.at(thi),dparms.at(thi),mparms.at(thi),ys.at(thi).data()));
	}
      threadpool.done();

      for(int xi=0; xi < threads.size(); xi++)
	{
	  printf("  joining %d...\n",xi);
	  threads.at(xi).join();
	  printf("  joined %d.\n",xi);
	}
      printf("done with all threads.\n");
      for(int txx=0; txx < (int)threads.size(); txx++)
	{
	  storeResult(solns.at(txx).data());
	}
    }
  else if(nthreads==1 && !cuda)
    {
      double soln[nvars*tlen];
      integrate(0.0, tlen, soln, h_integ, params, dparams, *mparams, y);
      storeResult(soln);
    }

#if defined(__NVCC__) || defined(__CUDACC__) || defined(CUDA_FLAG)
  if(cuda)
    {
      try
	{
	  const int threads_per_block = nthreads;
	  // Nblocks must be 1, unless grid-level synchronization is available (compute capability >= 6)
	  const int Nblocks = 1; //(int)ceil(tlen/(float)threads_per_block);
	  
	  printf("using CUDA to integrate model %d threads....\n",threads_per_block);
	  cudaSetDevice(0);
	  cudaCheckError();
	  printf("...finished set CUDA device.\n");

	  printf("declaring host objects...\n");
	  struct parameters * cu_params; struct dataParams *cu_dparamsp;
	  double* soln; double* cu_soln; double* cu_y;
	  printf("...declared host objects.\n");

	  soln = (double*)malloc(tlen*nvars*sizeof(double));
	  
	  cudaMalloc(&cu_params, sizeof(struct parameters));
	  cudaCheckError();
	  cudaMemcpy(cu_params, params, sizeof(struct parameters), cudaMemcpyHostToDevice);
	  cudaCheckError();
	  printf("finished cuparams\n");

	  cudaMalloc(&cu_dparamsp, sizeof(struct dataParams));
	  cudaCheckError();
	  cudaMemcpy(cu_dparamsp, &dparams, sizeof(struct dataParams), cudaMemcpyHostToDevice);
	  cudaCheckError();
	  printf("finished dparams\n");
	  
	  cudaMalloc(&cu_soln, tlen*nvars * sizeof(double));
	  cudaCheckError();
	  printf("finished soln\n");

	  cudaMalloc(&cu_y, nvars * sizeof(double));
	  cudaCheckError();
	  cudaMemcpy(cu_y, y, sizeof(double)*nvars, cudaMemcpyHostToDevice);
	  cudaCheckError();
	  printf("finished y\n");
	  
	  cudaDeviceSetLimit(cudaLimitMallocHeapSize, 2*tlen*nvars*sizeof(double));
	  cudaCheckError();
	  printf("finished setlimit\n");
	  
	  integrateCU<<<Nblocks, threads_per_block>>>
	    (ti, te, tlen, cu_soln, h_integ, cu_params, cu_dparamsp, cu_y);
	  cudaCheckError();
	  printf("...submitted parallel CUDA integrateCU().\n");
	  
	  cudaMemcpy(soln, cu_soln, sizeof(double)*tlen*nvars, cudaMemcpyDeviceToHost);
	  cudaCheckError();
	  printf("...finished copying solution from device to host.\n");
	  
	  storeResult(soln);
	  free(soln);
	}
      catch (const std::exception& e)
	{
	  std::cout << "Exception in CUDA code block!" << std::endl;
	  std::cout << e.what() << std::endl;
	}
      printf("done integrating with CUDA.\n");
    }
#endif
  
  if((int)bp.size() > 0)
    {
      auto bpres = std::minmax_element(bp.begin(), bp.end());
      printf("bpmin=%.7f bpmax=%.7f\n",*bpres.first,*bpres.second);
    }
  else
    {
      std::cout << "error! bp.size=0! (no blood pressure generated!)\n";
    }
  
  time = linspace(ti, te, (int)tv.size());
  printf("time.size=%d ti=%.2f te=%.2f\n",(int)time.size(), ti, te);

  processResult(params);
}

void Model::storeResult(double *soln)
{
  int ix_t;
  int N_store = (!cuda)?(tlen/nthreads):tlen;
  for(int i=0; i < N_store; i++)
    {
      ix_t = i*nvars; // ix offset
    
      // Neurons
      prei.sig.push_back(soln[ix_t]);
      earlyi.sig.push_back(soln[ix_t+1]);
      auge.sig.push_back(soln[ix_t+2]);
      posti.sig.push_back(soln[ix_t+3]);
      rampi.sig.push_back(soln[ix_t+4]);
      
      // everything else
      tv.push_back(soln[ix_t+9]);
      hr_phase.push_back(soln[ix_t+10]);
      bp.push_back(soln[ix_t+11]);
    }
}

void Model::processResult(struct parameters *params)
{
  // process model output
  calcHR();
  printf("calculated HR, ecg.\n");

  check_for_nans();
  printf("checked for nans.\n");
  
  resp_peaks();
  printf("finished resp_peaks.\n");
  if(insp0_ix.size()==0||exp0_ix.size()==0)
    return;

  calc_rsa();
  if((int)rsa_phase.size()==0||(int)rri_vect.size()==0)
    {
      std::cout << "0 RSA phases produced." << std::endl;
      dstats.avg_rri = -999;
      return;
    }
  printf("finished calc_rsa.\n");

  calc_b2i();
  printf("finished calc_b2i.\n");
  
  calc_cvc();
  printf("finished calc_cvc.\n");

  printf("calcBP started...\n");
  calcBP(params);
  printf("calcBP finished.\n");
  
  printf("scaling resp to normal range...\n");
  printf(" TV_RANGE = [ %.2f , %.2f ]\n",sranges["tvmin"],sranges["tvmax"]);
  tv = normalize_d(tv, sranges["tvmin"], sranges["tvmax"]);

  printf("finding Q vals for RSA...\n");
  interp_rsa_segs(dparams.Qwins, rsa_phase, rri_diff,
		  time_beat, Qmap, saver->output_folder, db);

  printf("interpolating entire time series of RSA...\n");
  double qc[4];
  std::vector<Beatix> BmapInterp = interp_rsa(qc, rri_diff.size(), Bmap);
  qcomps.assign(qc, qc+4);
  std::vector<double> phaset, difft, errt;
  for(int i=0; i < BmapInterp.size(); i++)
    {
      phaset.push_back(BmapInterp.at(i).phase);
      difft.push_back(BmapInterp.at(i).rri_diff);
      errt.push_back(compute_mad(rri_diff));
    }
  rsa_phase = phaset;
  rri_diff = difft;
  rsa_stderr = errt;
}

void Model::calcBP(struct parameters *params)
{
  printf("scaling BP to range...\n");
  printf(" BP TARGET RANGE = [ %.2f , %.2f ]\n",sranges["bpmin"],sranges["bpmax"]);
  // auto bxminmax = std::minmax_element(bp.begin(), bp.end());
  // printf(" BP INPUT RANGE = [ %.2f , %.2f ]\n",*bxminmax.first,*bxminmax.second);
  // double alpha_bp = (sranges["bpmax"]-sranges["bpmin"])/(*bxminmax.second-*bxminmax.first);
  // double BPmin=(1+(params->po)-(*bxminmax.first))*alpha_bp;
  // double BPmax=(*bxminmax.second-(1+params->po+params->svol))*alpha_bp+sranges["bpmax"];
  // printf(" BP CALC RANGE = [ %.2f , %.2f ]\n",BPmin,BPmax);
  // bp = normalize_d(bp, BPmin, BPmax);
  // auto byminmax = std::minmax_element(bp.begin(), bp.end());
  // printf(" BP OUTPUT RANGE = [ %.2f , %.2f ]\n",*byminmax.first,*byminmax.second);
  calc_bp();
}

void Model::calcHR()
{
  double thresh = 0.98; //0.98
  printf("started calcHR...\n");
  printf("hr_phase.size = %d\n",(int)hr_phase.size());
  ecg.push_back(beat(hr_phase[0]));
  for(int i=1; i<hr_phase.size(); i++)
    {
      ecg.push_back(beat(hr_phase[i]));
      if( beat(hr_phase[i-1]) < thresh && beat(hr_phase[i]) >= thresh)
	beat_ix.push_back(i);
    }
  printf("beatix.size = %d\n",(int)beat_ix.size());
  ecg = normalize_d(ecg, sranges["ecgmin"], sranges["ecgmax"]);
}

void Model::save(std::string fn_ext){

  std::cout << "\nsaving to .cardio..." << std::endl;

  fn_ext = replace_underscores(fn_ext); // replace underscores in fn_ext
  std::cout << "fn_ext = " << fn_ext << std::endl;

  save_raw(db);
  save_qmap(fn_ext, saver->output_folder);
  
  std::ofstream mfile;
  std::string ext = ".cardio";
  std::string fn;

  // time
  saver->save_double(fn_ext, "time", time);
  saver->save_double(fn_ext, "timecvc", time_cvc);
  saver->save_double(fn_ext, "timebeat", time_beat);
  saver->save_double(fn_ext, "timeresp", time_resp);
  saver->save_double(fn_ext, "cvctime", cvctime);
  saver->save_double(fn_ext, "svtime", svtime);
  saver->save_double(fn_ext, "beat2insp", beat2insp);
  saver->save_double(fn_ext, "time_b2i", time_b2i);
  saver->save_double(fn_ext, "bpsystime", bpsystime);
  
  // BP
  saver->save_double(fn_ext, "bp", bp);
  saver->save_double(fn_ext, "stroke_vol", stroke_vol);
  saver->save_double(fn_ext, "svol_diff", svol_diff);
  saver->save_int(fn_ext, "bp_maxs", bp_maxs);
  saver->save_int(fn_ext, "bp_mins", bp_mins);
  saver->save_double(fn_ext, "bpsysdiff", bpsysdiff);
  saver->save_int(fn_ext, "bp_pulseix", bp_pulseix);
  saver->save_double(fn_ext, "bpplen", bp_len); // pulse time lengths
  saver->save_int(fn_ext, "bp_pulseix1", bp_pulseix1);
  saver->save_double(fn_ext, "bpresp_nat", bpresp_nat); // bp vs resp phase (measured)
  saver->save_double(fn_ext, "bpmresp_nat", bpmresp_nat); // bp vs resp phase (measured)
  
  // heart signals
  saver->save_double(fn_ext, "qcomps", qcomps);
  saver->save_int(fn_ext, "beatix", beat_ix);
  saver->save_double(fn_ext, "hrri", rri_vect);
  saver->save_double(fn_ext, "hrridiff", rri_diff);
  saver->save_double(fn_ext, "hrsastderr", rsa_stderr);
  saver->save_double(fn_ext, "hrsaphase", rsa_phase);
  saver->save_double(fn_ext, "hcvcphase", cvc_phase);
  saver->save_double(fn_ext, "hecg", ecg);
  saver->save_double(fn_ext, "cvcdist", cvcdist);
  saver->save_double(fn_ext, "cvcerr", cvcerr);
  
  // Lung signals
  saver->save_int(fn_ext, "lexp0ix", exp0_ix);
  saver->save_int(fn_ext, "linsp0ix", insp0_ix);
  saver->save_double(fn_ext, "linspdur", insp_dur);
  saver->save_double(fn_ext, "lexpdur", exp_dur);
  saver->save_double(fn_ext, "respdur", respdur);
  saver->save_double(fn_ext, "ltv", tv);
  
  // Neural signals
  saver->save_double(fn_ext, "zprei", prei.sig);
  saver->save_double(fn_ext, "zearlyi", earlyi.sig);
  saver->save_double(fn_ext, "zauge", auge.sig);
  saver->save_double(fn_ext, "zposti", posti.sig);
  saver->save_double(fn_ext, "zrampi", rampi.sig);

  // save dstats
  saver->save_dstats(fn_ext, dstats);

  std::cout << "\nData saved with ID: " << fn_ext << "\n";
}
