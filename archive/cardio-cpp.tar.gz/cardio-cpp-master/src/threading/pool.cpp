#include "thread_pool.h"

ThreadPool::ThreadPool() : m_func_q(), m_lock(), m_dcond(), m_accept_func(true)
{
}

ThreadPool::~ThreadPool()
{
}

void ThreadPool::push(std::function<void()> func)
{
  std::unique_lock<std::mutex> lock(m_lock);
  m_func_q.push(func);
  lock.unlock();
  m_dcond.notify_one();
}

void ThreadPool::done()
{
  std::unique_lock<std::mutex> lock(m_lock);
  m_accept_func = false;
  lock.unlock();
  m_dcond.notify_all();
}

void ThreadPool::loop_func()
{
  std::function<void()> func;
  while(true)
    {
      {
	std::unique_lock<std::mutex> lock(m_lock);
	m_dcond.wait(lock, [this]() { return !m_func_q.empty() || !m_accept_func; });
	if (!m_accept_func && m_func_q.empty())
	  {
	    // end thread loop, lock is released immediately
	    return;
	  }
	func = m_func_q.front();
	m_func_q.pop(); // release the lock
      }
      func();
    }
}
