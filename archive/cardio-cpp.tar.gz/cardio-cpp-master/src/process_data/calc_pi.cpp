#include "process_data.h"
#include <stdio.h>
#include <iostream>
#include <algorithm>
#include "utils.h"

void DB::calc_pi()
{
  /* calculate the Pulmonary Index (PI)
     -> 10 means all is normal;
        anything below 8 requires attention
   */

  // calculate the per-minute averages for each signal
  rolling_minute(co2_pm, co2_diff, time_resp);
  rolling_minute(rr_pm, resp_rate, time_resp);

  // estimate spo2 as 100 - ( 100 * co2_diff / max(co2_diff) )
  if(spo2.size() == 0)
    {
      auto max_co2diff = std::max_element(co2_diff.begin(), co2_diff.end());
      for(int cix=0; cix < co2_diff.size(); cix++)
	spo2.push_back(100.0 - 100.0*co2_diff.at(cix) / *max_co2diff);
    }
  rolling_minute(spo2_pm, spo2, time, &time_pm);
  rolling_minute(hr_pm, hr_vect, time_beat);

  // calculate the pulmonary index
  int i=0,j=0,j0=0,k=0,k0=0,pix=1;
  double ti,trj,tbk,tdiff,tmin;
  double si,cj,rj,bk;
  while (i < time_pm.size())
    {
      ti = time_pm[i];
      trj = time_resp[i];      
      tbk = time_beat[i];

      // std::cout << "ti=" << ti << "; trj=" << trj << "; tbk=" << tbk << std::endl;

      si = spo2_pm[i];
      cj = co2_pm[i];
      rj = rr_pm[i];
      bk = hr_pm[i];

      if (
	  (rj >= 12.0 && rj <= 28.0) &&
	  (cj >= 28.0 && cj <= 44.0) &&
	  (si > 94.0) &&
	  (bk >= 60.0 && bk <= 80.0)
	  )
	{
	  pix = 10;
	}
      else if (
	       (rj >= 12.0 && rj <= 28.0) &&
	       (cj >= 28.0 && cj <= 44.0) &&
	       (si >= 90.0 && si <= 94.0) &&
	       (bk >= 60.0 && bk <= 80.0)
	       )
	{
	  pix = 9;
	}
      else // pix <= 8 
	{
	  pix = 8;
	  if (
	      (rj > 12 && rj < 16) &&
	      (cj >= 64 || cj < 12) &&
	      (si < 90)
	      )
	    {
	      pix = 6;
	    }
	  else if (
		   ( (rj > 12 && rj < 16) &&
		     (cj >= 64 || cj < 12) &&
		     (si > 90) ) ||
		   ( (rj > 12 && rj < 16) &&
		     ( (cj >= 44 && cj < 64) || (cj <= 24 && cj > 12) ) &&
		     (si < 90)
		     )
		   )
	    {
	      pix = 7;
	    }
	  else if (
		   (rj > 12 && rj < 16) &&
		   ( (cj >= 44 && cj < 64) || (cj > 12 && cj <= 24) ) &&
		   (si > 90)
		   )
	    {
	      pix = 8;
	    }
	  else {
	    pix = 5;
	  }
	}
      
      pulm_index.push_back(pix);
      i += 1;
    }
}

