#include <algorithm>
#include <time.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <vector>
#include <cmath>
#include <map>
#include "process_data.h"
#include "utils.h"
#include "opt.hpp"

bool order_bmap(const Beatix bi, const Beatix bj)
{
  return (bi.phase < bj.phase);
}

void interp_rsa_segs(int parts,
		     std::vector<double> rsa_phase,
		     std::vector<double> rri_diff,
		     std::vector<double> time_beat,
		     std::vector<Qix>& Qmap,
		     std::string output_dir,
		     std::string fn_ext)
{
  srand(time(NULL));
  int N = (int) rsa_phase.size() / parts;
  std::cout << "\n  part_size=" << N << std::endl;
  std::cout << "  nparts=" << parts << std::endl;
  std::vector<Beatix> tempbmap;
  int i0, i1, ik=0;
  int wsize = (int)(rsa_phase.size()/parts);
  for(int i=0; i<parts; i++)
    {
      i0 = (int)(wsize*i);
      i1 = (int)(wsize*(i+1));
      ik = i0;
      while(ik < i1) 
	{
	  Beatix tmpb;
	  tmpb.ix = ik-i0;
	  tmpb.time_beat = time_beat[ik];
	  tmpb.phase = rsa_phase[ik];
	  tmpb.rri_diff = rri_diff[ik];
	  tempbmap.push_back(tmpb);
	  ik += 1;
	}
      calc_q(i, tempbmap.size(), tempbmap, Qmap, output_dir, fn_ext);
      std::vector<Beatix>().swap(tempbmap);
    }
}

void save_seg(int qix,
	      std::vector<double> rri_phase,
	      std::vector<double> rri_diff,
	      std::vector<double> rri_error,
	      std::string output_dir,
	      std::string fn_ext)
{
  fn_ext = replace_underscores(fn_ext);

  std::ofstream mfile;
  std::string ext = ".cardio";
  std::string ixstr = std::to_string(qix);
  if(qix<10)
    {
      ixstr = "0" + ixstr;
    }
  std::string fn = output_dir + "rsaseg_" + ixstr + fn_ext + ext;
  mfile.open(fn, std::ios::out);
  for(int i=0; i < rri_phase.size(); i++)
    {
      mfile << std::to_string(rri_phase[i]) << "," << std::to_string(rri_diff[i]) << "," << std::to_string(rri_error[i]) << std::endl;
    }
  mfile.close();
}

double trig_poly(double phase, double a0, double A, double B);
void fit_cosine_trans(std::vector<double> phase, std::vector<double>& Fx, double abc[3]);
double generate_guess(double x0, double x1);
// std::vector<float> rsa_cost(std::vector<float> rphase, std::vector<float> rdiff);

double trig_poly(double phase, double a0, double A, double B)
{
  return A*cos(phase*2.0*M_PI) + B*sin(phase*2.0*M_PI) + a0;
}

double generate_guess(double x0, double x1)
{
  return (x1-x0)*((double)(rand())/RAND_MAX);
}

void fit_cosine_trans(std::vector<double> phase, std::vector<double>& Fx, double abc[3])
{
  abc[0] = 0.0;
  abc[1] = 0.0;
  abc[2] = 0.0;
  int iters = 0;
  float err = 0;
  std::vector<float> oerr;
  std::vector<float> p0 = { (float)median_full(Fx), (float)median_full(Fx), (float)compute_mad(Fx) };
  std::vector<float> p1(p0);
  std::cout << "p0 = " << p0[0] << " " << p0[1] << " " << p0[2] << std::endl;
  Optimizer opt(p0);
  opt.sigma = (float)(median_full(Fx)*1e-2/(float)Fx.size());
  std::vector<float> phasef((int)phase.size()), Fxf((int)Fx.size());
  for(int k=0; k < (int)phase.size(); k++)
    {
      phasef.at(k) = (float)phase.at(k);
      Fx.at(k) = (float)Fx.at(k);
    }
  opt.cost_func = [&opt](std::vector<float> rphase, std::vector<float> rdiff)
    {
      std::vector<float> cost(3,0);
      for(int i=0; i < (int)rphase.size(); i++)
	{
	  float cres = (float)trig_poly((double)rphase.at(i),(double)opt.p()[0],(double)opt.p()[1],(double)opt.p()[2]);
	  for(int j=0; j < 3; j++)
	    {
	      cost.at(j) += (float)pow((rdiff.at(i)-cres),2)*opt.sigma;
	    }
	}
      return cost;
    };
  while(true)
    {
      opt.train_once_supervised(phasef, Fxf);
      if(iters > 10)
	{
	  if(iters>(int)(100*(int)phase.size()) || opt.converged)
	    break;
	}
      iters++;
    }
  for(int j=0; j < (int)opt.M(); j++)
    {
      abc[j] = (double)opt.p().at(j);
    }
  for(int ri=0; ri < Fx.size(); ri++)
    Fx.at(ri) = trig_poly(phase.at(ri), abc[0], abc[1], abc[2]);
  oerr = opt.training_error();
  err = 0;
  for(float& terr: oerr)
    err += std::abs(terr);
  err /= (float)iters;
  std::cout << "RSAfit total_iters=" << iters << " total_resid=" << err << " A= " << abc[1] << " B= " << abc[2]
  	    << " a0=" << abc[0] << std::endl;
}

void calc_q(int qix, int N,
	    std::vector<Beatix> Bmap,
	    std::vector<Qix>& Qmap,
	    std::string output_dir,
	    std::string fn_ext)
{
  /* The Qmap argument is used to store Q for each time segment,
     and save_seg(...) saves each segment to a datafile
   */
  std::vector<Beatix> bmap(Bmap);
  std::vector<double> rsa_phase(N), rri_diff(N);
  for(int i=0; i < N; i ++)
    {
      rsa_phase[i] = bmap[i].phase;
      rri_diff[i] = bmap[i].rri_diff;
    }

  // rri_diff = median_perc_filter(rri_diff, 3);
  
  // calculate Q -> A, B using a sine-cosine transform
  double ab[3];
  fit_cosine_trans(rsa_phase, rri_diff, ab);
  double Q;
  Q = sqrt(pow(ab[0],2) + pow(ab[1],2) + pow(ab[2],2));
  
  // set rri_error
  std::vector<double> rri_error(rri_diff.size());
  for(int i=0; i < rri_error.size(); i++)
    {
      rri_error[i] = compute_mad(rri_diff);
    }
  
  // save rsa segment
  save_seg(qix, rsa_phase, rri_diff, rri_error, output_dir, fn_ext);
  
  Qix cQ; // assign Q -> Qerr in Qmap
  cQ.ix = qix;
  cQ.time = (bmap[0].time_beat+bmap.back().time_beat)/2.0;
  cQ.Q = Q;
  cQ.Qerr = compute_mad(rri_diff)/sqrt(rsa_phase.size());
  for(int iq=0; iq < 3; iq++)
    cQ.Qcomps[iq] = ab[iq];
  Qmap.push_back(cQ);
}

std::vector<Beatix> interp_rsa(double Qcomps[3], int N,std::vector<Beatix> Bmap)
{
  /* bmap is the output, which is used as the (rri_diff, rsa_phase)
     for the entire time series */
  srand(time(NULL));
  std::vector<Beatix> bmap(Bmap);
  std::vector<double> tbeats(N), rsa_phase(N), rri_diff(N);
  for(int i=0; i < N; i ++)
    {
      tbeats.at(i) = bmap[i].time_beat;
      rsa_phase[i] = bmap[i].phase;
      rri_diff[i] = bmap[i].rri_diff;
    }
  fit_cosine_trans(rsa_phase, rri_diff, Qcomps);
  for(int ri=0; ri < rri_diff.size(); ri++)
    {
      bmap.at(ri).time_beat = tbeats.at(ri);
      bmap.at(ri).phase = rsa_phase.at(ri);
      bmap.at(ri).rri_diff = rri_diff.at(ri);
    }  
  return bmap;
}
