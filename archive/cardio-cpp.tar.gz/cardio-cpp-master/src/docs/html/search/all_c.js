var searchData=
[
  ['qix',['Qix',['../structQix.html',1,'']]]
];
