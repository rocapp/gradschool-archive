var searchData=
[
  ['neuralsignal',['NeuralSignal',['../structNeuralSignal.html',1,'']]],
  ['nsamps',['nsamps',['../classConfig.html#a23d60c4182229c935e36813c6fe8c388',1,'Config']]]
];
