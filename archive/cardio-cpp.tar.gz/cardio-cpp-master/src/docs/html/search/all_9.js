var searchData=
[
  ['model',['Model',['../classModel.html',1,'Model'],['../classConfig.html#a04cd07299d7a50178132ec913d6f405c',1,'Config::model()']]]
];
