var searchData=
[
  ['neuralsignal',['NeuralSignal',['../structNeuralSignal.html',1,'']]]
];
