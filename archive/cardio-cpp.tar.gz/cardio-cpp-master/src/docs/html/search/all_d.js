var searchData=
[
  ['rcov',['rcov',['../classConfig.html#aef1d27b5bd7147fc46f9b5c6d1a65183',1,'Config']]],
  ['rlow',['rlow',['../structdataParams.html#a25600b77a1ef51d89e1f7c5843df1493',1,'dataParams']]],
  ['rriorder',['rriorder',['../structdataParams.html#ac0aa0cdc68a4373ecbbeb0b65ede163f',1,'dataParams']]],
  ['rsa_5fdata',['rsa_data',['../structrsa__data.html',1,'']]],
  ['rthresh',['rthresh',['../structdataParams.html#a6746b3067c3a2c7f1bb960bbc66a82c9',1,'dataParams']]]
];
