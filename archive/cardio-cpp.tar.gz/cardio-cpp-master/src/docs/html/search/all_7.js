var searchData=
[
  ['i0scale',['i0scale',['../structdataParams.html#a209c7f46da65bb24423d029b85f3b57a',1,'dataParams']]],
  ['insp_5fdur',['insp_dur',['../classDB.html#a3b8e324025e9f41c5720f2b724d31e94',1,'DB']]],
  ['ix',['ix',['../structQix.html#acc964dbdcb17319cadef9c694b4b4f82',1,'Qix']]]
];
