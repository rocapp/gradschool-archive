var searchData=
[
  ['cmap',['cmap',['../classConfig.html#aed6b28beff74f4d1b4881b6635c8b0ec',1,'Config']]],
  ['co2order',['co2order',['../structdataParams.html#a2c50169a73a5b48cfa38eca0bc952d1e',1,'dataParams']]]
];
