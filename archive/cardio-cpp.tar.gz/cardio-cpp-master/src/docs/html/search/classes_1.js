var searchData=
[
  ['beatix',['Beatix',['../structBeatix.html',1,'']]]
];
