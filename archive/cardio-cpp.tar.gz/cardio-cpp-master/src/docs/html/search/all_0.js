var searchData=
[
  ['avgstats',['avgstats',['../structavgstats.html',1,'']]]
];
