#!/bin/sh
sudo cp -r html/* ~/public_html/docs/cardio-docs/
