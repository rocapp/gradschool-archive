#include "config.h"
#include <string>
#include <cstring>
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>
#include <map>
#include <cstdlib>
#include <stdio.h>


void printUsage()
{
  printf("\n\n***cardio help***\n\n");
  printf("  Required Arguments:\n");
  printf("  -f : configuration file (absolute path)\n");
  printf("\nAdditionally, define the subject ID variable (SID).\n");
  printf("\n\nExample : \n");
  printf("user@linux:~/cardio-cpp$ SID=subject_1 ./cardio_model -f $CARDIO_SRC/config/subject_1.ini\n");
  printf("\n\n");
  printf("Alternatively, define the subject ID variable in your config file like so:\n");
  printf("\nIn your config file (e.g. $CARDIO_SRC/config/subject_1.ini), prefix a line with 'record ' followed by the subject ID.\n\n");
  printf("e.g. 'record subject_one'\n\n");
}


//! Constructor for the config class.
//! Load configuration from command-line arguments
//! and configuration (.ini) file from the $CONFIG directory.
Config::Config(int argc, char **argv){
  int c;
  opterr=0;
  cmap["dfn"] = "cardio_data.hdf5"; //!<< default name of data file (located in cmap['dpath'])
  cmap["dpath"] = std::string(getenv("CARDIO_DATA")) + "/"; //!<< location of input data files (hdf5), see `scripts/load_data.py` */
  cmap["opath"] = std::string(getenv("CARDIO_OUT")) + "/"; //!<< output directory (.cardio files)
  while ((c = getopt (argc, argv, "i:f:o:")) != -1){
    switch(c)
      {
      case 'i':
	cmap["i"] = optarg;
	break;
      case 'f':
	cmap["f"] = optarg;
	break;
      case 'o':
	cmap["opath"] = optarg;
	break;
      default:
	printUsage();
	exit(1);
      case '?':
	printUsage();
	exit(1);
      }
  }
  if(cmap["i"]=="")
    {
      try
	{  
	  cmap["i"] = std::string(std::getenv("SID")); //!<< ID of input segment/subject
	}
      catch (const std::exception& e)
	{
	  std::cout << "Subject ID environment variable SID not set!" << std::endl
		    << "Using the 'record' variable from " << cmap["f"] << std::endl;
	  std::ifstream conf(cmap["f"]);
	  std::string recstr1, recstr2;
	  if(conf.is_open())
	    {
	      while(std::getline(conf,recstr1))
		{
		  if(recstr1.find("record")!=std::string::npos)
		    {
		      std::istringstream rstm(recstr1);
		      int ct=0;
		      while(std::getline(rstm,recstr2,' '))
			{
			  if(ct==0) { ct++; } else {
			    cmap["i"] = recstr2;
			    break;
			  }
			}
		      break;
		    }
		}
	      std::cout << "Subject ID (SID) set to: " << cmap["i"] << std::endl;
	    }
	  else { printUsage(); exit(1); }
	}
    }
  
  loadConfig(cmap["f"]);
  
}

//! Load config.ini file, as specified in CONFIG env var
void Config::loadConfig(std::string cfn)
{
  // defaults
  model["svol2"] = 0.05; // slope of secondary BP peak
  model["bphase2"] = 0.455; // heart phase where secondary BP peak is centered
  std::cout << "config file : " << cfn << std::endl;
  std::string line, value, key;
  int count;
  std::ifstream cfile (cfn);
  if (cfile.is_open())
    {
      while (std::getline(cfile,line))
	{
	  count=0;
	  std::istringstream ssl(line);
	  while (std::getline(ssl,value,' '))
	    {
	      if(value.find("#")!=std::string::npos)
		{
		  break;
		}
	      if (count == 0)
		{
		  key = value;
		  std::cout << "cfkey = " << key;
		}
	      else {
		cmap[key] = value;
		std::cout << " : cfvalue = " << value << std::endl;
	      }
	      count+=1;
	    }
	}
    }

  // config options
  
  std::string::size_type sz;
  std::string ptemp,ptemp1,pkey;
  double pval;
  int cnt;
  for (auto const& item : cmap)
    {
      key = item.first;
      value = item.second;

      printf("key = %s : value = %s\n",key.c_str(),value.c_str());

      if (key=="record" && cmap["i"] == "")
	{
	  cmap["i"] = std::string(value);
	}
      else if (key=="dpath")
	{
	  if(value.find("$CARDIO_DATA")==std::string::npos)
	    {
	      cmap["dpath"] = std::string(value);
	    }
	  else
	    {
	      cmap["dpath"] = std::string(getenv("CARDIO_DATA")) + "/";
	    }
	}
      else if (key=="dfn")
	{
	  cmap["dfn"] = std::string(value);
	}
      else if (key=="opath")
	{
	  if(value.find("$CARDIO_OUT")==std::string::npos)
	    {
	      cmap["opath"] = std::string(value);
	    }
	  else
	    {
	      cmap["opath"] = std::string(getenv("CARDIO_OUT")) + "/";
	    }	
	}
      else if (key=="fs")
	{
	  std::string::size_type sz;
	  fs = std::stod(value,&sz); // sampling freq
	  dparams.fs = fs;
	}
      else if(key=="prewin") // dparams, experimental conditions windows
	{ 
	  std::string::size_type sz;
	  dparams.prewin[0] = std::stod(value.substr(0,value.find(",")),&sz);
	  dparams.prewin[1] = std::stod(value.substr(value.find(",")+1),&sz);
	}
      else if(key=="durwin")
	{
	  std::string::size_type sz;
	  dparams.durwin[0] = std::stod(value.substr(0,value.find(",")),&sz);
	  dparams.durwin[1] = std::stod(value.substr(value.find(",")+1),&sz);
	}
      else if(key=="postwin")
	{
	  std::string::size_type sz;
	  dparams.postwin[0] = std::stod(value.substr(0,value.find(",")),&sz);
	  dparams.postwin[1] = std::stod(value.substr(value.find(",")+1),&sz);
	}
      else if(key=="taup") // dparam
	{
	  std::string::size_type sz;
	  dparams.taup = std::stod(value,&sz);
	}
      else if(key=="bpminmax") // dparam
	{
	  std::string::size_type sz;
	  dparams.bpminmax[0] = std::stod(value.substr(0,value.find(",")),&sz);
	  dparams.bpminmax[1] = std::stod(value.substr(value.find(",")+1),&sz);
	}
      else if(key=="bpMinMaxScale") // dparam
	{
	  std::string::size_type sz;
	  dparams.bpMinMaxScale[0] = std::stod(value.substr(0,value.find(",")),&sz);
	  dparams.bpMinMaxScale[1] = std::stod(value.substr(value.find(",")+1),&sz);
	}
      else if(key=="e2i_minratio")
	{
	  std::string::size_type sz;
	  dparams.e2i_minratio = std::stod(value,&sz); // dparam
	}
      else if(key=="e2i_mindiff")
	{
	  std::string::size_type sz;
	  dparams.e2i_mindiff = std::stod(value,&sz); // dparam
	}
      else if (key=="resporder")
	{
	  std::string::size_type sz;
	  dparams.resporder = std::stoi(value,&sz); // dparam
	}
      else if (key=="ttol")
	{
	  std::string::size_type sz;
	  dparams.ttol = std::stod(value,&sz); // dparam
	}
      else if (key=="co2order")
	{
	  std::string::size_type sz;
	  dparams.co2order = std::stoi(value,&sz); // dparam
	}
      else if (key=="e0scale")
	{
	  std::string::size_type sz; // dparam
	  dparams.e0scale = std::stod(value,&sz);
	}
      else if (key=="i0scale")
	{
	  std::string::size_type sz; // dparam
	  dparams.i0scale = std::stod(value,&sz);
	}
      else if (key=="hlow")
	{
	  std::string::size_type sz; // dparam
	  dparams.hlow = std::stod(value,&sz);
	}
      else if (key=="hthresh")
	{
	  std::string::size_type sz; // dparam
	  dparams.hthresh = std::stod(value,&sz);
	}
      else if (key=="hheight")
	{
	  std::string::size_type sz; // dparam
	  dparams.hheight = std::stod(value,&sz);
	}
      else if (key=="hmaxheight")
	{
	  std::string::size_type sz; // dparam
	  dparams.hmaxheight = std::stod(value,&sz);
	}
      else if (key=="hn")
	{
	  std::string::size_type sz; // dparam
	  dparams.hn = std::stoi(value,&sz);
	}
      else if (key=="hp")
	{
	  std::string::size_type sz; // dparam
	  dparams.hp = std::stoi(value,&sz);
	}
      else if (key=="horder")
	{
	  std::string::size_type sz; // dparam
	  dparams.horder = std::stoi(value,&sz);
	}
      else if (key=="rriorder")
	{
	  std::string::size_type sz; // dparam
	  dparams.rriorder = std::stoi(value,&sz);
	}
      else if (key=="rlow")
	{
	  std::string::size_type sz; // dparam
	  dparams.rlow = std::stod(value,&sz);
	}
      else if (key=="rthresh")
	{
	  std::string::size_type sz; // dparam
	  dparams.rthresh = std::stod(value,&sz);
	}
      else if (key=="ilow")
	{
	  std::string::size_type sz; // dparam
	  dparams.ilow = std::stod(value,&sz);
	}
      else if (key=="ithresh")
	{
	  std::string::size_type sz; // dparam
	  dparams.ithresh = std::stod(value,&sz);
	}
      else if (key=="ethresh")
	{
	  std::string::size_type sz; // dparam
	  dparams.ethresh = std::stod(value,&sz);
	}
      else if (key=="Qwins")
	{
	  std::string::size_type sz; // dparam
	  dparams.Qwins = std::stoi(value,&sz);
	}
      else if (key=="bporder")
	{
	  std::string::size_type sz; // dparam
	  dparams.bporder = std::stoi(value,&sz);
	}
      else if (key=="nbp")
	{
	  std::string::size_type sz; // dparam
	  dparams.nbp = std::stoi(value,&sz);
	}
      else if (key=="nsamps")
	{
	  std::string::size_type sz;
	  nsamps = std::stoi(value,&sz);
	}
      else if (key=="params")
	{ // params hr=0.08,db=0.07,rsa1=0.007
	  printf("  : : : : Loading params from config file...\n");
	  std::istringstream ssv(value);
	  while (std::getline(ssv,ptemp,','))
	    { // hr=0.08
	      cnt = 0;
	      std::istringstream ssp(ptemp);
	      while (std::getline(ssp,ptemp1,'='))
		{
		  if (cnt == 0) {
		    pkey = ptemp1;
		  } else {
		    pval = std::stod(ptemp1,&sz);
		    params[pkey] = pval;
		    printf("  ** param %s = %.7f\n",pkey.c_str(),pval);
		  }
		  cnt +=1;
		}
	      pcount +=1;
	    }
	}
      else if (key=="model")
	{ // model ti=0.0,te=60.0,sfreq=240
	  std::istringstream ssvm(value);
	  std::string mtemp,mtemp1,mkey;
	  double mval;
	  printf("  --> Setting model params...\n");
	  while (std::getline(ssvm,mtemp,','))
	    { // ti=0.08
	      cnt = 0;
	      std::istringstream ssm(mtemp);
	      while (std::getline(ssm,mtemp1,'='))
		{
		  if (cnt == 0) {
		    mkey = mtemp1;
		  } else {
		    mval = std::stod(mtemp1,&sz);
		    model[mkey] = mval;
		    if(mkey=="nvhosp")
		      nvhosp = (int)model["nvhosp"];
		    if(mkey=="cuda" && (int)model["cuda"]!=0)
		      cuda = true;
		    printf("  param %s = %.3f\n",mkey.c_str(),mval);
		  }
		  cnt +=1;
		}
	    }
	  
	}
    }
}

void Config::setParams(pset& param_set, std::map<std::string, double> pmap, int gflag){

  if (gflag == 1){ // get param offset if flag is set to 1
    getParamsOffset(param_set);
  }
  
  std::string pkey;
  for (auto const& item : params) // iterate through free params
    {
      pkey = item.first;
      setParam(param_set, pkey, pmap[pkey], 0);
    }
}

void Config::setParam(pset& param_set, std::string pname, double pval, int gflag){
  if (gflag == 1){ // get param offset if flag is set to 1
    getParamsOffset(param_set);
  }
  *param_set.paddr[pname] = pval;
  std::cout << "\n" << pname << " set to : " << pval;
}

void Config::getParamsOffset(pset& param_set){
  char *base;
  double *addr;
  size_t offset;
  base = (char *) param_set.pparams;

  offset = offsetof(parameters, erica_pert);
  addr = (double *)(offset + base);
  param_set.paddr["erica_pert"] = addr;
  
  offset = offsetof(parameters, soff);
  addr = (double *)(offset + base);
  param_set.paddr["soff"] = addr;
  
  offset = offsetof(parameters, svol);
  addr = (double *)(offset + base);
  param_set.paddr["svol"] = addr;
  
  offset = offsetof(parameters, tad);
  addr = (double *)(offset + base);
  param_set.paddr["tad"] = addr;

  offset = offsetof(parameters, tad_ei);
  addr = (double *)(offset + base);
  param_set.paddr["tad_ei"] = addr;
  
  offset = offsetof(parameters, tauhp);
  addr = (double *)(offset + base);
  param_set.paddr["tauhp"] = addr;
  
  offset = offsetof(parameters, rs1);
  addr = (double *)(offset + base);
  param_set.paddr["rs1"] = addr;

  offset = offsetof(parameters, hr);
  addr = (double *)(offset + base);
  param_set.paddr["hr"] = addr;

  offset = offsetof(parameters, rsa1);
  addr = (double *)(offset + base);
  param_set.paddr["rsa1"] = addr;

  offset = offsetof(parameters, rsa2);
  addr = (double *)(offset + base);
  param_set.paddr["rsa2"] = addr;

  offset = offsetof(parameters, po);
  addr = (double *)(offset + base);
  param_set.paddr["po"] = addr;

  offset = offsetof(parameters, taup);
  addr = (double *)(offset + base);
  param_set.paddr["taup"] = addr;

  offset = offsetof(parameters, taul);
  addr = (double *)(offset + base);
  param_set.paddr["taul"] = addr;

  offset = offsetof(parameters, taupp);
  addr = (double *)(offset + base);
  param_set.paddr["taupp"] = addr;

  offset = offsetof(parameters, baro);
  addr = (double *)(offset + base);
  param_set.paddr["baro"] = addr;

  offset = offsetof(parameters, sym);
  addr = (double *)(offset + base);
  param_set.paddr["sym"] = addr;

  offset = offsetof(parameters, db);
  addr = (double *)(offset + base);
  param_set.paddr["db"] = addr;

  offset = offsetof(parameters, sb);
  addr = (double *)(offset + base);
  param_set.paddr["sb"] = addr;

  offset = offsetof(parameters, d1);
  addr = (double *)(offset + base);
  param_set.paddr["d1"] = addr;
  
  offset = offsetof(parameters, d2);
  addr = (double *)(offset + base);
  param_set.paddr["d2"] = addr;

  offset = offsetof(parameters, d3);
  addr = (double *)(offset + base);
  param_set.paddr["d3"] = addr;
  
  offset = offsetof(parameters, d4);
  addr = (double *)(offset + base);
  param_set.paddr["d4"] = addr;

  offset = offsetof(parameters, d5);
  addr = (double *)(offset + base);
  param_set.paddr["d5"] = addr;  
}
