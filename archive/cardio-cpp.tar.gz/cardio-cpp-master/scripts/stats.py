#!/usr/local/bin/python3.6
import numpy as np
from scipy.spatial.distance import cdist
from scipy.optimize import curve_fit

def calculate_q_from_comps(cp, A, B, a0): # A, B, a0
    return A*np.cos(2*np.pi*cp) + B*np.sin(2*np.pi*cp) + a0

def fit_rsa(phase, rdiff, p0):
    popt, pcov = curve_fit(calculate_q_from_comps, phase, rdiff, p0=p0)
    return popt, np.sqrt(np.diag(pcov))

def cauchy_quantile(x0,gamma,p):
    return x0 + gamma*np.tan(np.pi*(p-0.5))

def cauchy_cdf(x0,gamma,x):
    # returns : X, Pr(X <= x) <--- sorted to be monotonically incr.
    # pr = np.arctan((x-x0)/gamma)/np.pi + 0.5
    cdix = np.argsort(x)
    return x[cdix], np.linspace(0, 1, x.size)

def cauchy_entropy(gamma):
    return np.log(4*np.pi*gamma)

def compute_mad(x):
    return np.median(np.abs(x-np.median(x)))

def sup_diff(cargs):
    cp1, cdf2 = cargs
    dmax = np.max(np.abs(cp1 - cdf2))
    return dmax

import scipy

def ks2sample(cdf1, N, cdf2, M, alpha, retN=False):
    # N, M: number of samples
    # alpha: level at which to reject the null
    cdf1 = cdf1[::100] if cdf1.size > 1e4 else cdf1
    cdf2 = cdf2[::100] if cdf2.size > 1e4 else cdf2
    cdf1 = cdf1[:-1] if cdf1.size % 2 != 0 else cdf1
    cdf2 = cdf2[:-1] if cdf2.size % 2 != 0 else cdf2
    Dnm = 0.1*np.max(scipy.spatial.distance.cdist(np.atleast_2d(cdf1).reshape(-1,2),
                                                  np.atleast_2d(cdf2).reshape(-1,2),
                                                  "chebyshev"))
    # print("Dnm=",Dnm)
    calpha = np.sqrt(-0.5*np.log(alpha*0.5))
    try:
        reqN = int(np.power(calpha/Dnm, 2))
    except OverflowError:
        reqN = int(N*1e3)
    if not retN:
        return (Dnm*np.sqrt(N) > calpha) and (N+M >= 2*reqN)
    return reqN, (N+M >= 2*reqN)

def ks2_compute_pvalues(cdf_dict, epochs, linalpha, signal_names):
    """
    return: pdict[sigk][(epoch1, epoch2, subjx)]
    """
    pdict = {}
    cdf_dict["unif"] = {}
    for aix, sigk in enumerate(signal_names): # iterate through signals
        pdict[sigk] = {}
        cdf_dict["unif"][sigk] = []
        for eix, ename in enumerate(epochs):
            for ei2, e2 in enumerate(epochs+["unif"]): # KS test
                if eix != ei2:
                    for subjx in np.arange(len(cdf_dict["pre"]["rsa"])):
                        try:
                            print("uniflen=",len(cdf_dict["unif"][sigk]))
                            if len(cdf_dict["unif"][sigk]) <= subjx:
                                cdf_dict["unif"][sigk].append((np.linspace(0.0, 1.0, len(cdf_dict[ename][sigk][subjx][1])),
                                                               np.linspace(0.0, 1.0, len(cdf_dict[ename][sigk][subjx][1]))))
                            print(sigk, subjx, ename, e2)
                            print("subj-uniflen",subjx,len(cdf_dict[e2][sigk][subjx]))
                            for kalpha in linalpha:
                                if ks2sample(cdf_dict[ename][sigk][subjx][1], len(cdf_dict[ename][sigk][subjx][1]),
                                             cdf_dict[e2][sigk][subjx][1], len(cdf_dict[e2][sigk][subjx][1]), kalpha):
                                    print("KS2 : ", sigk, subjx, ename, e2, kalpha)
                                    if (e2, ename, subjx) in pdict[sigk] and pdict[sigk][(e2, ename, subjx)] < kalpha:
                                        pdict[sigk][(ename, e2, subjx)] = pdict[sigk][(e2, ename, subjx)]
                                        break
                                    elif (ename, e2, subjx) in pdict[sigk] and pdict[sigk][(ename, e2, subjx)] < kalpha:
                                        break
                                    else:
                                        pdict[sigk][(ename, e2, subjx)] = kalpha
                                        break
                        except IndexError as excep:
                            print("IndexError:",excep)
                            pass
    return pdict

    
def cauchy_t2sample(x1, err1, N, x2, err2, M):
    sp = np.sqrt(err1*err1/N + err2*err2/M) 
    t = (x1 - x2) / sp # Welch's t-test
    t_dstr = np.random.standard_t(1, size=1e6) # shown to be equal to a cauchy distribution
    p = np.sum(t_dstr<t) / float(len(t_dstr))
    return p
    
