#!/usr/local/bin/python3.6

import subprocess
import json
import os
import numpy as np
import sys
import time
 
make_path = "/home/rocapp/Git/cardio-cpp"
dpath = "/home/rocapp/Public/sepsis_records/RECORDS.json"
os.chdir(make_path)

if __name__ == "__main__":
    with open(dpath, "r") as f:
        rdict = json.load(f)

    want = "V"
    wcnt = 0
    for jk, jv in rdict.items():
        wic = 0
        for recv in jv.keys():
            if jv[recv]['sigs']:
                if want in jv[recv]['sigs']:
                    wic += 1
        if wic >= 2: wcnt += 1
    print(wcnt)
    print(wcnt / len(rdict.items()))
