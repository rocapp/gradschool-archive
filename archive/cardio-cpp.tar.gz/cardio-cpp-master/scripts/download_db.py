#!/usr/local/bin/python3.6
import wfdb # v2.2.1
import os,sys

if __name__=="__main__":
    db = sys.argv[1]
    rec = sys.argv[2]
    db_path = os.path.expanduser("~/Public/{}".format(db))
    records = [rec,]
    wfdb.io.dl_database(db, db_path, records=records)
