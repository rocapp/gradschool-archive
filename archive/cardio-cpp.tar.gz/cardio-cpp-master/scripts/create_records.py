#!/usr/local/bin/python3.6

import subprocess
import json
import os
import numpy as np
import sys
import time
import datetime
import h5py # h5py 2.8.0 (from pip3)

make_path = "/home/rocapp/Git/cardio-cpp"
jpath = "/home/rocapp/Public/sepsis_records/records_check.json"
dpath = "/home/rocapp/Public/sepsis_records/RECORDS.json"
hf = h5py.File(os.path.join(make_path, "data/sepsis_data.hdf5"), "r") # hdf5 file, contains all data

os.chdir(make_path)

def get_tsep(rec):
    # given a record, return the time sepsis occurs in seconds
    try:
        hdb = hf[rec]
        return hdb.attrs.get("t0")
    except KeyError:
        return None

def get_sigs(rec):
    # given a record, return which signals are available
    try:
        cmd = "wfdbsignals {}".format(rec)
        pcomp = subprocess.run(cmd, shell=True, check=True,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               encoding='utf-8')
        sout = pcomp.stdout
        sigs = sout.split("\n")
        sigs = [sig for sig in sigs if len(sig) > 0]
        return sigs
    except (subprocess.CalledProcessError,AttributeError):
        return False

def default(o):
    if isinstance(o, np.int64): return int(o)
    raise TypeError

def updateRecords(newdict):
    with open(dpath, "w") as f:
        json.dump(newdict, f, default=default)
    print("RECORDS db updated.\n")

if __name__ == "__main__":
    with open(jpath, "r") as f:
        rdict = json.load(f)

    RECORDS = {}

    lookin = ["Fig",True]
    
    for jk, jv in rdict.items():
        recnames = jv[0]
        if jv[1] in lookin:
            RECORDS.update({jk : {}})
            print(jk)
            for rec in recnames:
                t0 = get_tsep(rec)
                sigs = get_sigs(rec)
                rec_info = {"tsep": t0,
                            "sigs": sigs,
                            "resp": None}
                RECORDS[jk].update({rec : rec_info, 'use': jv[1]})
            print("    ",RECORDS[jk])
    updateRecords(RECORDS)
                
