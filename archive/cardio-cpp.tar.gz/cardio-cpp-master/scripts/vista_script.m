path(path,genpath('/home/rocapp/edfread'));

folderInfo=dir('/home/rocapp/Public/VistaData/VISTA_EDF_FILES/**/*.edf');
folderOut='/home/rocapp/Public/VistaData/';
hfile = '/home/rocapp/Git/cardio-cpp/data/vista_data.hdf5';
for fi=1:length(folderInfo)
    fold = folderInfo(fi).folder;
    fn = folderInfo(fi).name;
    disp(['Opening : ', fn, '...']);
    [head,rec]=edfread(fullfile(fold, fn));
    recout = []; hout = {};
    ik = 1;
    for ii=1:length(head.label)
        labi = head.label(ii);
        if contains(labi{1}, "II")
            hout{ik} = 'II';
            recout = [recout ; rec(ii,:)];
            ik=ik+1;
        elseif contains(labi{1}, "Resp")
            hout{ik} = 'Resp';
            recout = [recout ; rec(ii,:)];
            ik=ik+1;
        elseif contains(labi{1}, "Pleth")
            hout{ik} = 'SPO2';
            recout = [recout ; rec(ii,:)];
            ik=ik+1;
        elseif contains(labi{1}, ["CVP", "PA", "BP"])
            hout{ik} = 'BP';
            recout = [recout ; rec(ii,:)];
            ik=ik+1;
        end
    end
    fnsplit = strsplit(fn, '_');
    dname = fullfile('/', fnsplit{1});
    disp([size(recout), size(hout)]);
    try
        h5create(hfile, dname, size(recout));
    catch Ee
        disp(Ee);
    end
    h5write(hfile, dname, recout);
    for hi=1:length(hout)
        h5writeatt(hfile, dname, hout{hi}, round(hi-1));
    end
    disp(' ...done.');
end

h5disp(hfile);
