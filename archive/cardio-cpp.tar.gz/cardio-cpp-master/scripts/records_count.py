#!/usr/local/bin/python3.6
import json,sys,os

if __name__ == "__main__":

    spath = "/home/rocapp/Public/sepsis_records"
    fn="records_check.json"
    
    if len(sys.argv) > 1:
        fn = sys.argv[1]

    fpath = os.path.join(spath, fn)
    with open(fn, "r", encoding="utf-8") as f:
        cdict = json.load(f)
    
    cis = [cv for ck, cv in cdict.items() if cv[1] == True or cv[1] == 'Fig']
    # cis = [cv for ck, cv in cdict.items() if cv[1] == False]

    print("\nNumber of subjects that have both non/sepsis available: ",len(cis))
    print("\n",cis)
