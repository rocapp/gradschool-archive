#!/usr/bin/env bash

# set default env vars if not defined
TESTS=${TESTS:-test_hdf5}; printf '%s\n' "$TESTS"

CARDIO_SRC=${CARDIO_SRC:-/home/$USER/Git/cardio-cpp/}
CARDIO_SRC=$(realpath -ms $CARDIO_SRC)
printf '%s\n' "$CARDIO_SRC"

CARDIO_OUT=${CARDIO_OUT:-/home/$USER/Documents/cardio-output/}
CARDIO_OUT=$(realpath -ms $CARDIO_OUT)
printf '%s\n' "$CARDIO_OUT"

CARDIO_DATA=${CARDIO_DATA:-/home/$USER/Git/cardio-cpp/data/}
CARDIO_DATA=$(realpath -ms $CARDIO_DATA)
printf '%s\n' "$CARDIO_DATA"

CONFIG=${CONFIG:-$CARDIO_SRC/config/$1.ini}
printf '%s\n' "$CONFIG"

CARDIO_FIG=${CARDIO_FIG:-/home/$USER/public_html/sepsis_data/figs/}
CARDIO_FIG=$(realpath -ms $CARDIO_FIG)
printf '%s\n' "$CARDIO_FIG"

SID=${SID:-silent-build}
printf '%s\n' "$SID"

sleep 1;

cd $CARDIO_SRC

export -p H5=1 SID TESTS CARDIO_FIG CARDIO_DATA CARDIO_SRC CARDIO_OUT CONFIG

[[ ! -d "$CARDIO_OUT" ]] && mkdir $CARDIO_OUT

[[ $SID == *"Erica"* ]] && DFN="erica_data.hdf5" || DFN="sepsis_data.hdf5"

echo ==== $SID ====
sleep 2;

set -e # any failures beyond here will cause an exit

echo Building...
echo
cd $CARDIO_SRC && make tests
