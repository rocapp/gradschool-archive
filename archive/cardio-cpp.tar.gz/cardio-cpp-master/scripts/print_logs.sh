#!/bin/bash

# Print Virtual Hospital Simulation Logs, Detect Keyboard Interrupt

control_c() {
    kill $PID
    exit
}

trap control_c SIGINT

my_cmd() {

    export recent_log=$(ls -ct $CARDIO_OUT/log* | head -1)
    export recent_weights=$(ls -ct $CARDIO_OUT/Wv* | head -1)
    cat $recent_log;
    python -c \
	   $'import numpy as np; import os; aa=np.loadtxt(os.environ["recent_weights"]); print("max:", np.argmax(aa), aa[np.argmax(aa)], ", min:", np.argmin(aa), np.min(aa))';
    sleep 30;
    
}

while(true);
do
    my_cmd | while read line; do
	PID=$!
	echo $line
    done
done
