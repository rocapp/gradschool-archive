#!/usr/bin/env bash
for ff  in $(cat erica_subjects.txt)
do
    ./scripts/build.sh $ff
done
