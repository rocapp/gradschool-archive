import matplotlib as mpl
mpl.use("Agg")

mpl.rcParams['figure.titlesize'] = 36
mpl.rcParams['figure.figsize'] = (12,12)
mpl.rcParams['figure.dpi'] = 100 #300

mpl.rcParams['figure.subplot.hspace'] = 0.05

mpl.rcParams['savefig.bbox'] = 'tight'

axfontsize = 24
mpl.rcParams['axes.labelsize'] = axfontsize
mpl.rcParams['axes.titlesize'] = axfontsize+4

tickfontsize = 14
mpl.rcParams['xtick.labelsize'] = tickfontsize
mpl.rcParams['ytick.labelsize'] = tickfontsize

import matplotlib.pyplot as plt

import subprocess
import json
import os
import numpy as np
import sys
import time

make_path = "/home/rocapp/Git/cardio-cpp"
cardio_dir = make_path
jpath = "/home/rocapp/Public/sepsis_records/records_check.json2018-08-08"
os.chdir(make_path)

if __name__ == "__main__":
    with open(jpath, "r") as f:
        rdict = json.load(f)

    lookin = ["Fig",]

    rd = []
    
    rds = []

    for jk, jv in rdict.items():

        if jv[1] in lookin:
        
            print("\nmaking figures for records : ", jk)

            for ir, rec in enumerate(jv[0]):
                
                print("--> ", rec)
                # print(len(jv[0]))

                try:
                    sid = rec.replace("_","-")
                    rridiff = np.fromfile(os.path.join(cardio_dir, "{}_{}.cardio".format("hrridiff",sid)),dtype='float64')
                    rsastd = np.fromfile(os.path.join(cardio_dir, "{}_{}.cardio".format("hrsastderr",sid)),dtype='float64')

                    rdi = np.sqrt(np.power(rridiff.max(),2)+np.power(rridiff.min(),2))
                
                    if ir ==0:
                        rd.append(rdi)
                    else:
                        rds.append(rdi)
                except:
                    print('passed')
                    pass

    # expl_var = 0
    # unexpl_var = 0
    # y_ = np.array([rd, rds]).mean()
    # rd = np.array(rd)
    # rds = np.array(rds)
    # groups = [rd, rds]
    # N = rd.size + rds.size
    # for i in range(2):
    #     g = groups[i]
    #     n = g.size
    #     y_i = g.mean()
    #     expl_var += n*np.power(y_i - y_,2)
    #     for j in range(g.size):
    #         yij = g[j]
    #         unexpl_var += np.power(yij - y_i,2) / (N-2)

    # print("F=",expl_var / unexpl_var)

    # from scipy.stats import f_oneway, shapiro

    # fstat, pval = f_oneway(rd, rds)
    # print("F=",fstat," pval=",pval)
    # W, pwval = shapiro(rd)
    # print("W=",W,"pval=",pwval)
    # W, pwval = shapiro(rds)
    # print("W1=",W,"pval1=",pwval)
    
    plt.figure()
    plt.suptitle("RSA")
    plt.boxplot([rd, rds])
    plt.xticks([1, 2], ["control","sepsis"])
    plt.ylabel("sec")
    plt.savefig("/home/rocapp/public_html/figs/0__rsabox.png")
    plt.close()
