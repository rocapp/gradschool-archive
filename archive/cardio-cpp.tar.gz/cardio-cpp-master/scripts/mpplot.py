#!/usr/local/bin/python3.6
from multiprocessing import Process, Pipe
import numpy as np

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import gobject

import sys, os, time

import subprocess

sample_rate = 240 # sampling rate of data
NR_WINS = 20 # Number of windows for median filtering
sid = 'S8npcr-06-20-11-Erica' # subject ID

cardio_dir = os.path.expanduser("~/Documents/cardio-output") # where to look for .cardio files
os.chdir(cardio_dir)

fig_dir = os.path.expanduser("~/public_html/sepsis_data/figs") # where figures are sent
def save_path(fn): return os.path.join(fig_dir, fn)

def loadf(sid, signame, dtype='float64'):
    return np.fromfile(os.path.join(cardio_dir, "{}_{}.cardio".format(signame,sid)),dtype=dtype)

def loadq(sid): pass
def loadstates(sid):
    states = np.loadtxt(os.path.join(cardio_dir, "States_{}.txt".format(sid)),
                        skiprows=2, delimiter=",",
                        dtype={'names': ('index', 'time', 'signal', 'amp', 'err'),
                               'formats': ('i4', 'i4', 'U10', 'f4', 'f4')})
    return states

def byindex(states, name):
    return np.array([states[states['index']==i][name]\
                     for i in sorted(list(set(states['index'])))])

def normalize(sig):
    return (sig - sig.min())/(sig.max()-sig.min())

class ProcessPlotter(object):
    def __init__(self, name=''):
        self.x = {}
        self.y = {}
        self.e = {}
        self.c = []
        self.name = name
        self.first = True
        self.fig, self.ax = plt.subplots()
        self.fig.suptitle(name, fontsize=12)
        self.timer = self.fig.canvas.new_timer(interval=1000)

    def terminate(self):
        self.fig.savefig(save_path("{}/_{}_State.svg".format(sid,sid,)))
        printf('saved.')
        plt.close('all')

    def call_back(self):
        while self.pipe.poll():
            print('call back')
            command = self.pipe.recv()

            if command is None:
                self.terminate()
                return False

            else:
                
                # snames, times, amps, errs, covs
                if self.first:
                    
                    for ii, k in enumerate(command[0]):
                        self.x.update({k : [command[1]]})
                        self.y.update({k : [command[2]]})
                        self.e.update({k : [command[3]]})
                    self.first = False
                    
                else:
                    
                    for j, k in enumerate(command[0]):
                        self.x[k].append(command[1])
                        self.y[k].append(command[2])
                        self.e[k].append(command[3])
                        
                self.c.append(command[4])
                
                for k in command[0]:
                    self.ax.scatter(self.x[k], self.y[k],
                                    c=np.array(self.c).reshape(-1,4),
                                    marker='o',label='covariance')
                    self.ax.errorbar(self.x[k], self.y[k],
                                     yerr=self.e[k],
                                     ecolor='c', ls='',
                                     marker='', rasterized=True)
                    # self.fig.canvas.draw()
        return True

    def __call__(self, pipe):
        print('starting {}...'.format(self.name))
        self.pipe = pipe
        self.timer.add_callback(self.call_back)
        self.timer.start()
        print('...done')
        return self.call_back()


class StatePlot(object):
    def __init__(self, name='data-state-sid'):
        self.plot_pipe, plotter_pipe = Pipe()
        self.plotter = ProcessPlotter(name=name)
        self.plot_process = Process(target=self.plotter,
                                    args=(plotter_pipe,))
        self.plot_process.daemon = True
        self.plot_process.start()
        
    def plot(self, data=[], finished=False):
        send = self.plot_pipe.send
        if finished:
            print('finished.')
            send(None)
        else:
            send(data)

if __name__=='__main__':
    if len(sys.argv) < 2: raise Exception('Enter an SID to plot.')
    sid = sys.argv[1]
    print("loading subject: ", sid)
    
    t = loadf(sid, "time")
    sample_rate = 1.0 / (t[1] - t[0])
    print("sample_rate = ", sample_rate)

    states = loadstates(sid)
    # print(set(states['index']))
    snames = byindex(states, 'signal')[0]
    times = byindex(states, 'time')
    amps = byindex(states, 'amp')
    errs = byindex(states, 'err')
    # covs = normalize(np.array([np.cov(amp) for amp in amps]))
    # covs = np.array([np.corrcoef(amp) for amp in amps])
    # covs = np.corrcoef(amps.T)
    covs = np.correlate(amps[:,0], amps[:,1], mode='same')
    covs += np.correlate(amps[:,1], amps[:,2], mode='same')
    covs += np.correlate(amps[:,0], amps[:,2], mode='same')
    covs = normalize(covs)
    print(covs)
    times_ticks = [(int(np.median(tt))) for tt in times]

    fig, ax = plt.subplots(frameon=False)
    fig.suptitle("{} states".format(sid), fontsize=12)
    
    index = np.arange(len(errs))
    bar_width = 0.5

    error_config={'ecolor': '0.3'}

    colors = ['r', 'g', 'b', 'c', 'm', 'k']
    colors = np.array(colors)

    bars = []
    namps = []
    for ii, sn in enumerate(snames):
        amp = normalize(amps[:,ii])
        bot = [0,]*len(errs) if ii==0 else\
              np.array(namps).sum(0)
        namps.append(amp)
        # print(bot)
        bars.append(
            ax.bar(index, amp, bar_width,
                   bottom=bot,
                   color=colors[ii],
                   yerr=amp*errs[:,ii],
                   error_kw=error_config,
                   label=sn)
        )
    ax.fill_between(index, covs, facecolor=(0.3, 0.3, 0.3, 0.5), linestyle='--',
                    label='correlation')
    ax.set_xlabel('time')
    ax.set_ylabel('deviation')
    # xticks = index[::3]
    ax.set_xticks(index)
    print(times)
    times_ticks = [str(tt) for tt in times_ticks]
    ax.set_xticklabels(times_ticks,
                       fontsize=9,
                       rotation=65)
    ax.legend(bbox_to_anchor=(1.04, 1), borderaxespad=0)

    # fig.tight_layout()
    
    fig.savefig(save_path("{}/_{}_State.svg".format(sid,sid,)),
                bbox_inches='tight')
    print('saved.')
    plt.close('all')
