#!/usr/local/bin/python3.6
import wfdb
import os, sys
import json
import numpy as np
import datetime
import h5py # h5py 2.8.0 (from pip3)

## load_data.py : Loads cardiophys data into hdf5

# Usage :
#    $ ./load_data.py (args)[ name_of_dataset | file_mode | subject_to_load ]
# [args] :
# name_of_dataset : (e.g. sepsis)
# file_mode : w / a (either write or append)
# subject_to_load : name of subject (e.g. S8-CR-1-2-3-Erica)

# choose which database to load from
dbc = "sepsis"
if len(sys.argv) > 1: dbc = sys.argv[1]

print("Loading {} database...\n".format(dbc))

if dbc == "mghdb":
    db_path = os.path.expanduser("~/Public/mghdb")
elif dbc == "sepsis":
    db_path = os.path.expanduser("~/Public/SepsisData") # path to wfdb files
elif dbc == "erica":
    db_path = os.path.expanduser("~/Public/EricaData") # path to slow breathing data from Erica
elif dbc=="fantasia":
    db_path = os.path.expanduser("~/Public/fantasia")

make_path = os.environ["CARDIO_SRC"]
os.chdir(make_path)

recs = os.listdir(db_path)
if dbc in ["mghdb","sepsis"]:
    recs = [os.path.splitext(r)[0] for r in recs]
    recs = list(set(recs))
    recs = [r for r in recs if r.count("_") == 1]
elif dbc == "erica":
    recs = [r for r in recs if '.txt' in r]
    recs = [os.path.splitext(r)[0] for r in recs]
elif dbc == "fantasia":
    recs = [r for r in recs if '.ecg' in r]
    recs = [os.path.splitext(r)[0] for r in recs]
recs = list(set(recs))
recs = sorted(recs)

# print("\nAll records found:")
# for rec in recs:
#     print("...", rec)
# print("\n")

try:
    os.mkdir("data")
except FileExistsError:
    pass

# Subjects to load, channels to load
if dbc == "mghdb":
    want_keys = ["mgh152"]
    channel_names = ["Resp. Imp.","ECG lead II"] # CO2 CO2 off
elif dbc == "sepsis":
    # "A084-0380661247", "A006-0360249162", A012-0447461450_0007
    want_keys = ["A012-0447461450","A006-0360249162",
                 "A084-0380661247","A100-0360205025",
                 "A027-0367964357", "A056-0443898863",
                 "A065-0408757787"]
    channel_names = ["CO2", "II", "SPO2", "CVP3", "CVP2"]
elif dbc == "erica":
    want_keys = recs
    channel_names = ["CO2", "II", "BP"]
elif dbc == "fantasia":
    want_keys = recs
    channel_names = ["RESP", "ECG", "BP"]

if len(sys.argv) > 3: want_keys = [sys.argv[3]]
print(want_keys)

print("\n",channel_names,"\n")

# remove keys that are not wanted, use only wanted keys for (t_sep)
if dbc=="sepsis":
    t_sep = np.loadtxt("t_sepsis.csv", delimiter=",", dtype=str) # csv has t0 datetimes
    t_sep = dict(t_sep)
    tkeys = list(t_sep.keys())
    for tk in tkeys:
        if tk not in want_keys:
            t_sep.pop(tk)
elif dbc in ["mghdb", "erica","fantasia"]:
    t_sep = {}
    for wk in want_keys:
        t_sep[wk] = 0

data_fn = "sepsis_data.hdf5" if dbc in ["sepsis","mghdb"] else "erica_data.hdf5"
if dbc == "fantasia": data_fn = "fantasia_data.hdf5"

data_fn = os.path.join(os.environ["CARDIO_DATA"], data_fn)

fmode = "w" # set the file mode (either w or a)
if len(sys.argv) > 2: fmode = sys.argv[2]
hf = h5py.File("{}".format(data_fn), fmode) # hdf5 file, contains all output data

if dbc=="sepsis":
    fs = 240 # sampling frequency
elif dbc=="mghdb":
    fs = 360
elif dbc=="erica":
    fs = 100
elif dbc=="fantasia":
    fs = 250
    
filtd = { # Data filter parameters
    #        sADmx, sMADi, 
    "sepsis": [0.9, 100.0, 2, 0.9, 10],
    "mghdb": [1.0, 100.0, 2, 0.9, 80],
    "erica": [1.0, 1000.0, 15, 1.0, 5],
    }

channel_names0 = list(channel_names)
for kr, tr in t_sep.items():

    if not False: #any(kr in reck for reck in hf.keys()):
        
        print("\n\n-->", kr)

        if dbc=="sepsis":
            dt_0 = datetime.datetime.strptime(tr, "%Y-%m-%d %H:%M:%S") # sepsis t0
            grecs = [r for r in recs if kr in r] # recs that have the SID in it
            tdiff = {}
        elif dbc in ["mghdb", "erica","fantasia"]:
            grecs = [kr,]
        for rec in grecs:
            print("\n  --> loading rec...",rec)
            if dbc in ["mghdb", "sepsis", "fantasia"]:
                channel_names = channel_names0
                print(channel_names)
                sigs, fields = wfdb.io.rdsamp(os.path.join(db_path, rec),
                                              channel_names=channel_names,
                                              warn_empty=True)
                channel_names = fields["sig_name"]
                if dbc == 'fantasia':
                    record = wfdb.io.rdrecord(os.path.join(db_path, rec),
                                              physical=True,
                                              channel_names=channel_names,
                                              warn_empty=True)
                    sigs, fields = record.p_signal, record.get_write_fields()[1]
                print(sigs.shape, fields)
                if rec == "A012-0447461450_0007":
                    sigs = sigs[int(10500*fs):,:]
                elif "A006-0360249162" in rec:
                    sigs = sigs[2500*fs:,:]
            elif dbc == "erica": # Load non-wfdb data (Erica dataset)
                sigs = np.loadtxt(os.path.join(db_path, rec+".txt"),dtype='float64')
                if sigs.shape[1] > sigs.shape[0]: sigs = sigs.T
                sigs = sigs[150*100:sigs.shape[0]-150*100,:]
                # data in order of channel_names
            # elif dbc == "fantasia":
                # if sigs.shape[1] > 2: sigs[:,2] = sigs[:,2]*fields["Gain"]
            if dbc in ["erica", "sepsis", "fantasia"]:
                notnan = []
                check_chans = [0,]
                if dbc=='sepsis' and any([ccc for ccc in ["CVP3", "CVP2"] if ccc in channel_names]):
                    # sepsis_nemati : convert using adu/mmHg reported in wfdb files
                    sigs[:,-1] = sigs[:,-1] / 5.0 # Central Venous Pressure (3-8mmHg is normal)
                if dbc=="sepsis" and sigs.shape[1] > 3: check_chans.extend([1,3])
                elif dbc=="erica" and sigs.shape[1] > 2 and sigs[:,2].max()!=1.0: check_chans.append(2)
                elif dbc=="fantasia" and sigs.shape[1] > 2: check_chans.append(2)
                # print(sigs.shape)
                for i in check_chans: # indices corresponding to channel_names
                    print("\n",channel_names[i])
                    sig = sigs[:,i]
                    print("  preclean:", sig.size)
                    nni = np.where(np.isnan(sig)==0)[0].tolist()
                    sign = sig[nni]
                    if sign.size == 0:
                        print("  **skipped ", channel_names[i])
                        continue
                    print("  notisnan init=", sign.size)
                    dsign = np.diff(sign) # finite difference
                    medi = np.median(dsign) # median of diff
                    mads = np.abs(dsign - medi)
                    madss = np.abs(sign[:dsign.size] - np.median(sign))
                    mads[np.isnan(mads)] = mads.max()
                    madi = np.median(mads)
                    madis = np.median(madss)
                    mstd = np.std(sig)
                    print("pre processing")
                    print("  max=",sign.max(),"; mean=",sign.mean()," ; min=",sign.min())
                    print("  median diff=",madi, "; max diff=",mads.max(),
                          "; std=",mstd,"; nr=",sig.size)
                    goodixs = list()
                    if dbc in ["fantasia","erica"]:
                        if i == 2: # BP
                            goodixs = np.where( (sign > 30) & (sign < 230) )[0].tolist()
                        else:
                            goodixs = np.where( (mads <= 20*madi+mstd) &\
                                                (madss <= 50*madis+mstd) )[0].tolist()
                    elif dbc=="sepsis":
                        goodixs = np.where( (mads < 5*(madi+mstd)) &\
                                            (madss <= 5*madis+mstd) )[0].tolist()
                    goodixs = list(set(goodixs))
                    if i==0:
                        notnan.extend(goodixs)
                        notnan = list(set(notnan))
                    else:
                        nmask = np.flatnonzero(np.in1d(notnan, goodixs, assume_unique=True))
                        ntemp = [notnan[nm] for nm in nmask]
                        notnan = ntemp
                    print("  nr_notnan=",len(notnan))
                    sigs[np.isnan(sigs[:,i]),i] = np.median(sign)
                    sig = sigs[:,i]
                    print("after processing")
                    print("  std=",sig[goodixs].std(),"; nrgood=",len(goodixs))
                    print("  max=",sig[goodixs].max(),"; mean=",sig[goodixs].mean())
                sigs = sigs[notnan,:]
            # Create dataset:
            try:
                sigd = hf.create_dataset("{}".format(rec), data=sigs, dtype="float64")
            except RuntimeError:
                del hf[rec]
                sigd = hf.create_dataset("{}".format(rec), data=sigs, dtype="float64")
            print(sigs.shape)
            for i in range(len(channel_names)): # e.g. sig -> attrs -> "co2" -> 0
                channel_key = channel_names[i]
                if "II" in channel_key or 'ecg' in channel_key.lower():
                    channel_key = "II"
                elif "CO2" in channel_key or "resp" in channel_key.lower():
                    channel_key = "CO2"
                sigd.attrs[channel_key] = i
                print("    attr:", channel_key, i)
            if dbc=="sepsis":
                try:
                    dt_t = datetime.datetime.combine(fields['base_date'],fields['base_time']) # datetime of recording start
                    if dt_0 >= dt_t:
                        toff = dt_0 - dt_t
                        tsec = toff.total_seconds()
                        tdiff.update({rec : tsec})
                        tsort = sorted(tdiff.items(), key=lambda x: x[1])
                        try:
                            sigd = hf[tsort[0][0]]
                            tsec = tsort[0][1]
                            sep_ix = int(tsec*fs)
                            print(" rec: {} :: sec = {:f} ; sep_ix = {:d}\n".format(tsort[0][0],tsec,sep_ix)) 
                            sigd.attrs['t0'] = sep_ix # store sepsis t0
                        except IndexError:
                            pass
                except KeyError:
                    print("  no sepsis t0")
                    pass

hf.close()
