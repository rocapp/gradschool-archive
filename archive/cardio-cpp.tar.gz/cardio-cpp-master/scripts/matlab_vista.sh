#!/bin/bash
matlab -r "cd /home/rocapp/Git/cardio-cpp/scripts; vista_script"
