import subprocess
import json
import os
import numpy as np

make_path = "/home/rocapp/Git/cardio-cpp/"
os.chdir(make_path)

def updateRecords(newdict):
    with open("records_check.json", "w") as f:
        json.dump(newdict, f)
    print("Records json updated.\n")

if __name__ == "__main__":

    with open("records_check.json", "r") as f:
        rdict = json.load(f)
        
    for jk, jv in rdict.items():

        if jv[1] in [None,]:
        
            print("\nchecking records : ", jk)

            buse = 0
            for rec in jv[0]:
                print("--> ", rec)
                try:
                    cmd = "TESTS=test_hdf5 H5=1 SID={} CONFIG=./config/config_000.ini make runtest".format(rec)
                    pcomp = subprocess.run(cmd, shell=True, check=True)
                    if pcomp.returncode == 0:
                        setuse = input("\n  Is this record useful (y/[N])? ")
                        if setuse == "y": buse += 1
                except subprocess.CalledProcessError as Ex:
                    print("\n",rec," failed...\n")

            if buse > 1:
                rdict[jk][1] = True
            elif buse in [0, 1]:
                rdict[jk][1] = False
            
            updateRecords(rdict)
        
    
