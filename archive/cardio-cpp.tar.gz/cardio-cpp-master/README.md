# cardio-cpp
### A signal processing & dynamical systems modeling library, specialized for analyzing ECG and respiratory signals. Written in C++.

## Installation
First, install all the dependencies listed below.

Then, set the following environment variables:

    CARDIO_SRC (default: ~/Git/cardio-cpp/) Full path of the source directory
    CARDIO_OUT (default: ~/Documents/cardio-output/) Full path of the output directory
    CARDIO_DATA (default: ~/Git/cardio-cpp/data/) Full path of the input data directory (hdf5 data files)
    CARDIO_FIG (default: ~/public_html/sepsis_data/figs/) Path to the figures directory

### Build
To build the model executable: `cd $CARDIO_SRC && make`

To build the data processing executable: `cd $CARDIO_SRC && TESTS=test_hdf5 make`

To build any other test in $CARDIO_SRC/tests/: `cd $CARDIO_SRC && TESTS=test_to_build make`, where 'test_to_build' is the filename of the test you want to build without the .cpp extension.

## Usage

### Running stuff:
- To run the model:
    - `$ $CARDIO_SRC/test_model -f path/to/session_config.ini`
- To run the virtual hospital simulation test (`vhosp`):
    - `$ $CARDIO_SRC/tests/test_vhosp`

### Plotting stuff:
- To parse, plot `vhosp` results:
    - Parse `vhosp` logs:
        - `$ $CARDIO_SRC/scripts/parse_vhosp.py $CARDIO_SRC/virtual_hosp_logs/logvh_....cardio`
    - Plot `vhosp` weights:
        - `$ $CARDIO_SRC/scripts/plot_vhosp_weights.py $CARDIO_SRC/virtual_hosp_logs/Wvhosp_...cardio`

### Configuration
See the configuration files in `$CARDIO_SRC/config/` for example configurations.

## Features
- Peak finding
- ECG, BP, respiration signal processing
- Statistical analysis
- Generate simulations of ECG, BP, respiration using the builtin closed-loop dynamical systems model
- Import PhysioNet (WFDB), HDF5 data

# Dependencies
### Developed on Ubuntu LTS 18.04
- Python 3.6+ (likely to work with versions >=3.x.x)
- libhdf5-dev (use the Ubuntu package if possible) ( preferred: 1.10.0-patch1+docs-4 or 1.10.4+repack-10 )
- hdf5-tools (use the Ubuntu package if possible)
- C++17
- g++ 7.3.0

# Quickstart:
- The default output directory: `/home/$USER/Documents/cardio-output/ `(will be created if it doesn't exist)
- Load data script: `./scripts/load_data.py` (look for a list of subjects to load, modify this to create an hdf5 database)
- Build model: `make clean && make TESTS=test_model` (in the repository root directory)
- Run model: `$CARDIO_SRC/test_model -f path/to/session_config.ini` (by default, configuration files are in `$CARDIO_SRC/config/`)
- Plot script: `./scripts/plot.py (SUBJECT-ID)` (figures are saved in SVG format in the `$CARDIO_FIG` directory)

# Docs
http://robcapps.com/docs/cardio-docs/