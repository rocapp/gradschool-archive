
/*
  Robert Capps August 2019
  Optimization of the closed-loop dynamical systems model
*/

#include "model_output.h"
#include <string>
#include <iomanip>      // std::setprecision
#include <iostream>
#include <vector>
#include "config.h"
#include "opt.hpp"
#include "utils.h"
#include <fstream>
#include <stdlib.h>

std::string utime = std::to_string(std::time(0));
void save_log(std::string output_dir, std::string fn_ext, int logix, std::vector<float> wp);
void save_weights(std::string output_dir, std::string fn_ext, std::vector<float> wp);
void load_weights(std::string dir, std::string fn_ext, std::string ut, std::vector<float>& wp);

double csym, csvol, cpo, ctaup, ctaupp;

const int ntargets = 1;
double targets[ntargets] = {
			    86.0 // BP
};

double cstats[ntargets];
int M = 1000;
int caction = M/2;
double aerr = 0.5; // current absolute error

void save_log(std::string output_dir, std::string fn_ext, int logix, std::vector<float> wp)
{
  fn_ext = replace_underscores(fn_ext);
  std::ofstream mfile;
  std::string ext = "_" + utime + ".cardio";
  std::string fn = output_dir + "logOPT_" + "_" + fn_ext + ext;
  mfile.open(fn, std::ios::out|std::ios::app);
  mfile.seekp( 0, std::ios::end );
  mfile << std::setprecision(3)
	<< "iter " << logix << " || " << " BP=" << cstats[0] << " AERR=" << aerr << " || action: " << caction << std::endl;
  mfile << "csym = " << csym << " " << "csvol = " << csvol << " " << "cpo = " << cpo << " "
	<< "ctaup = " << ctaup << " " << "ctaupp = " << ctaupp << std::endl;
  mfile << std::endl;
  mfile.close();
}

void save_weights(std::string output_dir, std::string fn_ext, std::vector<float> wp)
{
  fn_ext = replace_underscores(fn_ext);
  std::ofstream mfile;
  std::string ext = "_" + utime + ".cardio";
  std::string fn = output_dir + "Wopt_" + fn_ext + ext;
  mfile.open(fn, std::ios::out);
  for(float& wi: wp)
    mfile << std::to_string(wi) << std::endl;
  mfile.close();
  std::cout << "weights saved to: " << fn << std::endl;
}

void load_weights(std::string dir, std::string fn_ext, std::string ut, std::vector<float>& wp)
{
  fn_ext = replace_underscores(fn_ext);
  std::ifstream mfile;
  std::string ext = "_" + ut + ".cardio";
  std::string fn = dir + "Wopt_" + fn_ext + ext;
  std::string line;
  mfile.open(fn, std::ios::in);
  if(mfile.is_open())
    {
      while(getline(mfile,line))
	{
	  wp.push_back(atof(line.c_str()));
	}
    }
}

int main(int argc, char** argv)
{

  setenv("TESTS", "test-model", 0);
  setenv("SID", "test-model-opt", 0);
  
  printf("Optimization routine starting...\n\n");

  std::srand ( unsigned ( std::time(0) ) );
  
  std::function<float(float,float)> gblur = [](float wx, float sig)
    {
      return std::exp(-wx*wx/(2*sig*sig));
    };
  
  std::vector<float> w0;
  w0.assign(M,0);
  std::generate(w0.begin(), w0.end(), RandomNumber);

  std::vector<double> actionsd = linspace(-0.2, 0.2, M);
  std::vector<float> actions = cvertd2f(actionsd);
  
  Optimizer nurse(w0);
  nurse.reward_func = [&nurse,gblur](std::vector<float> actions)
    {
      std::vector<float> creward((int)actions.size(),0);
      float resid = 0.0;
      if(!std::isnan(cstats[0]) && cstats[0] > 0.0)
	{
	  resid = std::abs(cstats[0]-targets[0])/targets[0];
	  creward.at(caction) += std::exp(-resid) - 0.5*sqrt(resid);
	}
      else
	{
	  std::vector<float> creward((int)actions.size(),0);
	  creward.at(caction) = -5.0;
	}
      for(int cr=0; cr < (int)creward.size(); cr++)
	{
	  if(std::abs(cr-caction) < (int)(actions.size()*0.015))
	    creward.at(cr) = creward.at(cr)*gblur(std::abs(cr-caction),(float)(actions.size()*0.015));
	  if(std::isnan(creward.at(cr)))
	    creward.at(cr) = 0.0;
	  if(creward.at(cr) > 1.0)
	    creward.at(cr) = 1.0;
	  if(creward.at(cr) < -1.0)
	    creward.at(cr) = -1.0;
	}
      nurse.N_visits.at(caction) += 1.0;
      return creward;
    };

  Config conf;
  conf = Config(argc, argv);

  SaveData saver(conf.cmap["opath"]); // saver class instance

  int N = conf.model["nvhosp"];
  nurse.sigma = 0.01;
  nurse.gamma = 0.003;
  int iter=0;
  int prev_action = caction;
  int since_new_action = 0;
  while(true)
    {
      int tries=0;
      while(true)
	{
	  if(RandomNumber() > nurse.p()[nurse.max_reward_index()])
	    {
	      caction = (int)(0.5-RandomNumber() * (actions.size()-1)) + caction;
	      if(caction >= (int)actions.size() || caction < 0)
		{
		  caction = nurse.max_reward_index();
		}
	    }
	  else
	    {
	      caction = nurse.max_reward_index();
	    }

	  {
	    static Model m0(conf.cmap["i"], conf.cmap["dpath"], &saver, conf.dparams);
	    m0.setup(conf);
	  
	    parameters params = parameters();
	    parameters *pparams = &params;
	    std::map<std::string, double*> paddr;
	    pset params_set(params, pparams, paddr);

	    // csym, csvol, cpo, ctaup, ctaupp;
	    conf.setParams(params_set, conf.params, 1);
	    if(tries==0)
	      {
		csym = params_set.pparams->sym;
		csvol = params_set.pparams->svol;
		cpo = params_set.pparams->po;
		ctaup = params_set.pparams->taup;
		ctaupp = params_set.pparams->taupp;
	      }
	    // params_set.pparams->sym = csym - actions.at(caction)*csym;
	    // params_set.pparams->svol = csvol - actions.at(caction)*csvol;
	    // params_set.pparams->po = cpo - actions.at(caction)*cpo;
	    params_set.pparams->taup = ctaup - actions.at(caction)*ctaup;
	    // params_set.pparams->taupp = ctaupp - actions.at(caction)*ctaupp;
	  
	    m0.run(params_set.pparams);
	    cstats[0] = m0.dstats.avg_bp;
	  }
	  
	  nurse.train_once_modelfree(nurse.reward_func(actions));
	  
	  int gpm = 0;
	  double resid;
	  for(int ci=0; ci < ntargets; ci++)
	    {
	      if(std::isnan(cstats[ci]) || cstats[ci]<=0.0)
		break;
	      resid = std::abs(cstats[ci]-targets[ci])/targets[ci];
	      if(resid > 0.33 && ci==3)
		break;
	      gpm++;
	    }
	  if((gpm==ntargets&& std::abs(cstats[0]-targets[0])/targets[0] <= aerr) || tries>=5)
	    {
	      if(tries>=5)
		caction = (int)(M/2.0);
	      break;
	    }
	  tries++;
	}

      
      if(caction==prev_action)
	{
	  since_new_action++;
	}
      else {
	since_new_action = 0;
      }
      
      std::cout << "Chosen Action = " << caction << std::endl;

      {	
	static Model m(conf.cmap["i"], conf.cmap["dpath"], &saver, conf.dparams);
	m.setup(conf);
      
	parameters params = parameters();
	parameters *pparams = &params;
	std::map<std::string, double*> paddr;
	pset params_set(params, pparams, paddr);
	conf.setParams(params_set, conf.params, 1);
	
	csym = params_set.pparams->sym;
	csvol = params_set.pparams->svol;
	cpo = params_set.pparams->po;
	ctaup = params_set.pparams->taup;
	ctaupp = params_set.pparams->taupp;
	// params_set.pparams->sym = csym - actions.at(caction)*csym;
	// params_set.pparams->svol = csvol - actions.at(caction)*csvol;
	// params_set.pparams->po = cpo - actions.at(caction)*cpo;
	params_set.pparams->taup = ctaup - actions.at(caction)*ctaup;
	// params_set.pparams->taupp = ctaupp - actions.at(caction)*ctaupp;

	m.run(params_set.pparams);
	cstats[0] = m.dstats.avg_bp;

	csym = params_set.pparams->sym;
	csvol = params_set.pparams->svol;
	cpo = params_set.pparams->po;
	ctaup = params_set.pparams->taup;
	ctaupp = params_set.pparams->taupp;
      }
      
      std::cout << "done running model\n\n" << std::endl;
      
      aerr = std::abs(cstats[0] - targets[0]) / targets[0]; // absolute error     
      std::cout << "iter " << iter << " | " << " BP = " << cstats[0] << std::endl;

      save_log(conf.cmap["opath"], conf.cmap["i"], iter, nurse.p());
      nurse.train_once_modelfree(nurse.reward_func(actions));
      save_weights(conf.cmap["opath"], conf.cmap["i"], nurse.p());

      prev_action = caction;

      bool tflag = true;
      for(int tgi=0; tgi < ntargets; tgi++)
	{
	  if(std::abs(cstats[tgi]-targets[tgi]) > 0.01*targets[tgi])
	    {
	      tflag = false;
	      break;
	    }
	}
      if(iter>=N || tflag)
	{
	  printf("done with optimization.\n");
	  printf("saving to folder : %s...\n", saver.output_folder);
	  // Msave->save("test-model-"+conf.cmap["record"]);
	  break;
	}
      
      iter++;
    }

  save_weights(conf.cmap["opath"], conf.cmap["i"], nurse.p());
  
  return 0;
}
