#include <iostream>
#include "load_data.h"
#include "process_data.h"
#include "config.h"
#include <string>

int main(int argc, char** argv)
{
  
  Config conf(argc, argv);

  PhysioNetDB pdb(conf.cmap["i"],"/home/rocapp/Public/SepsisData");
  
  if (conf.cmap["c"] == "0")
    {
      pdb.load_signals();
    }
  else if (conf.cmap["c"] == "1")
    {
      pdb.load_cardio(conf.cmap["i"]);
    }
  
  pdb.save(conf.cmap["i"]);
  
  return 0;
}
