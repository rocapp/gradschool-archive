#include "model_output.h"
#include <string>
#include <iomanip>      // std::setprecision
#include <iostream>
#include <vector>
#include "config.h"
#include "opt.hpp"
#include "utils.h"
#include <fstream>
#include <stdlib.h>

std::string utime = std::to_string(std::time(0));
void save_log(std::string output_dir, std::string fn_ext, int logix, std::vector<float> wp);
void save_weights(std::string output_dir, std::string fn_ext, std::vector<float> wp);
void load_weights(std::string dir, std::string fn_ext, std::string ut, std::vector<float>& wp);

double crampi, cposti, cearlyi;

const int ntargets = 5;
double targets[ntargets] = {0.75, // RRI
			    6.0, // Resp
			    3.0, // Insp
			    3.5, // Exp
			    100.0 // BP
};

double cstats[ntargets];
int caction = 30;
double aerr = 0.0; // current absolute error

float survived(int ntrials)
{
  // determine if the patient survived the current trial
  float sr = 1.0;
  if(
     cstats[0] <= 0.30 || cstats[0] > 1.6 || // heart rate 35-200bpm
     cstats[1] > 10.0 || cstats[1] < 1.55 // resp rate
     || std::abs(cstats[3]-cstats[2]) > cstats[1]/1.25 // insp, exp should be similar (avoid acidosis/alkalinosis)
     )
    {
      sr = 0.0;
    }
  return sr;
}

void save_log(std::string output_dir, std::string fn_ext, int logix, std::vector<float> wp)
{
  fn_ext = replace_underscores(fn_ext);
  std::ofstream mfile;
  std::string ext = "_" + utime + ".cardio";
  std::string fn = output_dir + "logvh_" + std::string(getenv("VHOSP")) + "_" + fn_ext + ext;
  mfile.open(fn, std::ios::out|std::ios::app);
  if(logix==0)
    mfile << "VHOSP = " << getenv("VHOSP") << std::endl << std::endl;
  mfile.seekp( 0, std::ios::end );
  mfile << std::setprecision(3)
	<< "iter " << logix << " || " << " RRI=" << cstats[0]
	<< " RESP=" << cstats[1] << " INSP=" << cstats[2]
	<< " EXP=" << cstats[3] << " BP=" << cstats[4]
	<< " AERR=" << aerr
	<< " || action: " << caction
    	<< " || survival: " << (int)survived(logix+1)
	<< std::endl;
  mfile << "crampi = " << crampi << " " << "cposti = " << cposti
	<< " " << "cearlyi = " << cearlyi << std::endl;
  mfile << std::endl;
  mfile.close();
}

void save_weights(std::string output_dir, std::string fn_ext, std::vector<float> wp)
{
  fn_ext = replace_underscores(fn_ext);
  std::ofstream mfile;
  std::string ext = "_" + utime + ".cardio";
  std::string fn = output_dir + "Wvhosp_" + fn_ext + ext;
  mfile.open(fn, std::ios::out);
  for(float& wi: wp)
    mfile << std::to_string(wi) << std::endl;
  mfile.close();
  std::cout << "weights saved to: " << fn << std::endl;
}

void load_weights(std::string dir, std::string fn_ext, std::string ut, std::vector<float>& wp)
{
  fn_ext = replace_underscores(fn_ext);
  std::ifstream mfile;
  std::string ext = "_" + ut + ".cardio";
  std::string fn = dir + "Wvhosp_" + fn_ext + ext;
  std::string line;
  mfile.open(fn, std::ios::in);
  if(mfile.is_open())
    {
      while(getline(mfile,line))
	{
	  wp.push_back(atof(line.c_str()));
	}
    }
}

int M = 50; // number of possible actions
std::vector<double> actionsd = linspace(-0.45, 0.45, M);
std::vector<float> actions = cvertd2f(actionsd);
int max_tries = 20; // maximum 'imagined scenarios' during executive processing

int main(int argc, char** argv)
{
  setenv("TESTS", "test-model", 0);
  setenv("VHOSP", "TRAIN", 0);
  setenv("TESTW0", "1563468931", 0); // set initial weights for test run
  std::cout << "VHOSP = " << getenv("VHOSP") << std::endl << std::endl;
  
  printf("Virtual hospital simulation...\n\n");
  printf("VHOSP = %s\n", getenv("VHOSP"));

  // directory that contains the training weights and vhosp logs (in repo)
  std::string weights_dir = std::string(getenv("CARDIO_SRC"))+"/virtual_hosp_logs/";

  // training or testing?
  std::string vhosp_str = std::string(getenv("VHOSP"));
  bool vhtrain = vhosp_str.compare("TRAIN")==0;
  
  std::srand ( unsigned ( std::time(0) ) );
  std::function<float(float,float)> gblur = [](float wx, float sig)
    {
      return std::exp(-wx*wx/(2*sig*sig));
    };
  std::vector<float> w0;
  if(!vhtrain)
    { // initial weights for testing are loaded from the corresponding training epoch
      std::string weights_nr = std::string(getenv("TESTW0"));
      load_weights(weights_dir, "vhosp", weights_nr, w0);
    }
  else
    { // assign initial weights for training
      w0.assign((int)M,0.0);
      std::generate(w0.begin(), w0.end(), RandomNumber);
    }
  std::cout << "Weights size = " << w0.size() << std::endl;
  Optimizer nurse(w0);
  nurse.reward_func = [&nurse,gblur](std::vector<float> actions)
    {
      std::vector<float> creward((int)actions.size(),0);
      float resid = 0.0;
      for(int i=0; i < (int)ntargets; i++)
	{
	  if(!std::isnan(cstats[i]) && cstats[i] > 0.0)
	    {
	      float term = std::abs(cstats[i]-targets[i])/targets[i];
	      if(i==3)
		term *= 2.0; // expiration weighted more heavily
	      resid += term;
	    }
	  else { resid += -1.5; }
	}
      resid = 0.33*(1.33*resid+std::abs(cstats[3]-cstats[2])) / ntargets;
      creward.at(caction) = 0.5*( (survived(1)-1.0) + std::exp(-resid) - M_PI*sqrt(resid) );
      for(int cr=0; cr < (int)creward.size(); cr++)
	{
	  if(std::isnan(creward.at(cr)))
	    creward.at(cr) = -0.5;
	}
      nurse.N_visits.at(caction) += 1.0;
      return creward;
    };

  Config conf;
  if(argc < 2)
    {
      std::string vhconfig = std::string(getenv("CARDIO_SRC")) + "/config/" +
	"test-model-vhosp" + ".ini";
      char* argv1 = (char*)("-f" + vhconfig).c_str();
      conf = Config(argc, &argv1);
    }
  else
    {
      conf = Config(argc, argv);
    }

  SaveData saver(conf.cmap["opath"]); // saver class instance

  int N = conf.model["nvhosp"];
  nurse.sigma = (float)conf.model["sigma"]; //0.05; // learning constant
  nurse.gamma = (float)conf.model["gamma"]; //0.025; // memory constant
  nurse.beta = (float)conf.model["beta"]; //0.5; // decay constant
  int iter=0;
  int prev_action = caction;
  int since_new_action = 0;
  while(true)
    {
      
      /* Do executive processing here...
	 continue to search for 'comfortable' parameter set before choosing an action */
      int tries=0;
      while(true)
	{
	  if( iter < (int)(0.1*N) ||
	      RandomNumber()-0.7 > nurse.p()[nurse.max_reward_index()] )
	    {
	      caction = nurse.random_action_index();
	    }
	  else
	    {
	      caction = nurse.max_reward_index();
	    }
	  
	  static Model m0(conf.cmap["i"], conf.cmap["dpath"], &saver, conf.dparams);
	  m0.setup(conf);
	  
	  parameters params = parameters();
	  parameters *pparams = &params;
	  std::map<std::string, double*> paddr;
	  pset params_set(params, pparams, paddr);
	  conf.setParams(params_set, conf.params, 1);
	  cearlyi = params_set.pparams->d2;
	  crampi = params_set.pparams->d5;
	  cposti = params_set.pparams->d4;
	  params_set.pparams->d4 = cposti - actions.at(caction);
	  cearlyi = params_set.pparams->d2;
	  crampi = params_set.pparams->d5;
	  cposti = params_set.pparams->d4;

	  m0.run(params_set.pparams);

	  cstats[0] = m0.dstats.avg_rri;
	  cstats[1] = m0.dstats.avg_insp + m0.dstats.avg_exp;
	  cstats[2] = m0.dstats.avg_insp;
	  cstats[3] = m0.dstats.avg_exp;
	  cstats[4] = m0.dstats.avg_bp;

	  if(vhtrain||iter < (int)(0.1*N))
	    nurse.train_once_modelfree(nurse.reward_func(actions));
	  
	  int gpm = 0;
	  double resid;
	  for(int ci=0; ci < ntargets; ci++)
	    {
	      if(std::isnan(cstats[ci]) || cstats[ci]<=0.0)
		break;
	      resid = std::abs(cstats[ci]-targets[ci])/targets[ci];
	      if(resid > 0.33 && ci==3)
		break;
	      gpm++;
	    }
	  if(
	     ( gpm==ntargets && std::abs(cstats[3]-targets[3])/targets[3] <= aerr ) ||
	     (tries>=max_tries)
	     )
	    {
	      if(tries>=max_tries)
		caction = nurse.max_reward_index();
	      break;
	    }
	  tries++;
	}
      /* finished executive processing */
      
      if(caction==prev_action)
	{
	  since_new_action++;
	}
      else {
	since_new_action = 0;
      }
      
      std::cout << "Chosen Action = " << caction << std::endl;
      
      static Model m(conf.cmap["i"], conf.cmap["dpath"], &saver, conf.dparams);
      m.setup(conf);
      
      parameters params = parameters();
      parameters *pparams = &params;
      std::map<std::string, double*> paddr;
      pset params_set(params, pparams, paddr);
      conf.setParams(params_set, conf.params, 1);
      cearlyi = params_set.pparams->d2;
      crampi = params_set.pparams->d5;
      cposti = params_set.pparams->d4;
      // params_set.pparams->d2 = cearlyi - 2.1*actions.at(caction);
      // params_set.pparams->d5 = crampi - 2.5*actions.at(caction);
      params_set.pparams->d4 = cposti - actions.at(caction);
      cearlyi = params_set.pparams->d2;
      crampi = params_set.pparams->d5;
      cposti = params_set.pparams->d4;

      m.run(params_set.pparams);

      std::cout << "done running model\n\n" << std::endl;
      
      cstats[0] = m.dstats.avg_rri;
      cstats[1] = m.dstats.avg_insp + m.dstats.avg_exp;
      cstats[2] = m.dstats.avg_insp;
      cstats[3] = m.dstats.avg_exp;
      cstats[4] = m.dstats.avg_bp;

      survived(iter+1); // did the model survive or not?

      aerr = 0.0; // absolute error, as in Gallego 1986
      for(int ai=0; ai < ntargets; ai++)
	aerr += std::abs(cstats[ai] - targets[ai]) / targets[ai];
      
      std::cout << "iter " << iter << " | " << " RRI = " << cstats[0]
		<< " RESP = " << cstats[1] << " INSP = " << cstats[2]
		<< " EXP = " << cstats[3]  << " BP = " << cstats[4] << std::endl;

      save_log(conf.cmap["opath"], conf.cmap["i"], iter, nurse.p());
      save_log(weights_dir, conf.cmap["i"], iter, nurse.p());
      
      if(vhtrain)      
	nurse.train_once_modelfree(nurse.reward_func(actions));
      if(vhtrain) {
	save_weights(conf.cmap["opath"], conf.cmap["i"], nurse.p());
	save_weights(weights_dir, conf.cmap["i"], nurse.p());
      }

      prev_action = caction;

      bool tflag = true;
      for(int tgi=0; tgi < ntargets; tgi++)
	{
	  if(std::abs(cstats[tgi]-targets[tgi]) > 0.1*targets[tgi])
	    {
	      tflag = false;
	      break;
	    }
	}
      if(iter>=N || tflag)
	{
	  printf("done with simulation.\n");
	  printf("saving to folder : %s...\n", saver.output_folder);
	  m.save(conf.cmap["record"]);
	  break;
	}
      
      iter++;
    }

  if(vhtrain) {
    save_weights(conf.cmap["opath"], conf.cmap["i"], nurse.p());
    save_weights(weights_dir, conf.cmap["i"], nurse.p());
  }
  
  return 0;
}
