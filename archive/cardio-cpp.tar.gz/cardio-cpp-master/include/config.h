#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <string.h>
#include <map>
#include <stddef.h>
#include <vector>

#include "parameters.h"

#ifndef CONFIG_H
#define CONFIG_H

void printUsage();

typedef struct paramset {
paramset(struct parameters params,
	 struct parameters *pparams,
	 std::map<std::string, double*> paddr) :
  params(params), paddr(paddr) { this->pparams = &(this->params); }
  struct parameters params;
  struct parameters * pparams;
  std::map<std::string, double*> paddr;
}pset;

//! Data structure to hold data processing parameters.
/*!
  Used by DB and subclasses (see src/process_data)
*/
struct dataParams {
  int co2order = 100; //!<< Window size parameter for median filter of respiratory signal (co2, tidal volume).
  int resporder = 2000; //!<< Window size for rolling median used to calculated phase transitions in the respiratory signal.
  double e0scale=3.0; //!<< Scale multiplier to adjust threshold for expiration detection. */
  double i0scale=1.0; //!<< Scale multiplier to adjust threshold for inspiration detection. */
  double e2i_minratio=0.0; //!<< Minimum ratio of (e0 / i0) to be considered a breath
  double e2i_mindiff=0.0; //!<< Minimum difference (e0 - i0) to be considered a breath
  double hlow=0.3; //!<< Shortest accepted RR-interval (seconds). */
  double hthresh=1.2; //!<< Longest accepted RR-interval (seconds). */
  double hheight = 0.13; //!<< Minimum height for the Ecg trace to be considered an R peak
  double hmaxheight = 100.0; //!<< Maximum height for the Ecg trace to be considered an R peak
  int hn = 1; //!<< Number of data points to check *before* heart beat (R peak) occurred. (function: clean_beats) */
  int hp = 1; //!<< Number of data points to check *after* heart beat (R peak) occurred. (function: clean_beats) */
  int horder = 100; //!<< Window size parameter for detection of heart beats. (function: heart_peaks) */
  int rriorder = 10; //!<< Window size parameter for median filtration of RR intervals (function: */
  double rlow = 0.3; //!<< Shortest accepted total respiration cycle duration */
  double rthresh = 10.0; //!<< Longest accepted total respiration cycle duration
  double ilow = 0.25; //!<< low, thresh for insp dur
  double ithresh = 4.0;
  double ethresh = 10.0;
  double bpminmax[2] = {50, 170}; //!<< Min, Max BP acceptable (outside this range, set to the median BP)
  double bpMinMaxScale[2] = {0.6, 0.6}; //!<< Scaling coeffs for finding BP Mins, Maxs ( e.g. Requirement to be a minimum: Min(BP) <= BPave-BPstd*bpMinMaxScale[0] )
  double taup = 0.4; // time constant for blood pressure decay
  int Qwins = 21; //!<< Number of windows to use for calculating transient RSA (Qrsa).
  int bporder = 20; //!<< Window size for blood pressure median filtration (smoothing).
  int nbp = 30; //!<< Order parameter for calculating baroreflex
  double ttol = 100.0; //!<< Tolerance for temporal proximity of states
  double prewin[2] = {0, 0}; //!<< time window (sec) before experimental condition
  double durwin[2] = {0, 0}; //!<< time window (sec) during experimental condition
  double postwin[2] = {0, 0}; //!<< time window (sec) after experimental condition
  double fs = 240.0; //!<< sampling frequency
};

//! Model parameters class
/*!
  Used by the Model instance to deliver model parameters to the integrator
*/
struct modelParams {
  int N;
  char** keys;
  double* vals;
  const double& operator[](char* k) const
  {
    for(int kj=0; kj < N; kj++)
      {
	if(strcmp(keys[kj],k)==0)
	  return vals[kj];
      }
    return 9999.0;
  }
  modelParams();
  modelParams(std::map<std::string, double> mmap)
  {
    N = (int)mmap.size();
    keys = new char*[N];
    vals = new double[N];
    int ii=0;
    for(auto mit=mmap.begin(); mit != mmap.end(); ++mit)
      {
	keys[ii] = new char[mit->first.length()];
	strcpy(keys[ii],const_cast<char*>(mit->first.c_str()));
	vals[ii] = mit->second;
	ii++;
      }
  }
  ~modelParams()
  {
    // if(keys)
    //   {
    // 	for(int ik=0; ik < N; ik++)
    // 	  delete keys[ik];
    // 	delete [] keys;
    //   }
    keys = nullptr;
    // if(vals)
    //   delete vals;
    vals = nullptr;
  }
};

//! Configuration class
/*!
  Used to configure model and data processing options.
  Configuration files (.ini) are loaded from the path specified in the $CONFIG environment variable.
*/
class Config{
 public:
  Config(int, char**);
  Config(){}
  int pcount = 0 ; //!<< nr free parameters
  int nsamps = 1; //!<< nr samps per proc
  double rcov = 0.25; //!<< fraction of samples for calcCov
  double fs = 240.0; //!<< sampling frequency (loaded from config.ini)
  int nvhosp = 100; //!<< number of iterations for vhosp simulations
  bool cuda = false; //!<< CUDA flag
  
  dataParams dparams; //!<< params for data processing
  std::map<std::string, std::string> cmap; //!<< contains string params
  std::map<std::string, double> params; //!<< initial free params loaded from config.ini
  std::map<std::string, double> model; //!<< model initial setup params from config.ini

  void loadConfig(std::string cfn); //!< Load configuration from $CONFIG/(SUBJECT-ID).ini file
  void getParamsOffset(pset& param_set);
  void setParams(pset& param_set, std::map<std::string, double> pmap, int gflag);
  void setParam(pset& param_set, std::string pname, double pval, int gflag);
  
};

#endif
