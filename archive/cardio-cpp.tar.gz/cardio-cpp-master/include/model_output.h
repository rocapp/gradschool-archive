#include <stdlib.h>
#include "process_data.h"
#include "parameters.h"
#include "utils.h"
#include "config.h"
#include <map>
#include <utility>
#include <thread>
#include <future>

#ifndef MODEL_OUTPUT_H
#define MODEL_OUTPUT_H

using namespace std;

class Model : public DB { // declares model class
 public:
  Model(std::string db, std::string dpath): DB(db, dpath) {}
  Model(double ti, double te, int tlen): DB(ti, te, tlen) {}
  Model(std::string db, std::string dpath, dataParams dparams):
    DB(db, dpath, dparams) {}
  Model(std::string db, std::string dpath, SaveData* ss, dataParams dparams):
    DB(db, dpath, ss, dparams) {}

  ~Model()
  {
    if(debug!=1)
      {
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
      }
  }

  fpos_t pos;
  int fd;
  bool cuda=false; // cuda flag
  int nthreads=1; // number of threads to use
  int nvars = 13; // number of model variables
  double tstep = 0.05; // time step for integrator (determines number of steps per sample)
  modelParams* mparams; // model parameters
  std::map<std::string, double> sranges; // mins, maxs from Dick et al 2014
  NeuralSignal prei, earlyi, auge, posti, rampi;
  std::vector<double> hr_phase; // model raw hr phase
  
  void setup(Config conf);
  void run(struct parameters *params); // integrate system
  void storeResult(double*);
  void save(std::string); // save model output to files
  
 protected:
  void calcHR();
  void calcBP(struct parameters *params);
  void processResult(struct parameters *params);
  
};



#endif
