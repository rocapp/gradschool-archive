#include <queue>
#include <functional>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <cassert>

/* Robert Capps 03-14-2019
   implemented with a lot of guidance from:
   https://stackoverflow.com/a/51400041 */

class ThreadPool
{
private:
  std::queue<std::function<void()>> m_func_q;
  std::mutex m_lock;
  std::condition_variable m_dcond;
  std::atomic<bool> m_accept_func;
  
public:
  ThreadPool();
  ~ThreadPool();
  void push(std::function<void()> func);
  void done();
  void loop_func();
};
