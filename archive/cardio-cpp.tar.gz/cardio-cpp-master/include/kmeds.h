#ifndef KMEDS_H
#define KMEDS_H

//! Class for calculating K-medians
class KMeds {
public:
  int nbands = 0; //!< number of bands
  double magnitude = 0.0; //!< the total magnitude of the band separation (e.g. useful for determining strength of cvc)
  double error = 0.0; //!< the total error across all groups
  std::vector<double> bsizes; //!< magnitude of each band
  std::vector<double> gsizes; //!< number of elements in the group
  std::vector<int> bands; //!< vector of binary (0, 1) that specifies if the current group is a band (e.g. for cvc)
  std::vector<std::vector<double>> groups; //!< vector containing each group.
  std::vector<double> meds; //!< vector of medians as doubles, order corresponds to groups
  std::vector<double> stds; //!< vector of standard deviations, order corresponds to groups, medians
  std::vector<double> signal; //!< signal vector (input)
  int max_k = 10; //!< maximum number of medians to find
  KMeds(std::vector<double> sig, int k) : signal(sig), max_k(k) {}
  void calc(); //!< find K-medians, determine the groups and whether or not each group is a band
};

#endif
