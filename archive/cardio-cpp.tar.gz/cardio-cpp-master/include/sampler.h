#include <string>
#include "process_data.h"
#include "model_output.h"
#include "load_data.h"
#include "config.h"
#include "parameters.h"
#include "fit_model.h"

#ifndef SAMPLER_H
#define SAMPLER_H

typedef struct ParamSpace { // parameter history
  std::vector<pset> pstore; // param history storage
  std::vector<double> L; // likelihoods
  std::vector<double> arates; // acceptance rate history
}paramspace;

typedef struct ParamTemp { // temporary storage for evaluating costs
  char * pbase; // base address for each pparam in subset
  parameters params; // actual params
  parameters * pparams; // pointer to actual params
  double L; // likelihood for the subset
}ptemp;

class Sampler { // declares MCMC-MH sampler class
private:
  Config config;
  Cost cost;
  paramspace pspace;
  std::vector<double> cov; // diagonal entries of covariance matrix
  
  void calc_cov();
  void updateParamSpace(pset cparams, double l, double carate);
  H5DB loadData();
  Model setupModel();
  void genSampSpace(ptemp * sspace, pset px);
  void evalSamples(ptemp * out_ss,
		   ptemp * sub_ss, int nsamps,
		   int tlen, int ti, int te,
		   H5DB data,
		   std::string costname);
  
public:
  Sampler(int argc, char **argv) : config(argc, argv) {}
  void sample(std::string costname, int proc_id, int nproc);
  
};

#endif
