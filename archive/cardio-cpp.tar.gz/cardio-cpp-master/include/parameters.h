#include <vector>
#include "process_data.h"

#ifndef PARAMETERS_H
#define PARAMETERS_H

struct NeuralSignal {
  std::vector<double> sig; // signal
  std::vector<double> actsig; // activation signal
};
typedef struct NeuralSignal NeuralSignal;

struct parameters {
  
parameters() :
  erica_pert(0),
  tauhp(3000), tad(2500), tad_ei(2500),
  eiAd(0.0), rs1(0.0), svol(60.0), soff(0.0),
  hr(3.9e-3), rsa1(0.0), rsa2(0.0),
  po(60), taup(240), taul(240),
  taupp(480),
  baro(0.0),
  sym(0.0),
  db(0.0),
  sb(0.0),
  d1(0.02),
  d2(0.24),
  d3(0.145),
  d4(0.13),
  d5(0.2) {}

  double erica_pert; // flag : is this an erica-dataset simulation?
  
  double tauhp; // pre-i/i nap inactivation time constant
  double tad; // activation time constant
  double tad_ei; // early-i time constant
  
  double eiAd; // slow variable for early-i
  double rs1; // noise to early-i
  
  double hr;
  double rsa1;
  double rsa2;

  double soff;
  double svol; // stroke volume
  double po;
  double taup;
  double taul;
  double taupp;
  
  double baro; // respiratory baroreflex
  double sym;
  double db; // cardiac baroreflex
  double sb;

  // drives
  double d1;
  double d2;
  double d3;
  double d4;
  double d5;

};

const double st2 = 0.; // stimulus to early-I
const double st4 = 0.; // stimulus to post-I

const double v12mp = -40.; // pre-i/i persistent sodium vinf
const double kmp = -6.; // pre-i/i persistent sodium decay constant
const double EL = -60.; // leak reversal potential
const double C = 20.; // membrane capacitance
const double gL = 2.8; // leak conductance
const double v12hp = -55.; // pre-i/i nap inactivation vinf
const double khp = 10.; // pre-i/i nap inactivation decay constant
const double gNaP = 5.; // pre-i/i persistent sodium conductance
const double ENa = 50.; // pre-i/i sodium reversal potential
const double EK=-85.;
const double Ee=0.;
const double Ei=-75.;
const double v12n=-30.;
const double kn=-4.;
const double gKdr=5.;
const double gAD=10.;

const double tauhp = 3000; // pre-i/i nap inactivation time constant
const double tad = 2500.; // activation time constant
const double tad_ei = 2500.; // early-i time constant

const double gE=10.;
const double gI=60.;

    
const double hb = 0.2;
const double hb2 = 0.;

// connectivity
const double a12 = .5;
const double b32 = .05;
const double b42 = .42;

const double b23 = .42;
const double b43 = .2;

const double b24 = .22;
const double b34 = .0;

const double a15 = .5;
const double b25 = .3;
const double b35 = .7;
const double b45 = .7;

const double b41 = .1;
const double b31 = 0.;


void integrate (double t0, // initial time
		int ln, // length of solution array (timescale * te)
		double *uu, // solution array
		double h, // integration time step
		struct parameters *p, // parameters
		struct dataParams dparams,
		struct modelParams mparams, // model config params
		double* y
		);

#endif
