#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

// aEIF Purkinje cell model: (Buchin 2016); (Touboul 2008)
// with a time-varying semi-stochastic injected current

struct Params {
  double C; // Capacitance, pF
  double E_L; // Leak reversal potential, mV
  double V_T; // Threshold potential, mV
  double Delta_T; // Spike slope factor, mV
  double V_r; // Membrane potential reset (after spike), mV
  double g_L; // Leak conductance, nS
  double a; // Level of subthreshold adaptation, nS
  double b; // Adaptation current reset (after spike), pA
  double tau_m; // Membrane voltage time constant, ms
  double tau_w; // Adaptation time constant, ms
  double I_mean; // Constant mean injected current
  double I_noise; // Noisy injected current
  double I_syn; // Synaptic input current
  double V_spike; // Conditional threshold for spike generation
  double v; // Membrane voltage, mV
  double w; // Adaptation current, pA
};

struct Currents {
  double *I_noise;
  double *I_syn;
};

void create_syn(double *I_syn, int numbers[], int M, int N){
  for (int i=0; i < N; i++){ I_syn[i] = 1;
    for (int j=0; j < M; j++){ if (i % numbers[j] == 0) { I_syn[i] = 0; break; } } 
  }
}

double voltage_func(double y, struct Params *params) {
  double v = y; double w = params->w;
  double I_in = params->I_mean + params->I_noise + params->I_syn;

  double steady_state = -params->g_L*(v-params->E_L);
  double exp_state = params->g_L*params->Delta_T*exp((v-params->V_T)/params->Delta_T);
  double dv = (steady_state + exp_state - w + I_in)/params->C; // Membrane voltage
  return dv;
}

double current_func(double y, struct Params *params) {
  double w = y; double v = params->v;
  
  double dw = (params->a*(v-params->E_L) - w)/params->tau_w; // Adaptation current
  return dw;
}

struct Params set_params(double t0, double t1, int N,
                          double v0, double w0,
                          double I_noise0, double I_syn0){

  struct Params params = {
    268.0, // C
    -51.31, // E_L
    -53.23, // V_T
    0.85, // Delta_T
    -69.23, // V_r
    8.47, // g_L
    37.79, // a
    441.12, // b
    4.4, // tau_m
    20.76, // tau_w
    -150, // I_mean
    I_noise0, // I_noise
    I_syn0, // I_syn
    0.0, // V_spike
    v0, // v
    w0, // w
  };
  return params;
}

void euler_step(int i, double h, double *y, struct Params *params){
  y[0] = params->v + h*voltage_func(params->v, params);
  y[1] = params->w + h*current_func(params->w, params);
}

void run_integrate(double t0, double t1, int N, double Soln[][2],
                   struct Params params,
                   struct Currents currents){

  // printf("v0 = %.2f; w0 = %.2f\n",params.v,params.w);
  FILE *fpv; FILE *fpw;
  fpv = fopen("./v.txt","w");
  fpw = fopen("./w.txt","w");

  int ii = 0; double t = t0; int si=0;
  double h = (double) (t1-t0)/N;

  printf ("%.4f %.4f %.4f %.4f %.4f\n", t, params.v, params.w, params.I_syn, params.I_noise);

  int plot_ = 1;

  while (t < t1) {
    
    params.I_noise = currents.I_noise[ii];
    params.I_syn = currents.I_syn[ii];

    double result[2];
    euler_step(ii, h, result, &params);
    params.v = *(result); params.w = *(result + 1);

    if (params.v > params.V_spike) { // Spike threshold
      printf("Spike! %.4f, %.4f \n",t,params.v);
      params.v = params.V_spike;
      si++;
    }

    Soln[ii][0] = params.v; Soln[ii][1] = params.w;

    printf ("%.4f %.4f %.4f %.4f %.4f\n", t, params.v, params.w, params.I_syn, params.I_noise);
    if (plot_) {
      fprintf (fpv,"%.4f %.4f\n",t,params.v);
      fprintf (fpw,"%.4f %.4f\n",t,params.w);
    }

    if (params.v == params.V_spike) {
      params.v = params.V_r;
      params.w = params.w + params.b;
    }

    t+=h;
    ii++;
  }
printf("\nNumber of spikes: %d\n",si);
free(currents.I_syn);
free(currents.I_noise);
fclose(fpv);
fclose(fpw);
}

void ornstein_uhlenbeck(int N, double *y,
                        double t0, double t1, double y0,
                        double sigma, double tau){
  const gsl_rng_type * T;
  gsl_rng * r;
  gsl_rng_env_setup();
  T = gsl_rng_default;
  r = gsl_rng_alloc (T);
  double h = (double) 0.005*(t1-t0)/N;
  y[0] = y0;
  double xi = 0.0; double f;
  for (int ti = 0; ti < N-1; ti++){
    xi = gsl_ran_gaussian(r, sigma);
    f = -(y[ti]/tau) + sqrt(2.0*pow(sigma,2)/tau)*xi;
    y[ti+1] = y[ti] + h*f;}
}

struct Currents calc_currents(int N, int M, double t0, double t1,
                   double sigma, double tau_c,
                   int numbers[]){
  
  struct Currents currents;
  currents.I_noise = (double*)malloc(sizeof(double) * N);
  currents.I_syn = (double*)malloc(sizeof(double) * N);
  
  ornstein_uhlenbeck(N, currents.I_noise, t0, t1, 0.0, sigma, tau_c);
  
  // printf("M = %d, N = %d\n",M,N);

  create_syn(currents.I_syn, numbers, M, N);

  return currents;
}


int main (int argc, char *argv[])
{

  double t0 = 0.0;
  double t1 = 5000.0; // ms
  double h = 0.1; // Integration step h = 0.1ms
  int N = (int) (t1 / h);
  
  double sigma = 50; //160.0; // noise amplitude
  double tau_c = 2.0; // noise time constant

  int M = 3;
  int numbers[] = {3, 7, 17}; // modulo values for I_syn

  if (argc > 1) { t1 = atof(argv[1]); }
  if (argc > 2) { N = (int) atoi(argv[2]); }
  if (argc > 3) { sigma = atof(argv[3]); }
  
  double Soln[N][2];
  Soln[0][0] = -62.23; // Resting Voltage
  Soln[0][1] = 0.0; // Initial adaptation current
  
  struct Currents currents = calc_currents(N, M, t0, t1, sigma, tau_c, numbers);

  struct Params params = set_params(t0, t1, N,
                                    Soln[0][0], Soln[0][1],
                                    currents.I_noise[0],
                                    currents.I_syn[0]);
  run_integrate(t0, t1, N, Soln, params, currents);

  return 0;
}
