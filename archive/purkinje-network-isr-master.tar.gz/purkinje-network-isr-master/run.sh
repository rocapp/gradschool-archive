#!/usr/bin/env bash
export -p GSL_RNG_SEED=$(date +%s)
make && ./ptest "$@" && ./plot.sh
