﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;
#if UNITY_EDITOR
using UnityEditor;
#endif

public class PredatorBehaviourScript : MonoBehaviour {

	public Agent predator;
	int time = 0;
	int timelim = 10000;

	GameObject preyObject;

	// Use this for initialization
	void Start () {
		Random.InitState(1322); // 12341 321 111
		predator = new Agent("predator", timelim, 10, transform.rotation, transform.position);
		preyObject = GameObject.Find("prey");
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		Debug.DrawRay(transform.position,
                      transform.TransformDirection(Vector3.forward) * 1.0f,
                      Color.blue);
		predator.reward_function(transform, preyObject.transform.position);
		time = Agent.increment_time(time, predator, transform);
		Debug.Log("time=" + time + ", Direction= " + transform.rotation.ToString());
		
		if(time >= this.timelim-1 || predator.exitflag)
		{
			Debug.Break();
			Debug.Log("break");
			// EditorApplication.isPlaying = false;
			// #if UNITY_EDITOR
			// EditorApplication.isPlaying = false;
			// #else
			// Application.Quit(0);
			// #endif
		}

	}
}
