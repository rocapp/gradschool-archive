using System;
using System.Linq;
using UnityEngine;
using Random = UnityEngine.Random;


/// <summary>
/// an class that defines the basic properties of a reinforcement learning agent
/// </summary>
public class Agent
{
    /// <summary>
    /// [i, j, k, w]
    /// quaternion representing the agent's current orientation
    /// </summary>
    public Quaternion move_tensor;

    /// <summary>
    /// contains the [x, y, z] coordinates for the Agent's current position in 3-space
    /// </summary>
    public Vector3 pos_tensor;

    /// <summary>
    /// contains the [dx, dy, dz] velocities that define the Agent's current speed
    /// </summary>
    public Vector3 vel_tensor;

    /// <summary>
    /// contains the reward distribution (orientation, reward)
    /// </summary>
    /// <remarks>
    /// each orientation is a quaternion (4-vector), so the total dimensionality should be:
    /// [ [ [i, j, k, w], ...], [ 0.1, ... ] ]
    /// rt[0].Length = rt[1].Length = nr_reward_bins, rt[0][i].Length = 4
    public class RewardTensor {
        public Quaternion[] Q;
        public float[] V;
        public RewardTensor(int nr_reward_bins, Quaternion initial_orient)
        {
            this.Q = new Quaternion[nr_reward_bins]; // orientations
            this.V = new float[nr_reward_bins]; // reward
            this.Q[0] = initial_orient;
            for(int i=0; i < nr_reward_bins; i++)
            {
                if(i > 0)
                {
                    this.Q[i] = Quaternion.RotateTowards(initial_orient, initial_orient, -(float)(i) / (float)(nr_reward_bins));
                }
                this.V[i] = 0.0f;
            }
        }
    }
    public RewardTensor reward_tensor;

    /// <summary>
    /// name that identifies the agent (e.g. "predator")
    /// </summary>
    public string name;

    public static int time_lim;

    private int nr_reward_bins;

    /// <summary>
    /// constructor for agent
    /// </summary>
    /// <param name="name">name of agent (e.g. predator)</param>
    /// <param name="time_lim">time to end simulation</param>
    /// <param name="nr_reward_bins">the number of bins to use for approximating the reward distribution</param>
    public Agent(string name,
                 int time_lim,
                 int nr_reward_bins,
                 Quaternion initial_orient,
                 Vector3 initial_pos)
    {
        Agent.time_lim = time_lim;
        this.name = name;
        this.move_tensor = initial_orient;
        this.pos_tensor = initial_pos;
        this.reward_tensor = new RewardTensor(nr_reward_bins, initial_orient); // instantiate reward_tensor
        this.nr_reward_bins = nr_reward_bins;
    }

    private bool invflag = false;
    /// <summary>
    /// update the agent position using the `move_tensor` orientation quaternion
    /// </summary>
    /// <remarks>
    /// perform the hamiltonian product Pos' = Pos*Quat
    /// </remarks>
    public void update_position(Transform transform, int time)
    {
        // rotation with orientation quaternion move_tensor
        transform.Rotate(this.move_tensor.eulerAngles);
        // move position using unit velocity (1 unit time increment)
        transform.Translate(0, 0, Time.deltaTime * 10.0f);
        this.pos_tensor = transform.position;
        if((this.reward_tensor.V.Min() <= -1000.0f || this.reward_tensor.V.Max() < 0.0f) &&
            time > nr_reward_bins)
        {
            this.move_tensor = Random.rotation;
            this.reward_tensor = new RewardTensor(this.nr_reward_bins, this.move_tensor);
        }
    }

    public void select_optimal_orientation()
    {
        // int max_ix = Array.IndexOf(reward_tensor.V, reward_tensor.V.Max());
        // this.move_tensor = reward_tensor.Q[max_ix];
        int max_ix = Array.IndexOf(reward_tensor.V, reward_tensor.V.Max());
        int rix = (int)((this.nr_reward_bins-max_ix)*Random.value) + max_ix;
        this.move_tensor = this.reward_tensor.Q[rix];
        this.move_tensor = Quaternion.Lerp(this.move_tensor, this.move_tensor, 0.02f);
    }

    public static int increment_time(int time, Agent agent, Transform transform)
    { // call before or after reward function
        if(time + 1 < time_lim)
        {
            agent.select_optimal_orientation(); // select new movement direction as the maximally rewarding orientation tensor
            if(time % 10==0)
            {
                agent.update_position(transform, time); // update position
            }
            time += 1;
        }
        return time;
    }

    public bool exitflag = false;
    private float dist0 = 0.0f;
    public void reward_function(Transform transform, Vector3 target_position)
    {
        
        float R = -0.1f;

        // + reward if the target is within the predator's field of view (raycast)
        RaycastHit hit;
        bool spotted = Physics.Raycast(transform.position,
                                       transform.TransformDirection(Vector3.forward),
                                       out hit, Mathf.Infinity);
        bool spotted1 = Physics.Raycast(transform.position,
                                       transform.TransformDirection(Vector3.forward) + Vector3.up * 0.35f,
                                       out hit, Mathf.Infinity);
        bool spotted2 = Physics.Raycast(transform.position,
                                       transform.TransformDirection(Vector3.forward) + Vector3.down * 0.35f,
                                       out hit, Mathf.Infinity);
        bool spotted3 = Physics.Raycast(transform.position,
                                       transform.TransformDirection(Vector3.forward) + Vector3.right * 0.35f,
                                       out hit, Mathf.Infinity);
        float dist = Mathf.Abs(Vector3.Distance(transform.position, target_position));
        Debug.Log("*Distance = " + dist);
        if(spotted||spotted1||spotted2||spotted3)
        {
            Debug.Log("!! Spotted !!");
            R = 70.0f;
            Debug.DrawRay(transform.position,
                          transform.TransformDirection(Vector3.forward) * 10.0f + Vector3.right * 0.35f,
                          Color.white);
            Debug.DrawRay(transform.position,
                          transform.TransformDirection(Vector3.forward) * 10.0f + Vector3.down * 0.35f,
                          Color.black);
            Debug.DrawRay(transform.position,
                          transform.TransformDirection(Vector3.forward) * 10.0f + Vector3.up * 0.35f,
                          Color.yellow);
            Debug.DrawRay(transform.position,
                          transform.TransformDirection(Vector3.forward) * 10.0f,
                          Color.red);
            // + reward proportional to the distance from the predator to the target

        }

        if(dist <= 2.5f)
            { // exit if close enough
                Debug.Log(" ----------> ExitFlag (distance below thresh!)");
                exitflag = true;
            }

        R -= ( dist*dist + 10f*(dist - dist0) );
        dist0 = dist;

        // update the reward_tensor distribution (weight the reward by the distance returned from Quaternion.Angle)
        this.reward_tensor.Q[0] = this.move_tensor;
        this.reward_tensor.V[0] += R;
        for(int i=1; i < this.nr_reward_bins; i++)
        {
            if(reward_tensor.V.Max() > 0.0)
            {
                Quaternion bestq = reward_tensor.Q[Array.IndexOf(reward_tensor.V, reward_tensor.V.Max())];
                Quaternion.RotateTowards(reward_tensor.Q[i], bestq, 360f / (float)nr_reward_bins);
            }
            float dista = Quaternion.Angle(this.reward_tensor.Q[i], this.move_tensor);
            this.reward_tensor.V[i] = R * dista / 360.0f;
        }
        Debug.Log("Max Reward: " + reward_tensor.V.Max() + "; Min Reward: " + reward_tensor.V.Min());
    }


}