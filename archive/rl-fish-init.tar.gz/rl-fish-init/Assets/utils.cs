using System;
using System.Linq;

static class Utils 
{
    public static double distance(double[] A, double[] B)
    {   
        double dist = 0;
        for(int i=0; i < A.Length; i++)
            dist += Math.Pow(A[i]-B[i],2);
        dist = Math.Sqrt(dist);
        return dist;
    }

    public static double euclidean(double[] x)
    {
        double L = 0;
        for(int i=0; i < x.Length; i++)
            L += x[i]*x[i];
        L = Math.Sqrt(L);
        return L;
    }

    public static void normalize(double[] x)
    {
        for(int i=0; i < x.Length; i++)
            x[i] = (x.Max() - x[i]) / (x.Max() - x.Min());
    }

}