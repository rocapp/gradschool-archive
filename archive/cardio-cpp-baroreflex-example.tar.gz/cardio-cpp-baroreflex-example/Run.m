function Params = Run(params_fn, titlev)

    try
        Params = load(params_fn); % Load parameters
        Params = Params.ans;
    catch
        % Default parameters from (Ottesen 1997) Pg. 42
        warning('Using default params.');
        Params = containers.Map;
        
        % Uncontrolled model params
        Params('c_a') = 1.55; % arterial compliance (ml/mmHg)
        Params('c_v') = 519; % venous compliance (ml/mmHg)
        Params('R') = 1.05; % peripheral resistance (mmHg sec / ml)
        Params('Rf') = 0.84;
        Params('r') = 0.068; % venous outflow resistance (mmHg sec / ml)
        Params('V_str') = 67.9; % stroke volume (ml)
        Params('V_strf') = 77.9;
        
        Params('Pa0') = 80; % Typical mean arterial pressure (mmHg)
        Params('Pv0') = 7; % Typical mean venous pressure (mmHg)
        Params('H0') = 1.2; % typical mean heart rate (sec^-1)
        
        % Feedback model params
        Params('Alpha') = 93; % Alpha_s = Alpha_p = Alpha_0 (mmHg)
        Params('Alphaf') = 121;
        Params('Beta') = 7; % Beta_s = Beta_p = Beta_0
        
        Params('Alpha_H') = 0.84; % (sec^-2) sympathetic tone
        Params('Beta_H') = 1.17; % (sec^-2) parasympathetic tone
        Params('Gamma_H') = 0.; % damping from parasympathetic system (mediates symp. effects on HR)
        
        % Times
        Params('tau') = 1.4; % delay time (sec)
        Params('t0') = 300; % initial time (sec)
        Params('tf') = 340; % final time (sec)
        warning('saving default params in "params.mat"');
        save 'params.mat' Params;
    end

    % Integrate the DDE
    tspan = linspace(Params('t0'), Params('tf'));
    historyv = [Params('Pa0'), Params('Pv0'), Params('H0')]'; % history vector
    opts = ddeset('RelTol',1e-6,'AbsTol',1e-12);
    soln = dde23(@ODEs, Params('tau'), historyv, tspan, opts, Params);
    Y = deval(tspan, soln);
    
    disp([Params.keys; Params.values])
    
    % Plot
    
    % Figure 6 (Ottesen 1997)
    figure;
    clf;
    
    subplot(3, 1, 1);
    plot(tspan, Y(1,:));
    title('Pa')
    subplot(3,1,2);
    plot(tspan, Y(2,:));
    title('Pv')
    subplot(3,1,3);
    plot(tspan, Y(3,:));
    title('HR')
    try
        suptitle(titlev)
    catch
        suptitle('(upper right) Fig 6 (Ottesen 1997)')
    end
end