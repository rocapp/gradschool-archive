%% Simulation of baroreflex-feedback mechanism with time-delay, based on (Ottensen 1997)

function dy = ODEs(t,y,Z,Params)
    % System of equations
    Pa = y(1);
    Pv = y(2);
    H = y(3);
    
    Ts = Gs(Z(1), Params('Alpha'), Params('Beta'));
    Tp = Gp(Pa, Params('Alpha'), Params('Beta'));
    
    dy = [P_A(Pa, Pv, H, Params('c_a'), Params('R'), Params('V_str'));
          P_V(Pa, Pv, Params('c_v'), Params('R'), Params('r'));
          HR(Ts, Tp, Params('Alpha_H'), Params('Beta_H'), Params('Gamma_H'))];
      
function dPv = P_V(Pa_t, Pv_t, c_v, R, r)
    % Calculate the derivative of the venous pressure
    dPv = (1/(c_v*R))*Pa_t - ( (1/(c_v*R)) + (1/(c_v*r)) )*Pv_t;
    
function dPa = P_A(Pa_t, Pv_t, H, c_a, R, V_str)
    % Calculate the derivative of the arterial pressure
    dPa = -(1/(c_a*R))*(Pa_t - Pv_t) + (V_str/c_a)*H;

    
function dH = HR(Ts, Tp, Alpha_h, Beta_h, Gamma_h)
    % Calculate the derivative of the HR
    dH = (Alpha_h*Ts / (1 + Gamma_h*Tp)) - Beta_h*Tp;
    
function Ts = Gs(P_tau, Alpha_s, Beta_s)
    % Find the sympathetic tone as a function of the mean arterial pressure
    Ts = 1 / (1 + (P_tau / Alpha_s)^Beta_s);

function Tp = Gp(P, Alpha_p, Beta_p)
    % Find the parasympathetic tone as a function of the mean arterial pressure
    Tp = 1 / (1 + (P / Alpha_p)^(-Beta_p));
