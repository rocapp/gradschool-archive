from sympy import *
import sys
from sympy.functions.special.spherical_harmonics import Znm
from sympy.codegen.ast import real, float32
custom_functions={'sin': "Mathf.Sin", 'cos': "Mathf.Cos", "Pow": "Mathf.Pow", "cosf":"Mathf.Cos", "sinf": "Mathf.Sin", 'sqrt':"Mathf.Sqrt", 'sqrtf':"Mathf.Sqrt"}
def Y(j,t,p):
    x=cos(t)*sin(p)
    y=sin(t)*sin(p)
    z=cos(p)
    if j==0:
        return sqrt(1/pi)/2
    if j==1:
        return sqrt(3/(4*pi))*y
    if j==2:
        return sqrt(3/(4*pi))*z
    if j==3:
        return sqrt(3/(4*pi))*x
    if j==4:
        return sqrt(15/(4*pi))*x*y
    if j==5:
        return sqrt(15/(4*pi))*z*y
    if j==6:
        return sqrt(5/(16*pi))*(-x*x-y*y+2*z*z)
    if j==7:
        return sqrt(15/(4*pi))*(z*x)
    if j==8:
        return sqrt(15/(16*pi))*(x*x-y*y)
    return None
for i in range(9):
     for j in range(9):
            theta=Symbol("theta", real=True)
            phi=Symbol("phi",real=True)
            dt=Symbol("x",real=True)
            dp=Symbol("y",real=True)
            Mij=integrate(Y(j,100*theta/99-dt/99,100*phi/99-dp/99)*Y(i,(theta),(phi)),(theta, 0,2*pi),(phi,0,2*pi))
            print("M[%i][%i]=%s;"%(i,j,ccode(Mij, type_aliases={real:float32}, user_functions=custom_functions).replace("M_PI", "Mathf.PI").replace("F","f")))
            sys.stdout.flush()
