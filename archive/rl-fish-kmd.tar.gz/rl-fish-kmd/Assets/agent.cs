using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using Random = UnityEngine.Random;


/// <summary>
/// an class that defines the basic properties of a reinforcement learning agent
/// </summary>
public class Agent
{
    /// <summary>
    /// [i, j, k, w]
    /// quaternion representing the agent's current orientation
    /// </summary>
    public Quaternion move_tensor;
    public Quaternion move_tensor_0;

    /// <summary>
    /// contains the [x, y, z] coordinates for the Agent's current position in 3-space
    /// </summary>
    public Vector3 pos_tensor;

    /// <summary>
    /// contains the [dx, dy, dz] velocities that define the Agent's current speed
    /// </summary>
    public Vector3 vel_tensor;

    /// <summary>
    /// class that defines the reward distribution (orientation, reward)
    /// defined in `reward.cs`
    /// </summary>
    /// <remarks>
    /// each orientation is a quaternion (4-vector), so the total dimensionality should be:
    /// [ [ [i, j, k, w], ...], [ 0.1, ... ] ]
    /// rt[0].Length = rt[1].Length = nr_reward_bins, rt[0][i].Length = 4
    static public float[] sh_proj(float[] c, Vector3 x)
    {
        Vector3 y=x.normalized;
	    return new float[]{ 1.0f/Mathf.Sqrt(4*Mathf.PI)*c[0],Mathf.Sqrt(3.0f/(4*Mathf.PI))*(y.y*c[1]),Mathf.Sqrt(3.0f/(4*Mathf.PI))*y.z*c[2],Mathf.Sqrt(3.0f/(4*Mathf.PI))*y.x*c[3],Mathf.Sqrt(15.0f/(4*Mathf.PI))*y.x*y.y*c[4],Mathf.Sqrt(15.0f/(4*Mathf.PI))*y.z*y.y*c[5],
	    Mathf.Sqrt(15.0f/(4*Mathf.PI))*y.z*y.y*c[5],Mathf.Sqrt(5.0f/(16*Mathf.PI))*(-y.x*y.x-y.y*y.y+2*y.z*y.z)*c[6],Mathf.Sqrt(15.0f/(4*Mathf.PI))*y.z*y.x*c[7],Mathf.Sqrt(15f/(16f*Mathf.PI))*(y.x*y.x-y.y*y.y)*c[8] };
    }
    static public float sh_dot(float[] c, Vector3 x)
    {
        float[] u=sh_proj(c,x);
        float usum=0f;
        for(int i=0; i<9; ++i) usum+=u[i];
        return usum;
    }
    public class RewardTensor {
        public static float[] scaleByMat(float[][] M, float[] x){
            float[] y=new float[9];
            for(int i=0; i<9; ++i){
                y[i]=0f;
                for(int k=0; k<9; ++k){
                    y[i]+=M[i][k]*y[k];
                }
            }
            return y;
        }
    	public float maxR(float[] x, out Vector3 best){
            float dmax=-1000000f;
            best=Vector3.zero;
			Vector3[] dirs={Vector3.up,Vector3.left,Vector3.right,Vector3.down, Vector3.back, Vector3.forward};
			for(int i=0; i<6; ++i){
				float d=sh_dot(x,dirs[i]);
					if(d>dmax){
						dmax=d;
					best=dirs[i];
				}
			}
			for(int i=0; i<100; ++i){
				Vector3 v=Random.onUnitSphere;
				float d=sh_dot(x,v);
				if(d>dmax){
					dmax=d;
					best=v;
				}
			}
		return sh_dot(x,best);
	}
		public float minR(float[] x){
			float d=100000000f;
			Vector3[] dirs={Vector3.up,Vector3.left,Vector3.right,Vector3.down, Vector3.back, Vector3.forward};
			for(int i=0; i<6; ++i){
				d=Mathf.Min(sh_dot(x,dirs[i]),d);
			}
			for(int i=0; i<100; ++i){
				d=Mathf.Min(sh_dot(x,Random.onUnitSphere),d);
			}
			return d;
		}
		public float[][] V;
		int nbins=0;
		float maxd=0.0f;
		Vector3 lastpos=new Vector3(0,1,0);
		public RewardTensor(int n_reward_bins, float max_dist=20f)
		{
		    maxd=max_dist;
		    nbins=n_reward_bins;
		    V=new float[nbins*nbins*nbins*nbins][];
		    for(int i=0; i<nbins*nbins*nbins*nbins; ++i){
                V[i]=new float[9];
		    }
		}
		public void spot(Vector3 p){
			lastpos=p;
		}
		public void degrade(float f, Vector3 p){
            foreach(var v in V){
                v[0]-=0.0001f;
            }
		}
		public int bin(Vector3 q){
			Vector3 p0=Vector3.up*maxd;
			Vector3 p1=Vector3.left*maxd;
			Vector3 p2=Vector3.back*maxd;
			Vector3 p3=lastpos;
			float px=Mathf.Min((q-p0).magnitude,maxd);
			float py=Mathf.Min((q-p1).magnitude,maxd);
			float pz=Mathf.Min((q-p2).magnitude,maxd);
			float pw=Mathf.Min((q-p3).magnitude,maxd);
			int ix=(int)(px*nbins/maxd);
			ix=(int) Mathf.Min(ix,nbins-1);
			int iy=(int)(py*nbins/maxd);
			iy=(int) Mathf.Min(iy,nbins-1);
			int iz=(int)(pz*nbins/maxd);
			iz=(int) Mathf.Min(iz,nbins-1);
			int iw=(int)(pw*nbins/maxd);
			iw=(int) Mathf.Min(iw,nbins-1);
			return ix*nbins*nbins*nbins+iy*nbins*nbins+iz*nbins+iw;
		}
		public void upd(Vector3 d, float R, Vector3 p){
            String s="";
            
            float[] r=new float[]{R,R,R,R,R,R,R,R,R};
            float[] u1=sh_proj(r,d);
            for(int j=1; j<9; ++j){
                V[bin(p)][j]+=u1[j];
            }
            
            for(int j=1; j<9; ++j){
                 s+=V[bin(p)][j]+" ";
            }
            Debug.Log(s);
		}
		public void scale(float[][] M, Vector3 p){
            V[bin(p)]=scaleByMat(M,V[bin(p)]);
        }
		public float max(Vector3 p){
			Vector3 tmp;
			return maxR(V[bin(p)], out tmp);
		}
		public float min(Vector3 p){
			return minR(V[bin(p)]);
	}
	public Vector3 opt(Vector3 d){
		Vector3 best;
		maxR(V[bin(d)],out best);
		return best;
	}
	public void reset(Vector3 p){
		for(int i=0; i<9; ++i) V[bin(p)][i]=0f;
	}
	public float eval(Vector3 p, Vector3 d){
		return sh_dot(V[bin(p)],d);
	}
    }
    public RewardTensor reward_tensor;

    /// <summary>
    /// name that identifies the agent (e.g. "predator")
    /// </summary>
    public string name;

    /// <summary>
    ///   Time limit for simulation
    /// </summary>
    public static int time_lim;

    /// <summary>
    ///   defines the number of bins used for the reward distribution
    /// </summary>
    private int nr_reward_bins;

    /// <summary>
    ///   Distance threshold that determines when the predator is close enough to the prey to end the simulation
    /// </summary>
    public float thresh=3f;
    
    /// <summary>
    /// constructor for agent
    /// </summary>
    /// <param name="name">name of agent (e.g. predator)</param>
    /// <param name="time_lim">time to end simulation</param>
    /// <param name="nr_reward_bins">the number of bins to use for approximating the reward distribution</param>
    public Agent(string name,
                 int time_lim,
                 int nr_reward_bins,
                 Quaternion initial_orient,
                 Vector3 initial_pos)
    {
        Agent.time_lim = time_lim;
        this.name = name;
        this.move_tensor = initial_orient;
        this.pos_tensor = initial_pos;
        this.reward_tensor = new RewardTensor(nr_reward_bins); // instantiate reward_tensor
        this.nr_reward_bins = nr_reward_bins;
    }
    
    Quaternion move_tensor0; // @kmd: what is this?
    
    float tupd=0f; // @kmd: also this?
    
    /// <summary>
    /// update the agent position using the `move_tensor` orientation quaternion
    /// </summary>
    /// <remarks>
    /// perform the hamiltonian product Pos' = Pos*Quat
    /// </remarks>
    public void update_position(Transform transform, int time)
    {
        // rotation with orientation quaternion move_tensor
        transform.rotation=this.move_tensor*this.move_tensor0;
        // move position using unit velocity (1 unit time increment)
	transform.position+=transform.forward*Time.fixedDeltaTime;
        this.pos_tensor = transform.position;
        if((this.reward_tensor.min(transform.position) <= -0.1*dist0 || this.reward_tensor.max(transform.position) < 0.0f) &
            time > Mathf.Pow(nr_reward_bins,4.0f))
        {
            tupd=time;
            this.move_tensor0=transform.rotation;
            if((reward_tensor.max(transform.position)<0 || reward_tensor.min(transform.position)<=-2000000f*dist0/10.0f) && time>100){
                if(Random.value<0.001){
                    this.move_tensor = Random.rotation;
                    this.reward_tensor.reset(transform.position);
                }
            }
        }
    }

    public void select_optimal_orientation(Transform transform,int time)
    {
        tupd=time;
        this.move_tensor0=transform.rotation;
        this.move_tensor = Quaternion.FromToRotation(transform.forward,(this.reward_tensor.opt(transform.position)+Random.onUnitSphere*0.1f).normalized);
    }

    public static int increment_time(int time, Agent agent, Transform transform)
    { // call before or after reward function
        if(time + 1 < time_lim)
        {
        
            if(Random.value<0.5)
            {   
            agent.select_optimal_orientation(transform,time); // select new movement direction as the maximally rewarding orientation tensor
            }
                agent.update_position(transform, time); // update position
            
            
            
            time += 1;
        }
        return time;
    }
    
    Matrix4x4 ScalingMatrix;
    
    public bool exitflag = false;
    private float dist0 = 0.0f;
    public float fov=0.5f; // defines the field of view for spotting
    public int nr_spotted = 0; // number of times the prey was spotted
    private Vector3[,] visrays; // raycasting (positions, directions)
    public void reward_function(Transform transform, Vector3 target_position)
    {
        float dotp=Vector3.Dot(transform.forward,(target_position-transform.position).normalized);
        reward_tensor.degrade(-0.001f,transform.position);
        float R = -0.0f;
	bool spotted=false;
	for(int i=0; i<160; ++i){
        Vector3 d=transform.forward+0.4f*Random.onUnitSphere;
        bool hit=Physics.Raycast(transform.position,d);
		spotted=spotted||hit;
		Color c=(hit)?Color.yellow:Color.black;
		Debug.DrawRay(transform.position, d*300.0f,c);
		
	}
	if(spotted){
		reward_tensor.upd((target_position-transform.position).normalized,70.0f,transform.position);
	}
	
        float dist = Mathf.Abs(Vector3.Distance(transform.position, target_position));
	
        Debug.Log("*Distance = " + dist);
	
        if(dist <= thresh)
            { // exit if close enough
                Debug.Log(" ----------> ExitFlag (distance below thresh!)");
                //reward_tensor.upd(transform.forward,100.0f, transform.position);
                exitflag = true;
            }
        R -= 10f*(dist-dist0)-2.0f*dotp;
        Debug.Log(R+" "+reward_tensor.eval(transform.position,transform.forward));
        dist0 = dist;
        Vector3 D=reward_tensor.opt(transform.position).normalized;
	
        if(D.x==0)
        {
            D.x=0.00001f;
        }
        float x=Mathf.Atan(D.y/D.x);
        float y=Mathf.Asin(D.z);
        float[][] M=Utils.genSHscaling(x,y);
        this.reward_tensor.scale(M,transform.position);
        this.reward_tensor.spot(target_position+Random.onUnitSphere*Random.value*0.1f); // updates estimated distance to target
        this.reward_tensor.upd(transform.forward,R,transform.position);
        Debug.Log("Max Reward: " + reward_tensor.max(transform.position) + "; Min Reward: " + reward_tensor.min(transform.position));
	Debug.Log("# Times Spotted: " + nr_spotted);
    }
    float[][] genSHScaling(float x, float y){
        float[][] M=new float[9][];
        for(int i=0; i<9; ++i){
            M[i]=new float[9];
        }
        M[0][0]=Mathf.PI;
M[0][1]=(9801.0f/40000.0f)*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 9801.0f/40000.0f*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 9801.0f/40000.0f*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (9801.0f/40000.0f)*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI;
M[0][2]=(99.0f/200.0f)*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y) + (99.0f/200.0f)*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI);
M[0][3]=-9801.0f/40000.0f*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (9801.0f/40000.0f)*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 9801.0f/40000.0f*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (9801.0f/40000.0f)*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[0][4]=-99.0f/800.0f*Mathf.Pow(15, 1.0f/2.0f)*(Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 99.0f/200.0f*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)/Mathf.PI + (99.0f/800.0f)*Mathf.Pow(15, 1.0f/2.0f)*(Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 99.0f/200.0f*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI + (9801.0f/160000.0f)*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 9801.0f/160000.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI;
M[0][5]=(9801.0f/80000.0f)*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 9801.0f/80000.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI - 9801.0f/80000.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI + (9801.0f/80000.0f)*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI;
M[0][6]=-1.0f/8.0f*Mathf.Pow(5, 1.0f/2.0f)*(-99.0f/100.0f*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*y) - 99.0f/100.0f*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) - 99.0f/50.0f*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y))/Mathf.PI + (1.0f/8.0f)*Mathf.Pow(5, 1.0f/2.0f)*(-2*Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (99.0f/100.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) - 2*Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 2*Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) + 4*Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (99.0f/100.0f)*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (99.0f/50.0f)*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) - 2*Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + 4*Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI;
M[0][7]=-9801.0f/80000.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2)/Mathf.PI + (9801.0f/80000.0f)*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI - 9801.0f/80000.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (9801.0f/80000.0f)*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI;
M[0][8]=(99.0f/800.0f)*Mathf.Pow(15, 1.0f/2.0f)*(Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 99.0f/200.0f*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (99.0f/800.0f)*Mathf.Pow(15, 1.0f/2.0f)*(Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 99.0f/200.0f*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 9801.0f/160000.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 9801.0f/160000.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[1][0]=0;
M[1][1]=(288178803.0f/158404.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)/Mathf.PI + (288178803.0f/158404.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (288178803.0f/158404.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (288178803.0f/158404.0f)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[1][2]=0;
M[1][3]=(288178803.0f/158404.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 288178803.0f/158404.0f*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (288178803.0f/158404.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 288178803.0f/158404.0f*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[1][4]=-29403.0f/120796.0f*Mathf.Pow(5, 1.0f/2.0f)*(-10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI - 29403.0f/120796.0f*Mathf.Pow(5, 1.0f/2.0f)*(-10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (29403.0f/120796.0f)*Mathf.Pow(5, 1.0f/2.0f)*(-20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (29403.0f/120796.0f)*Mathf.Pow(5, 1.0f/2.0f)*(-20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[1][5]=(288178803.0f/24038404.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (288178803.0f/24038404.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (288178803.0f/24038404.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (288178803.0f/24038404.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[1][6]=(1.0f/8.0f)*Mathf.Pow(15, 1.0f/2.0f)*(-10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2) + (40000.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2) + (20398.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))/Mathf.PI - 1.0f/8.0f*Mathf.Pow(15, 1.0f/2.0f)*(-20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2) + (20398.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (40000.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI - 1.0f/8.0f*Mathf.Pow(15, 1.0f/2.0f)*(-10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) + (40000.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) + (20398.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))/Mathf.PI + (1.0f/8.0f)*Mathf.Pow(15, 1.0f/2.0f)*(-20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) + (20398.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (40000.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI;
M[1][7]=(288178803.0f/24038404.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 288178803.0f/24038404.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (288178803.0f/24038404.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 288178803.0f/24038404.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[1][8]=(3.0f/8.0f)*Mathf.Pow(5, 1.0f/2.0f)*((99960399.0f/911979601.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) + (196020000.0f/911979601.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2) - 99960399.0f/911979601.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2) - 196020000.0f/911979601.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))/Mathf.PI - 3.0f/8.0f*Mathf.Pow(5, 1.0f/2.0f)*((196020000.0f/911979601.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (99960399.0f/911979601.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 196020000.0f/911979601.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2) - 99960399.0f/911979601.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI - 3.0f/8.0f*Mathf.Pow(5, 1.0f/2.0f)*(-99960399.0f/911979601.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) + (99960399.0f/911979601.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) - 196020000.0f/911979601.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2) + (196020000.0f/911979601.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI + (3.0f/8.0f)*Mathf.Pow(5, 1.0f/2.0f)*(-196020000.0f/911979601.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 99960399.0f/911979601.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (196020000.0f/911979601.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) + (99960399.0f/911979601.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI;
M[2][0]=0;
M[2][1]=(29403.0f/796.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 29403.0f/796.0f*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 29403.0f/796.0f*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (29403.0f/796.0f)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI;
M[2][2]=(14850.0f/199.0f)*Mathf.Sin((1.0f/99.0f)*y) + (14850.0f/199.0f)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI);
M[2][3]=-29403.0f/796.0f*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (29403.0f/796.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 29403.0f/796.0f*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (29403.0f/796.0f)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[2][4]=(29403.0f/120796.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (29403.0f/120796.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 29403.0f/120796.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI - 29403.0f/120796.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[2][5]=(297.0f/400.0f)*Mathf.Pow(5, 1.0f/2.0f)*((9900.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 9900.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 297.0f/400.0f*Mathf.Pow(5, 1.0f/2.0f)*((9900.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 9900.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI - 297.0f/400.0f*Mathf.Pow(5, 1.0f/2.0f)*(-9900.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (9900.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (297.0f/400.0f)*Mathf.Pow(5, 1.0f/2.0f)*(-9900.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (9900.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI;
M[2][6]=-1.0f/8.0f*Mathf.Pow(15, 1.0f/2.0f)*(-39600.0f/30199.0f*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*y) - 39600.0f/30199.0f*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) - 79200.0f/30199.0f*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y))/Mathf.PI + (1.0f/8.0f)*Mathf.Pow(15, 1.0f/2.0f)*((39600.0f/30199.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (39600.0f/30199.0f)*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (79200.0f/30199.0f)*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI))/Mathf.PI;
M[2][7]=-297.0f/400.0f*Mathf.Pow(5, 1.0f/2.0f)*((9900.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 9900.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))*Mathf.Sin((1.0f/99.0f)*x)/Mathf.PI - 297.0f/400.0f*Mathf.Pow(5, 1.0f/2.0f)*((9900.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 9900.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (297.0f/400.0f)*Mathf.Pow(5, 1.0f/2.0f)*(-9900.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (9900.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x)/Mathf.PI + (297.0f/400.0f)*Mathf.Pow(5, 1.0f/2.0f)*(-9900.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (9900.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[2][8]=-29403.0f/120796.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 29403.0f/120796.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 29403.0f/120796.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 29403.0f/120796.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[3][0]=0;
M[3][1]=-72772425.0f/39601.0f*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (72772425.0f/39601.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI - 72772425.0f/39601.0f*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (72772425.0f/39601.0f)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[3][2]=0;
M[3][3]=(72772425.0f/39601.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)/Mathf.PI + (72772425.0f/39601.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (72772425.0f/39601.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (72772425.0f/39601.0f)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[3][4]=(3.0f/4.0f)*Mathf.Pow(5, 1.0f/2.0f)*((9900.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2) - 9900.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2))*(-10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))/Mathf.PI - 3.0f/4.0f*Mathf.Pow(5, 1.0f/2.0f)*((9900.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2) - 9900.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2))*(-20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI - 3.0f/4.0f*Mathf.Pow(5, 1.0f/2.0f)*(-10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))*(-9900.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) + (9900.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI + (3.0f/4.0f)*Mathf.Pow(5, 1.0f/2.0f)*(-9900.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) + (9900.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2))*(-20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI;
M[3][5]=-72772425.0f/6009601.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (72772425.0f/6009601.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 72772425.0f/6009601.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (72772425.0f/6009601.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[3][6]=0;
M[3][7]=(72772425.0f/6009601.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (72772425.0f/6009601.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (72772425.0f/6009601.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (72772425.0f/6009601.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[3][8]=-14850.0f/30199.0f*Mathf.Pow(5, 1.0f/2.0f)*(-10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI - 14850.0f/30199.0f*Mathf.Pow(5, 1.0f/2.0f)*(-10199.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y), 2) - 20000.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (14850.0f/30199.0f)*Mathf.Pow(5, 1.0f/2.0f)*(-20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (14850.0f/30199.0f)*Mathf.Pow(5, 1.0f/2.0f)*(-20000.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 10199.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[4][0]=0;
M[4][1]=(28529701497.0f/170574723200.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 28529701497.0f/170574723200.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (28529701497.0f/170574723200.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 28529701497.0f/170574723200.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[4][2]=0;
M[4][3]=(28529701497.0f/170574723200.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 28529701497.0f/170574723200.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 28529701497.0f/170574723200.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (28529701497.0f/170574723200.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI;
M[4][4]=(147015.0f/3184.0f)*((1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (970299.0f/79600.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (147015.0f/3184.0f)*((1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (970299.0f/79600.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (28529701497.0f/50689280.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (28529701497.0f/50689280.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[4][5]=-28529701497.0f/1859710720.0f*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI + (28529701497.0f/1859710720.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI - 28529701497.0f/1859710720.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (28529701497.0f/1859710720.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[4][6]=0;
M[4][7]=-28529701497.0f/1859710720.0f*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI + (28529701497.0f/1859710720.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI + (28529701497.0f/1859710720.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI - 28529701497.0f/1859710720.0f*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI;
M[4][8]=(147015.0f/3184.0f)*((1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (970299.0f/79600.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)/Mathf.PI - 147015.0f/3184.0f*((1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (970299.0f/79600.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI + (28529701497.0f/50689280.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 28529701497.0f/50689280.0f*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI;
M[5][0]=0;
M[5][1]=-288178803.0f/23246384.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)/Mathf.PI - 288178803.0f/23246384.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 288178803.0f/23246384.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 288178803.0f/23246384.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[5][2]=0;
M[5][3]=-288178803.0f/23246384.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (288178803.0f/23246384.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI - 288178803.0f/23246384.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (288178803.0f/23246384.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[5][4]=-1440894015.0f/96153616.0f*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (1440894015.0f/96153616.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI - 1440894015.0f/96153616.0f*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (1440894015.0f/96153616.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[5][5]=(1440894015.0f/633616.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (1440894015.0f/633616.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (1440894015.0f/633616.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (1440894015.0f/633616.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[5][6]=-5.0f/8.0f*Mathf.Pow(3, 1.0f/2.0f)*(-9801.0f/796.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 9801.0f/796.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2) - 9801.0f/398.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI + (5.0f/8.0f)*Mathf.Pow(3, 1.0f/2.0f)*(-9801.0f/796.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2) - 9801.0f/796.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2) - 9801.0f/398.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))/Mathf.PI + (5.0f/8.0f)*Mathf.Pow(3, 1.0f/2.0f)*(-9801.0f/796.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 9801.0f/796.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) - 9801.0f/398.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI - 5.0f/8.0f*Mathf.Pow(3, 1.0f/2.0f)*(-9801.0f/796.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2) - 9801.0f/796.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) - 9801.0f/398.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))/Mathf.PI;
M[5][7]=(1440894015.0f/633616.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 1440894015.0f/633616.0f*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (1440894015.0f/633616.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 1440894015.0f/633616.0f*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[5][8]=-15.0f/8.0f*((96059601.0f/24038404.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 96059601.0f/24038404.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2))/Mathf.PI + (15.0f/8.0f)*((96059601.0f/24038404.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2) - 96059601.0f/24038404.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2))/Mathf.PI + (15.0f/8.0f)*(-96059601.0f/24038404.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (96059601.0f/24038404.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI - 15.0f/8.0f*(-96059601.0f/24038404.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2) + (96059601.0f/24038404.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI;
M[6][0]=(1.0f/4.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.PI;
M[6][1]=-1950399.0f/1168160000.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (1950399.0f/1168160000.0f)*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (1950399.0f/1168160000.0f)*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI - 1950399.0f/1168160000.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI;
M[6][2]=-19701.0f/5840800.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y) - 19701.0f/5840800.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI);
M[6][3]=(1950399.0f/1168160000.0f)*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 1950399.0f/1168160000.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (1950399.0f/1168160000.0f)*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 1950399.0f/1168160000.0f*Mathf.Pow(15, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[6][4]=-5.0f/8.0f*Mathf.Pow(3, 1.0f/2.0f)*((99.0f/400.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - 295980399.0f/15920000.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (99.0f/400.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI + (5.0f/8.0f)*Mathf.Pow(3, 1.0f/2.0f)*((99.0f/400.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) - 295980399.0f/15920000.0f*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (99.0f/400.0f)*Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI + (295980399.0f/25472000.0f)*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 295980399.0f/25472000.0f*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI;
M[6][5]=(295980399.0f/12736000.0f)*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI - 295980399.0f/12736000.0f*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI - 295980399.0f/12736000.0f*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (295980399.0f/12736000.0f)*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI;
M[6][6]=-5.0f/16.0f*(-2989701.0f/39800.0f*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*y) - 2989701.0f/39800.0f*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) - 2989701.0f/19900.0f*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y))/Mathf.PI + (5.0f/16.0f)*(-Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (2989701.0f/39800.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) - Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) - Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) + 2*Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (2989701.0f/39800.0f)*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (2989701.0f/19900.0f)*Mathf.PI*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) - Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + 2*Mathf.Pow(Mathf.PI, 2)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI;
M[6][7]=-295980399.0f/12736000.0f*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI + (295980399.0f/12736000.0f)*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI - 295980399.0f/12736000.0f*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (295980399.0f/12736000.0f)*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[6][8]=-5.0f/16.0f*Mathf.Pow(3, 1.0f/2.0f)*(-99.0f/200.0f*Mathf.PI*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x) + (295980399.0f/7960000.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) - 99.0f/200.0f*Mathf.PI*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI + (5.0f/16.0f)*Mathf.Pow(3, 1.0f/2.0f)*((99.0f/200.0f)*Mathf.PI*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI) - 295980399.0f/7960000.0f*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (99.0f/200.0f)*Mathf.PI*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))/Mathf.PI - 295980399.0f/25472000.0f*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 295980399.0f/25472000.0f*Mathf.Pow(3, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[7][0]=0;
M[7][1]=(72772425.0f/5811596.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 72772425.0f/5811596.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (72772425.0f/5811596.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 72772425.0f/5811596.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[7][2]=0;
M[7][3]=-72772425.0f/5811596.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)/Mathf.PI - 72772425.0f/5811596.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 72772425.0f/5811596.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 72772425.0f/5811596.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[7][4]=(147015.0f/3184.0f)*((9900.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2) - 9900.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2))*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI - 147015.0f/3184.0f*((9900.0f/30199.0f)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2) - 9900.0f/30199.0f*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x), 2))*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI - 147015.0f/3184.0f*(-9900.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) + (9900.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI + (147015.0f/3184.0f)*(-9900.0f/30199.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2) + (9900.0f/30199.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI;
M[7][5]=-363862125.0f/158404.0f*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (363862125.0f/158404.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI - 363862125.0f/158404.0f*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (363862125.0f/158404.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[7][6]=0;
M[7][7]=(363862125.0f/158404.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (363862125.0f/158404.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (363862125.0f/158404.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (363862125.0f/158404.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[7][8]=-363862125.0f/12019202.0f*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (363862125.0f/12019202.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI - 363862125.0f/12019202.0f*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (363862125.0f/12019202.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[8][0]=0;
M[8][1]=-288178803.0f/3411494464.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (288178803.0f/3411494464.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (288178803.0f/3411494464.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI - 288178803.0f/3411494464.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI;
M[8][2]=0;
M[8][3]=(288178803.0f/3411494464.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 288178803.0f/3411494464.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (288178803.0f/3411494464.0f)*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI - 288178803.0f/3411494464.0f*Mathf.Pow(5, 1.0f/2.0f)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[8][4]=-37125.0f/796.0f*((1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (970299.0f/79600.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)/Mathf.PI + (37125.0f/796.0f)*((1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (970299.0f/79600.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI - 1440894015.0f/2534464.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*x), 2)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (1440894015.0f/2534464.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI;
M[8][5]=(1440894015.0f/185971072.0f)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI - 1440894015.0f/185971072.0f*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI - 1440894015.0f/185971072.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (1440894015.0f/185971072.0f)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI;
M[8][6]=0;
M[8][7]=-1440894015.0f/185971072.0f*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)/Mathf.PI + (1440894015.0f/185971072.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)/Mathf.PI - 1440894015.0f/185971072.0f*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (1440894015.0f/185971072.0f)*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y), 2)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;
M[8][8]=(37125.0f/796.0f)*((1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (970299.0f/79600.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*x)/Mathf.PI + (37125.0f/796.0f)*((1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2) + (970299.0f/79600.0f)*Mathf.Sin((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI) + (1.0f/2.0f)*Mathf.PI*Mathf.Pow(Mathf.Cos((1.0f/99.0f)*y + (95.0f/198.0f)*Mathf.PI), 2))*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI + (1440894015.0f/2534464.0f)*Mathf.Sin((1.0f/99.0f)*x)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x)*Mathf.Cos((1.0f/99.0f)*y)/Mathf.PI + (1440894015.0f/2534464.0f)*Mathf.Sin((1.0f/99.0f)*y)*Mathf.Sin((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)*Mathf.Cos((1.0f/99.0f)*y)*Mathf.Cos((1.0f/99.0f)*x + (95.0f/198.0f)*Mathf.PI)/Mathf.PI;

        return M;
     }

}
