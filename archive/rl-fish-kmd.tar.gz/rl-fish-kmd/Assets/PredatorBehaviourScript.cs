﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;
#if UNITY_EDITOR
using UnityEditor;
#endif

public class PredatorBehaviourScript : MonoBehaviour {
	public float thresh=9.0f;
	public Agent predator;
	int time = 0;
	public float timelim = 10000.0f;
	public int n_success=0, n_fail=0;
	RewardTensor reward=null;
	GameObject preyObject;
	public float d0=9.5f;
	// Use this for initialization
	void Start () {
		predator = new Agent("predator", (int)timelim, 3, transform.rotation, transform.position);
		preyObject = GameObject.Find("prey");
		predator.thresh=thresh;
		Reset();
	}
	
	void Reset(){
	    // (int)System.DateTime.Now.Ticks
	    Random.InitState(321); // 12341 321
	    transform.position=Random.onUnitSphere*d0+preyObject.transform.position;
	    transform.rotation=Random.rotation;
	}
	// Update is called once per frame
	void FixedUpdate () {

		Debug.DrawRay(transform.position,
                      transform.TransformDirection(Vector3.forward) * 1.0f,
                      Color.blue);
		predator.reward_function(transform, preyObject.transform.position);
		time = Agent.increment_time(time, predator, transform);
		//Debug.Log("time=" + time + ", Direction= " + transform.rotation.ToString());
		
		if(predator.exitflag)
		{
			//Debug.Break();
			n_success+=1;
			thresh=predator.thresh=predator.thresh*0.99f;
			if(n_success%10==0){
				d0+=0.25f;
				timelim+=100;
			}
			Reset();
			reward=predator.reward_tensor;
			Debug.Log("found");
			// EditorApplication.isPlaying = false;
			// #if UNITY_EDITOR
			// EditorApplication.isPlaying = false;
			// #else
			// Application.Quit(0);
			// #endif
			predator.exitflag=false;
		}
		else if(time>timelim-2)
		{
			time=0;
			n_fail+=1;
			if(n_fail>5){
				d0=Mathf.Max(d0-0.01f,d0);
				n_fail=0;
			}
			reward=predator.reward_tensor;
			Reset();
		}

	}
}
