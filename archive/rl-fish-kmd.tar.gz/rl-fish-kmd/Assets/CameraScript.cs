﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour {

	public GameObject predator;
	private Vector3 offset;

	// Use this for initialization
	void Start () {
		predator = GameObject.Find("predator");
		Debug.Log("position = " + predator.transform.position.ToString());
		offset = transform.position - predator.transform.position;
	}
	
	// Update is called once per frame
	void LateUpdate () {
		transform.position = predator.transform.position + offset;
		// transform.rotation = predator.transform.rotation;
	}
}
