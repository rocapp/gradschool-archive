using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Rendering;
using Random = UnityEngine.Random;

/// <summary>
/// class that defines the reward distribution (orientation, reward)
/// </summary>
/// <remarks>
///   <para>
///     TODO: describe this class in detail
///   </para>
/// </remarks>
public class RewardTensor {

    /// <summary>
    ///   Scales the reward by the spherical harmonic laplacian
    /// </summary>
    public static SphericalHarmonicsL2 scaleByMat(float[][] M, SphericalHarmonicsL2 x)
    {
	SphericalHarmonicsL2 y=new SphericalHarmonicsL2();
	y.Clear();
	for(int i=0; i<9; ++i)
	{
	    y[0,i]=0f;
	    y[1,i]=0f;
	    y[2,i]=0f;
	    for(int k=0; k<9; ++k)
	    {
		y[0,i]+=M[i][k]*y[0,k];
		y[1,i]+=M[i][k]*y[1,k];
		y[2,i]+=M[i][k]*y[2,k];
	    }
	}
	return y;
    }
    
    public float maxR(SphericalHarmonicsL2 x, out Vector3 best)
    {
	float dmax=-1000000f;
	best=Vector3.zero;
	Vector3[] dirs={Vector3.up,Vector3.left,Vector3.right,Vector3.down, Vector3.back, Vector3.forward};
	for(int i=0; i<6; ++i)
	{
	    float d=Utils.sh_dot(x,dirs[i]);
	    if(d>dmax)
	    {
		dmax=d;
		best=dirs[i];
	    }
	}
	for(int i=0; i<100; ++i)
	{
			    Vector3 v=Random.onUnitSphere;
			    float d=Utils.sh_dot(x,v);
			    if(d>dmax){
				    dmax=d;
				    best=v;
			    }
		    }
	    return Utils.sh_dot(x,best);
    }
	    public float minR(SphericalHarmonicsL2 x){
		    float d=100000000f;
		    Vector3[] dirs={Vector3.up,Vector3.left,Vector3.right,Vector3.down, Vector3.back, Vector3.forward};
		    for(int i=0; i<6; ++i){
			    d=Mathf.Min(Utils.sh_dot(x,dirs[i]),d);
		    }
		    for(int i=0; i<100; ++i){
			    d=Mathf.Min(Utils.sh_dot(x,Random.onUnitSphere),d);
		    }
		    return d;
	    }
	    public SphericalHarmonicsL2[] V;
	    int nbins=0;
	    float maxd=0.0f;
	    Vector3 lastpos=new Vector3(0,1,0);
	    public RewardTensor(int n_reward_bins, float max_dist=20f)
	    {
		maxd=max_dist;
		nbins=n_reward_bins;
		V=new SphericalHarmonicsL2[nbins*nbins*nbins*nbins];
	    }
	    public void spot(Vector3 p){
		    lastpos=p;
	    }
	    public void degrade(float f, Vector3 p){
	foreach(var v in V){
	    v.AddAmbientLight(new Color(0.01f*f,0.01f*f,0.01f*f,0.01f*f));
	}
	V[bin(p)].AddAmbientLight(new Color(f,f,f,f));
	    }
	    public int bin(Vector3 q){
		    Vector3 p0=Vector3.up*maxd;
		    Vector3 p1=Vector3.left*maxd;
		    Vector3 p2=Vector3.back*maxd;
		    Vector3 p3=lastpos;
		    float px=Mathf.Min((q-p0).magnitude,maxd);
		    float py=Mathf.Min((q-p1).magnitude,maxd);
		    float pz=Mathf.Min((q-p2).magnitude,maxd);
		    float pw=Mathf.Min((q-p3).magnitude,maxd);
		    int ix=(int)(px*nbins/maxd);
		    ix=(int) Mathf.Min(ix,nbins-1);
		    int iy=(int)(py*nbins/maxd);
		    iy=(int) Mathf.Min(iy,nbins-1);
		    int iz=(int)(pz*nbins/maxd);
		    iz=(int) Mathf.Min(iz,nbins-1);
		    int iw=(int)(pw*nbins/maxd);
		    iw=(int) Mathf.Min(iw,nbins-1);
		    return ix*nbins*nbins*nbins+iy*nbins*nbins+iz*nbins+iw;
	    }

    /// <summary>
    ///   updates the reward tensor
    /// </summary>
    public void upd(Vector3 d, float R, Vector3 p)
    {
	for(int i=0; i<100; ++i){
	    Vector3 d2=d+Random.onUnitSphere*0.001f;//0.025f;
	    V[bin(p)].AddDirectionalLight(d2,Color.white,R);
	}
    }
    
    public void scale(float[][] M, Vector3 p)
    {
	V[bin(p)]=scaleByMat(M,V[bin(p)]);
    }
    
    public float max(Vector3 p)
    {
	Vector3 tmp;
	return maxR(V[bin(p)], out tmp);
    }
    
    public float min(Vector3 p)
    {
	return minR(V[bin(p)]);
    }
    
    public Vector3 opt(Vector3 d)
    {
	Vector3 best;
	maxR(V[bin(d)],out best);
	return best;
    }
    
    public void reset(Vector3 p)
    {
	V[bin(p)].Clear();
    }
    
    public float eval(Vector3 p, Vector3 d)
    {
	return Utils.sh_dot(V[bin(p)],d);
    }
}
