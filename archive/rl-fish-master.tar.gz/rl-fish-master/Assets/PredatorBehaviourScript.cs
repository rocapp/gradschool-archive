﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;
#if UNITY_EDITOR
using UnityEditor;
#endif

public class PredatorBehaviourScript : MonoBehaviour {
    public float thresh=0.5f;
    public float velocity=1f;
    public float velocity_scale=1f;
    public float turn_speed=0.2f;
    public Agent predator;
    public float reward_rate0=1.0f;
    int time = 0;
    public float timelim = 100000.0f;
    public int n_success=0, n_fail=0;
    RewardTensor reward=null;
    GameObject preyObject;
    public float d0=100.0f;
    public int nr_bins=5;
    public float max_distance=15;
    // Use this for initialization
    void Start () {
        predator = new Agent("predator", (int)timelim, nr_bins, transform.rotation,
                    transform.position, thresh, this.velocity, max_distance, turn_speed, velocity_scale, reward_rate0);
	predator.reward_tensor.readFromFile("predator"); // load memory from previous simulations
        preyObject = GameObject.Find("prey");
        Reset();
    }
    
    void Reset(){
        // (int)System.DateTime.Now.Ticks
        Random.InitState(System.Environment.TickCount);
	time = 0;
        transform.position=Random.onUnitSphere*d0+preyObject.transform.position;
        transform.rotation=Random.rotation;
        preyObject.transform.position+=Random.onUnitSphere*Random.value*2f;
        preyObject.transform.rotation=Random.rotation;
	predator.velocity=1f;
	preyObject.GetComponent<PreyBehaviorScript>().prey.velocity=1f;
    }
    // Update is called once per frame
    void FixedUpdate () {
	
        Debug.DrawRay(transform.position,
                        transform.TransformDirection(Vector3.forward) * 1.0f,
                        Color.blue);
        predator.reward_function(transform, preyObject.transform.position, preyObject, false, time);
        time = Agent.increment_time(time, predator, transform);
        Debug.Log("time="+time);
        if(predator.exitflag)
        {
			// Debug.Break();
			n_success+=1;
			thresh=predator.thresh=predator.thresh*0.99f;
			if(n_success%10==0){
				d0+=0.25f;
				timelim+=100;
			}
			Reset();
			reward=predator.reward_tensor;
			predator.reward_tensor.savetoFile("predator"); // write V matrix to file
			preyObject.GetComponent<PreyBehaviorScript>().prey.reward_rate=0.99f*preyObject.GetComponent<PreyBehaviorScript>().prey.reward_rate+0.01f*predator.reward_rate;
			preyObject.GetComponent<PreyBehaviorScript>().prey.reward_tensor.savetoFile("prey");
			Debug.Log("found");
			// EditorApplication.isPlaying = false;
			// #if UNITY_EDITOR
			// EditorApplication.isPlaying = false;
			// #else
			// Application.Quit(0);
			// #endif
			predator.exitflag=false;
	}
    	else if(time>=timelim-2)
		{
			time=0;
			n_fail+=1;
			if(n_fail>5){
				d0=Mathf.Max(d0-0.01f,d0);
				n_fail=0;
			}
			reward=predator.reward_tensor;
			
			predator.reward_rate=0.99f*predator.reward_rate+0.01f*preyObject.GetComponent<PreyBehaviorScript>().prey.reward_rate;
			predator.reward_tensor.savetoFile("predator");
			preyObject.GetComponent<PreyBehaviorScript>().prey.reward_tensor.savetoFile("prey");
			Reset();
		}
    }
}
