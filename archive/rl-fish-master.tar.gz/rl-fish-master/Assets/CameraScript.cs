﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour {

    public GameObject predator;
    public GameObject prey;
    private Vector3 offset;

	// Use this for initialization
	void Start () {
		predator = GameObject.Find("predator");
		prey = GameObject.Find("prey");
		Debug.Log("position = " + predator.transform.position.ToString());
		offset = new Vector3(0f, -10f, 0f);
	}
	
	// Update is called once per frame
	void LateUpdate () {
	    transform.position = predator.transform.position - offset;
	    Vector3 newDir = Vector3.RotateTowards(-Vector3.right, predator.transform.position+prey.transform.position, 1f, 0.001f);
	    transform.rotation = Quaternion.LookRotation(newDir);
	}
}
