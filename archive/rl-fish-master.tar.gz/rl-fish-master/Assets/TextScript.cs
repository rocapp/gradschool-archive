﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextScript : MonoBehaviour {

	private Text reward_text;

	// Use this for initialization
	void Start () {
		GameObject rewText = new GameObject();
		rewText.transform.parent = transform;
		rewText.AddComponent<Text>();
		reward_text = rewText.GetComponent<Text>();
		reward_text.text = "Reward Text.";
		reward_text.alignment = TextAnchor.MiddleCenter; 
	}
	
	// Update is called once per frame
	void Update () {
		// GameObject predator = GameObject.Find("predator");
		// predator.GetComponent<PredatorBehaviourScript>();
		// reward_text.text = "max_reward = " + 
	}
}
