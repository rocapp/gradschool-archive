﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PreyBehaviorScript : MonoBehaviour {
    public float thresh=0.5f;
    public float velocity=1f;
    public float reward_rate0=0.3f;
    public float velocity_scale=0.7f;
    public float turn_speed=0.2f;
    public Agent prey;
    int time = 0;
    RewardTensor reward=null;
    GameObject predatorObject;
    public int nr_bins=5;
    public float max_distance=15;
    public float timelim = 10000.0f;
    // Use this for initialization
    void Start () {
        prey = new Agent("prey", (int)timelim, nr_bins, transform.rotation,
                    transform.position, thresh, this.velocity, max_distance, turn_speed, velocity_scale, reward_rate0);
	prey.reward_tensor.readFromFile("prey"); // read reward tensor from previous saves
        predatorObject = GameObject.Find("predator");
    }
    void FixedUpdate(){
        prey.reward_function(transform, predatorObject.transform.position, predatorObject, true, time);
        time = Agent.increment_time(time, prey, transform);
        reward = prey.reward_tensor;
    }
}
