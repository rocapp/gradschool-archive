import os, sys, json
import numpy as np
from scipy.signal import find_peaks

def normalize(x): return (x - x.min()) / (x.max() - x.min())

def calc_r(xx, yy, dosum=True):
    if dosum: return ( (xx - xx.mean())*(yy - yy.mean()) ).sum() / ((xx.size-1)*xx.std()*yy.std())
    return ( (xx - xx.mean())*(yy - yy.mean()) ) / ((xx.size-1)*xx.std()*yy.std())

def codisp(xx):
    med = np.median(xx)
    return np.abs(med - xx).sum() / (med*xx.size)

def calc_stats(msv,extra=False):
    statd = {}
    statd['muc'] = msv
    arr = np.loadtxt("out.txt")
    time = arr[:,0]
    eat = arr[:,1]
    mpks,__ = find_peaks(eat,height=1.3,distance=50)
    etimes = time[mpks]
    erate = np.diff(etimes)
    erate = erate[erate > 0.0]
    imi = erate*10 # inter-meal intervals
    msz = eat[mpks]*100 # meal sizes = amplitude of "eat peaks"
    if imi.size > msz.size: imi = imi[:-1]
    elif msz.size > imi.size: msz = msz[:-1]
    statd['msimi_r'] = calc_r(msz,imi)
    statd['med_imi'] = np.median(imi)
    statd['med_msz'] = np.median(msz)
    statd['min_imi'] = imi.min()
    statd['min_msz'] = msz.min()
    statd['max_imi'] = imi.max()
    statd['max_msz'] = msz.max()
    statd['cd_imi'] = codisp(imi)
    statd['cd_msz'] = codisp(msz)
    if extra:
        return statd, arr, time, etimes, imi, msz
    return statd
