#!/bin/bash
./run.sh --nomuc "$@"
./run.sh --muc "$@"
# ./run.sh --vta "$@"
feh -Z --scale-down hungry-rat-fig_*.png
