# hungry-rat

a dynamical systems model of a hungry rat

=========================================

## Routines

### Grid search to sweep bifurcation parameter

- To generate a bifurcation diagram (MS, IMI, etc):

  *grid.py* : arguments : gmin (minimum param value), gmax (max param value), gstep (increment between values)

  `python3 grid.py --gmin 0.0 --gmax 1.0 --gstep 0.01`

=========================================

## Notes

### 04-08-2019
- equations now in latex_docs

### 03-28-2019
- gained a lot of intuition about the desired properties of the system
- simplified the model again
- the role of the hippocampus is way more clear now: hippocampal degradation decorrelates eating and satiety phases (hippocampal input to hypothalamus).

### 03-27-2019
- Fit the r values from Henderson 2012 exactly (r_musc=-0.15, r_cont=0.45)
- hippocampal degradation is implemented with the parameter sshift
- Current model configuration:
- $`\begin{alignedat}{3}
  [ ( \tau_{E} \cdot ( 0.5 + musc + S(t) ) ] \frac{dE}{dt} = -musc \cdot b_{E} \cdot E(t)^{3} + a_{H} \cdot H(t) \\
  \tau_{H} \frac{dH}{dt} = b_{H} \cdot H(t)^{2} - a_{E} \cdot E(t)^{3} \\
  [ ( \tau_{S} \cdot ( 0.5 + musc ) ) ] \frac{dS}{dt} = musc \cdot a_{E} \cdot E(t) - a_{H} \cdot H(t) - \frac{b_{S}}{musc} \cdot S(t)
  \end{alignedat}`$
  
### 03-25-2019
- The system is highly sensitive to initial conditions. This should be accounted for when considering usage for simulations of patients (how hungry are they on a scale, etc)
- The hunger initial condition needed to be changed to 0.1 so that the interdependence of meal size and inter-meal interval is more apparent when the hippocampus is engaged
-- *important*: mucimol is now represented by the sshift parameter (decreases the time constant of satiety)... this seems to effectively decrease the dependence of meal size on inter-meal interval, given mucimol.
- Set the default N=100,000 : this is important for determining the MS-IMI dependence.

### 10-08-2018
- Simplified the model drastically:
  - $`\begin{alignedat}{3}
  [ \tau_{E} \cdot ( 1.0 + S(t) ) ] \frac{dE}{dt} = -b_{E} \cdot E(t)^{3} + a_{H} \cdot H(t) \\
  \tau_{H} \frac{dH}{dt} = b_{H} \cdot H(t)^{2} - a_{E} \cdot E(t)^{3} \\
  \tau_{S} \cdot s_{shift} \cdot \frac{dS}{dt} = a_{E} \cdot E(t) - a_{H} \cdot H(t)
  \end{alignedat}`$
- $` a_{E} = 0.1 : no mucimol `$
- $` a_{E} = 0.025 : mucimol `$
- Also, replicated obesity by increasing hunger initial condition $`H_{0}`$.

### 10-07-2018
- Goal is to replicate results in Parent 2014
- the eating coefficient `ae` can alter the relationship between meal size and inter-meal interval
  - `ae` = 0.07 : meal size increases with inter-meal interval (memory intact)
  - `ae` = 0.005 : meal size no longer correlates with inter-meal interval (memory ablated)

