import os, sys, subprocess, json
import numpy as np
import matplotlib.pyplot as plt
import stats

def make_arr(key, jlist):
    return np.array([jl[key] for jl in jlist])

def loadstats(grng):
   jlist = []
   for ix in range(grng.size):
      with open('stats/stats{:03d}.txt'.format(ix)) as fst:
         td = json.load(fst)
         td['muc'] = grng[ix]
         jlist.append(td)
   return jlist

if __name__=="__main__":
   subprocess.run("g++ run.cc",shell=True)
   gmin, gmax, gstep = 0.0, 1.0, 0.01
   if len(sys.argv) > 1:
      for ia, arg in enumerate(sys.argv[1:]):
         arg = arg.strip("-")
         if arg.isalpha():
            print(arg, sys.argv[2+ia])
            if "gmin" in arg: gmin = float(sys.argv[ia+2])
            elif "gmax" in arg: gmax = float(sys.argv[ia+2])
            elif "gstep" in arg: gstep = float(sys.argv[ia+2])
   grng = np.arange(gmin, gmax, gstep)
   jlist = []
   for ix, msv in enumerate(grng):
      ilist = []
      N = 5
      for zz in range(N):
         subprocess.run('./a.out "--muc={:.4f}"'.format(msv,),shell=True)
         ilist.append(stats.calc_stats(msv))
      for sdi in ilist[1:]:
         for kk in ilist[0].keys():
            ilist[0][kk] += sdi[kk]
      for kk in ilist[0].keys():
         ilist[0][kk] /= N
      jlist.append(ilist[0])
   # stats
   mucarr = make_arr('muc',jlist)
   rarr = make_arr('msimi_r',jlist)
   msarr = make_arr('med_msz',jlist)
   imiarr = make_arr('med_imi',jlist)
   cdms = make_arr('cd_msz',jlist)
   cdimi = make_arr('cd_imi',jlist)
   # plot
   fig, axs = plt.subplots(nrows=3)
   plt.suptitle("Bifurcation Diagram (muscimol)")
   axs[0].plot(mucarr, rarr, '.-')
   axs[0].set_ylabel('MS-IMI correlation')
   axs[1].errorbar(mucarr, msarr, yerr=cdms, color="b", ecolor='k')
   axs[1].set_ylabel("MS")
   axs[2].errorbar(mucarr, imiarr, yerr=cdimi, color="r", ecolor='k')
   axs[2].set_ylabel("IMI")
   axs[2].set_xlabel('1.0 - [Muscimol]')
   plt.savefig("fig_grid.png")
   plt.show()
