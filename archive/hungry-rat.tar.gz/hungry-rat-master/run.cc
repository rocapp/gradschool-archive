#include <stdio.h>
#include <math.h>
#include <time.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <getopt.h>

int muc_flag = 0; // muscimol injection flag (hippocampus)
int v_flag = 0; // vta flag

// noise coeff
double r1 = 1e-15;

// initial conditions
double E0 = 0.0;
double H0 = 0.0;
double S0 = 0.0;

// growth rates
double ae = 3.0;
double ah = 2.0;
double as = 4.0;

// decay rates
double be = 1.0;
double bh = 5.0;
double bs = 1.0;

// time constants
double taue = 1.0;
double tauh = 1.0;
double taus = 1.0;

// reversal
double xr = 0.1;

// hippocampus shift
double sshift_s = 0.15; // muc
double sshift_b = 1.0; // nomuc
double sshift = sshift_b;

// VTA shift
double vshift_s = 0.15; // muc
double vshift_b = 1.0; // nomuc
double vshift = vshift_b;

double cals = 0.01; // number of calories per meal

// derivative function
void f(double t, double *y, double *x, double *I)
{
  // hypothalamus (arcuate, ventromedial, periventricular)
  x[0] = ( y[1] + ae*y[0]*y[0] - be*(y[0]*y[0]*y[0]) - y[2] ) / taue;
  x[1] = ( ah - bh*(y[0]*y[0]) - y[1] + I[0] ) / tauh;
  x[2] = 1e-3*( as*(y[0]+xr) - bs*y[2] + (I[1] - I[2] + I[0]) ) / taus;
}

// Class to set and organize the solution
class Soln {
public:
  double t;
  int M;
  double *y;
  double msz = 0.0;
  double hippo = sshift;
  double *vta;
  
  Soln();

  Soln(int m) : M(m) {
    y = new double[m];
    vta = new double[m];
  }
    
  void sety(double *yn){
    for(int i=0; i < M; i++)
      {
	y[i] = yn[i];
      }
  }
  
  void incr(double *yp, double *x, double h)
  {
    for(int i=0; i < M; i++)
      {
	y[i] = yp[i] + x[i]*h;
      }
  }
};

Soln::Soln()
{
  y = NULL;
}

// function for integrating the system
void euler(int M, int N, double h,
	   double *x0,
	   std::vector<Soln>& soln)
{
  double x[M];
  Soln s0(M);
  s0.t = 0.0;
  printf("initial conditions: \n");
  for(int i=0; i<M; i++)
    {
      s0.y[i] = x0[i];
      s0.vta[i] = x0[i];
      printf(" t=%f , y%d=%f\n", s0.t, i, s0.y[i]);
    }
  soln.push_back(s0);
  double t = 0.0;
  double lastm = 0;
  double taum = 10.0;
  double lasttau = taum;
  for (int i=1; i < N; i++)
    {
      t = t + h;
      Soln st(M);
      if (i > 2)
	{
	  if(soln.back().y[0] > 1.0 && soln.at(soln.size()-2).y[0] <= 1.0)
	    {
	      taum = (taum + soln.back().t - lastm) / 2.0;
	      lastm = soln.back().t;
	    }
	  st.hippo = soln.back().hippo + 1e-13;
	  if(taum<lasttau)
	    {
	      st.hippo -= soln.back().msz / (2.0*taum);
	    }
	  if(st.hippo < 0.1)
	    {
	      st.hippo = 0.1;
	    }
	  else if (st.hippo > sshift)
	    {
	      st.hippo = sshift;
	    }
	  if(soln.back().y[0] > 1.0)
	    {
	      // inversely proportional to RPE
	      double pfc_hip[M] = {
		4.0 / (1.0 + std::exp(0.2*std::pow(soln.back().y[1]-soln.back().y[0],2))),
		4.0 / (1.0 + std::exp(0.2*std::pow(soln.back().y[2]-soln.back().y[1],2))),
		4.0 / (1.0 + std::exp(0.2*std::pow(soln.back().y[2]-soln.back().y[0],2))) };
	      for(int ri=0; ri < M; ri++)
		{
		  double v_act = vshift;
		  double vscale = 0.1*v_act*soln.back().y[ri]*soln.back().y[ri];
		  st.vta[ri] = vscale*( soln.back().vta[ri] + 5.0*pfc_hip[ri]*(1.0+st.hippo) - 1e-2*soln.back().vta[ri]/taum );
		}
	    }
	}
      st.t = t;
      f(st.t, soln.back().y, x, st.vta);
      st.incr(soln.back().y, x, h);
      if(st.y[0] >= 1.0 &&
	 soln.at(soln.size()-2).y[0] < 1.0 &&
	 ((double)rand()/(double)RAND_MAX) >= 0.65)
	{
	  double h_act = 2.0 / (1.0+std::exp(st.hippo));
	  if(h_act<0.7)
	    h_act = 0.0;
	  st.y[0] += 0.5*ae*h_act;
	  st.y[1] += 0.25*ah*h_act;
	}
      soln.push_back(st);
      lasttau = taum;
      if(soln.back().y[0] > 1.0)
	soln.back().msz = soln.back().y[0]*cals;
    }
  printf("soln.size=%d\n",soln.size());
}

void write_file(std::vector<Soln> soln, std::string fn)
{

  printf("writing to file %s...\n",fn.c_str());
  
  std::ofstream mfile(fn);
  if (mfile.is_open())
    {
      for(int i=0; i < soln.size(); i++)
	{
	  mfile << soln[i].t << " ";
	  for(int j=0; j < soln[0].M; j++)
	    {
	      mfile << soln[i].y[j] << " ";
	    }
	  mfile << soln[i].hippo << " ";
	  mfile << soln[i].vta[0] << " ";
	  mfile << soln[i].vta[1] << " ";
	  mfile << soln[i].vta[2] << " ";
	  mfile << "\n";
	}
      mfile.close();
    }
  
  printf("wrote to file %s.\n",fn.c_str());
  
}

int main(int argc, char** argv)
{
  int M = 3;
  int N = 100000;
  double h = 0.1;

  srand(time(0));
  
  int c;

  while (1)
    {
      static struct option long_options[] =
	{
	 {"muc", optional_argument, &muc_flag, 1},
	 {"nomuc", no_argument, &muc_flag, 0},
	 {"vta", optional_argument, &v_flag, 1},
	 {"e0", required_argument, 0, 'e'},
	 {"h0", required_argument, 0, 'h'},
	 {"s0", required_argument, 0, 's'},
	 {"ah", required_argument, 0, 'a'},
	 {"ae", required_argument, 0, 'p'},
	 {"as", required_argument, 0, 't'},
	 {"be", required_argument, 0, 'c'},
	 {"bh", required_argument, 0, 'd'},
	 {"bs", required_argument, 0, 'z'},
	 {"taue", required_argument, 0, 'f'},
	 {"tauh", required_argument, 0, 'g'},
	 {"taus", required_argument, 0, 'i'},
	 {"N", required_argument, 0, 'n'},
	 {"h", required_argument, 0, 'j'},
	 {"r1", required_argument, 0, 'r'},
	 {"xr", required_argument, 0, 'x'}
	};

      int opt_ind = 0;

      c = getopt_long ( argc, argv, "e:h:s:a:c:d:f:g:i:r:z:x:p:t:",
			long_options, &opt_ind );

      if (c == -1)
	break;

      printf ("option %s", long_options[opt_ind].name);
      if (optarg)
	printf (" with arg %s", optarg);
      printf("\n");

      switch (c)
	{
	case 0: // flag options
	  // if (long_options[opt_ind].flag !=0)
	  //   break;
	  printf ("option %s", long_options[opt_ind].name);
	  if (optarg)
	    {
	      printf (" with arg %s", optarg);
	      printf("\n");
	      if(long_options[opt_ind].name=="muc")
		{
		  sshift_s = atof(optarg);
		}
	      else if(long_options[opt_ind].name=="vta")
		{
		  vshift_s = atof(optarg);
		}
	      break;
	    }
	  break;
	  
	case 't':
	  as = atof(optarg);
	  break;
	case 'x':
	  xr = atof(optarg);
	  break;
	case 'p':
	  ae = atof(optarg);
	  break;
	case 'e':
	  E0 = atof(optarg);
	  printf("  E0 = %.5f\n",E0);
	  break;
	case 'h':
	  H0 = atof(optarg);
	  printf("  H0 = %.5f\n",H0);
	  break;
	case 's':
	  S0 = atof(optarg);
	  printf("  S0 = %.5f\n",S0);
	  break;
	case 'z':
	  bs = atof(optarg);
	  break;
	case 'a':
	  ah = atof(optarg);
	  break;
	case 'c':
	  be = atof(optarg);
	  break;
	case 'd':
	  bh = atof(optarg);
	  break;
	case 'f':
	  taue = atof(optarg);
	  break;
	case 'g':
	  tauh = atof(optarg);
	  break;
	case 'i':
	  taus = atof(optarg);
	  break;
	case 'n':
	  N = atoi(optarg);
	  break;
	case 'j':
	  h = atof(optarg);
	  break;
	case 'r':
	  r1 = atof(optarg);
	  break;
	default: /* '?' */
	  fprintf(stderr,
		  "Usage: %s [--muc or --nomuc (default)] [-param_char/--param_name param_val]\n",
		  argv[0]);
	  exit(EXIT_FAILURE);
	}
    }

  sshift = (muc_flag==0) ? sshift_b : sshift_s;
  vshift = (v_flag==0) ? vshift_b : vshift_s;
  printf("  muc = %d\n",muc_flag);
  printf("  sshift = %.4f\n",sshift);
  printf("  vta = %d\n",v_flag);
  printf("  vshift = %.4f\n",vshift);
  
  double x0[] = { E0, H0, S0 };
  for(int xi=0; xi < M; xi++)
    x0[xi] += r1*rand()/RAND_MAX;
  std::vector<Soln> soln;

  euler(M, N, h, x0, soln);

  printf("===========\nfinished integrating.\n");

  write_file(soln, "out.txt");
  
}

