import os
import numpy as np
from matplotlib import rc
rc('text', usetex=True)
rc('figure',figsize=(15,10),)
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.stats import pearsonr
import stats

if __name__ == "__main__":
    statd, arr, time, etimes, imi, msz = stats.calc_stats(0.15,extra=True)
    msimi_rate = statd['msimi_r']
    fname = "hungry-rat-fig_{}".format(os.getenv("fext"))
    print("fig name is ",fname)
    fig, axarr = plt.subplots(nrows=3, ncols=2)
    fig.suptitle(fname.replace("_",": ").replace("-"," "))
    axarr[0][0].set_title("Ave IMI = {:.1f} sec;\nAve Meal = {:.1f} sec".format(statd['med_imi'],statd['med_msz']))
    axarr[0][0].plot(arr[:,0], arr[:,1], "g",
                     label="Eating phase")
    # axarr[0][0].scatter(arr[:,0], [-0.1,]*arr[:,0].size, c=arr[:,5], label='$VTA_E$')
    axarr[0][0].plot(etimes[:-1], msz/100.0, "rx",
                     label="Meal eaten")
    axarr[0][0].set_xlabel("time")
    axarr[0][0].legend(loc=4)
    width = (etimes[1]-etimes[0])*10.0
    nimi = stats.normalize(imi)
    nmsz = stats.normalize(msz)
    ncorr = stats.normalize(stats.calc_r(imi, msz, dosum=False))
    # axarr[0][1].plot(etimes[:-1], nimi, color="r",label="Inter-meal Intervals")
    # axarr[0][1].plot(etimes[:-1], nmsz, color="b",label="Meal Durations")
    axarr[0][1].plot(etimes[:-1], ncorr, color='g', label='Correlation')
    axarr[0][1].set_ylabel("Normalized Correlation IMI-MS")
    # axarr[0][1].legend(loc='center left', bbox_to_anchor=(1, 0.5))
    axarr[1][0].plot(arr[:,0], arr[:,2], "b", label="Hunger phase")
    # axarr[1][0].scatter(arr[:,0], [-0.1,]*arr[:,0].size, c=arr[:,6], label='$VTA_H$')
    axarr[1][0].legend(loc="best")
    axarr[2][0].plot(arr[:,0], arr[:,3], "k",
                     label="Satiety phase")
    # axarr[2][0].scatter(arr[:,0], [-0.1,]*arr[:,0].size, c=arr[:,7], label='$VTA_S$')
    axarr[2][0].legend(loc="best")
    
    axarr[2][1].plot(imi, msz, "k.", ls='', label="MS-IMI")
    ix_R = np.argsort(imi)
    pfR = np.poly1d(np.polyfit(imi[ix_R],msz[ix_R],1))
    axarr[2][1].plot(imi[ix_R], pfR(imi[ix_R]), 'b--', label='$R_{MS-IMI}$')
    axarr[2][1].set_ylabel("Meal size (MS)")
    axarr[2][1].set_xlabel("Inter-meal interval (IMI)")
    p0,p1=pearsonr(imi,msz)
    ttl = "$R_{MS-IMI} = " + "{:.4f}, p<{:.2f}$".format(msimi_rate,p1)
    axarr[2][1].set_title(ttl)
    axarr[2][1].plot(imi[np.argmax(msz)], np.max(msz), 'rx', label='Peak meal size')

    # axarr[1][1].axis('off')
    # axarr[1][1].plot(arr[:,0], arr[:,-1], 'b', label='VTA')
    axarr[1][1].plot(arr[:,0], arr[:,4], 'k', label="hippocampus")
    axarr[1][1].legend(loc='best')
    
    plt.subplots_adjust(wspace=0.45,hspace=0.3)
    plt.savefig("{}.png".format(fname),dpi=300)
    plt.savefig("{}.svg".format(fname),dpi=300)

    # f2, axs = plt.subplots(nrows=3)
    # axs[0].plot(arr[:,0], arr[:,5])
    # axs[0].set_ylabel("$VTA_E$")
    # axs[1].plot(arr[:,0], arr[:,6])
    # axs[1].set_ylabel("$VTA_H$")
    # axs[2].plot(arr[:,0], arr[:,7])
    # axs[2].set_ylabel("$VTA_S$")
    # axs[2].set_xlabel("time")
    # plt.savefig("{}_vta.png".format(fname),dpi=300)
    # plt.close()

    f3, axs = plt.subplots(ncols=3)
    # axs[0].bar(0, np.mean(arr[:,4]), yerr=np.std(arr[:,4]), color='k', ecolor='r', label='Hippocampus')
    axs[0].boxplot(arr[:,4])
    axs[0].set_ylabel('Neural activity')
    axs[0].set_ylim([0, 1.25])
    # axs[1].bar(0, np.mean(msz), yerr=np.std(msz), color='g', ecolor='r', label='Meal Size (MS)')
    axs[1].boxplot(msz)
    axs[1].set_ylim([100, 600])
    axs[1].set_ylabel('seconds')
    # axs[2].bar(0, np.mean(imi), yerr=np.std(imi), color='b', ecolor='r', label='Inter-meal Interval (IMI)')
    axs[2].boxplot(imi)
    axs[2].set_ylim([100, 2000])
    axs[2].set_ylabel('seconds')
    plt.savefig("{}_bars.png".format(fname,dpi=300))
    plt.savefig("{}_bars.svg".format(fname,dpi=300))
    plt.close()
    
    plt.show()
